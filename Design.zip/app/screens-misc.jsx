// screens-misc.jsx — Plan (meal suggestions), Profile, Paywall modal.
(function () {
  const I = window.VIcon;
  const { Card, Button, ProgressBar, Pill, MazeBg, Sparkline, SectionHeader, Disclaimer } = window.V;
  const S = window.VitalStore;

  // ---------- PLAN ----------
  const MEAL_IDEAS = [
    { id: 'oats', meal: 'Breakfast', name: 'Protein Oats & Berries', kcal: 420, p: 32, c: 52, f: 9, tag: 'High protein', mins: 8 },
    { id: 'chickenbowl', meal: 'Lunch', name: 'Chicken & Quinoa Bowl', kcal: 540, p: 46, c: 52, f: 16, tag: 'Balanced', mins: 15 },
    { id: 'salmon', meal: 'Dinner', name: 'Salmon, Greens & Sweet Potato', kcal: 610, p: 44, c: 41, f: 27, tag: 'Omega-3', mins: 22 },
    { id: 'yogurt', meal: 'Snack', name: 'Greek Yogurt & Almonds', kcal: 250, p: 22, c: 14, f: 12, tag: 'Quick', mins: 2 },
  ];

  function Plan() {
    const s = window.useVital();
    const tg = s.targets;
    const planned = MEAL_IDEAS.reduce((a, m) => a + m.kcal, 0);
    return (
      <div style={{ paddingBottom: 18 }}>
        <div style={{ padding: '6px 2px 16px' }}>
          <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>Plan</h1>
          <div style={{ fontSize: 13.5, color: 'var(--muted)', marginTop: 2 }}>A day that hits your {tg.budget.toLocaleString()} kcal target</div>
        </div>

        {/* summary */}
        <Card style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 16 }}>
          <div style={{ width: 48, height: 48, borderRadius: 14, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><I.leaf size={24} /></div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 15 }}>Today’s suggested menu</div>
            <div style={{ fontSize: 12.5, color: 'var(--muted)' }}>{planned.toLocaleString()} kcal · {s.onboarding.diet} · 4 meals</div>
          </div>
          <button onClick={() => S.toast('Menu refreshed')} style={{ width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><I.sync size={18} /></button>
        </Card>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {MEAL_IDEAS.map((m, i) => (
            <Card key={i} style={{ padding: 0, overflow: 'hidden' }} onClick={() => S.push('recipe', { id: m.id })}>
              <div style={{ height: 110, position: 'relative', display: 'flex', alignItems: 'flex-end', padding: 12, overflow: 'hidden', background: 'var(--surface2)' }}>
                <image-slot id={'plan-thumb-' + m.id} shape="rect" fit="cover" placeholder="Drop photo"
                  style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', color: '#9aa1ab' }}></image-slot>
                <span style={{ position: 'relative', fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--on-accent)', background: 'var(--accent)', padding: '4px 10px', borderRadius: 999 }}>{m.meal}</span>
                <div style={{ position: 'absolute', right: 12, top: 12, display: 'flex', gap: 6 }}>
                  <span style={{ fontSize: 11, fontWeight: 700, color: '#fff', background: 'rgba(0,0,0,0.45)', backdropFilter: 'blur(6px)', WebkitBackdropFilter: 'blur(6px)', padding: '4px 9px', borderRadius: 999, display: 'inline-flex', alignItems: 'center', gap: 4 }}><I.clock size={12} /> {m.mins}m</span>
                </div>
              </div>
              <div style={{ padding: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
                  <div style={{ fontWeight: 700, fontSize: 15.5, flex: 1 }}>{m.name}</div>
                  <div style={{ fontWeight: 800, fontSize: 15, fontFamily: 'var(--font-display)' }}>{m.kcal}</div>
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 10, alignItems: 'center' }}>
                  <MacroTag c="var(--c-protein)" v={m.p} k="P" />
                  <MacroTag c="var(--c-carbs)" v={m.c} k="C" />
                  <MacroTag c="var(--c-fat)" v={m.f} k="F" />
                  <div style={{ flex: 1 }} />
                  <button onClick={(e) => { e.stopPropagation(); S.addFood({ meal: m.meal, name: m.name, brand: 'Vital plan', qty: 1, unit: 'serving', kcal: m.kcal, p: m.p, c: m.c, f: m.f, fib: 5, src: 'plan', verified: true }); }}
                    style={{ height: 34, padding: '0 14px', borderRadius: 10, border: 'none', background: 'var(--accent)', color: 'var(--on-accent)', fontWeight: 700, fontSize: 13, fontFamily: 'inherit', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                    <I.plus size={15} sw={2.5} /> Log
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  function MacroTag({ c, v, k }) {
    return (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 600, color: 'var(--muted)' }}>
        <span style={{ width: 8, height: 8, borderRadius: 999, background: c }} />{v}g {k}
      </span>
    );
  }

  // ---------- PROFILE ----------
  function Profile({ onReplayOnboarding }) {
    const s = window.useVital();
    const tg = s.targets;
    const ob = s.onboarding;
    const goalKg = ob.targetWeightKg;
    return (
      <div style={{ paddingBottom: 18 }}>
        <div style={{ padding: '6px 2px 16px' }}>
          <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>Profile</h1>
        </div>

        {/* identity */}
        <Card style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 14 }}>
          <div style={{ width: 60, height: 60, borderRadius: 999, background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 26, fontFamily: 'var(--font-display)', flexShrink: 0 }}>{(ob.name || 'A')[0]}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 800, fontSize: 19, fontFamily: 'var(--font-display)' }}>{ob.name}</div>
            <div style={{ fontSize: 13, color: 'var(--muted)' }}>{ob.age} · {ob.sex} · {ob.heightCm} cm</div>
          </div>
          <button onClick={onReplayOnboarding} style={{ width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><I.edit size={17} /></button>
        </Card>

        {/* premium banner */}
        <Card accent onClick={() => S.paywall(true)} style={{ position: 'relative', overflow: 'hidden', marginBottom: 14, cursor: 'pointer' }}>
          <MazeBg opacity={0.1} />
          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(0,0,0,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><I.crown size={24} /></div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 800, fontSize: 16, fontFamily: 'var(--font-display)' }}>Go Vital Pro</div>
              <div style={{ fontSize: 12.5, opacity: 0.82, fontWeight: 600 }}>AI coaching, custom macros & more</div>
            </div>
            <I.chevR size={20} />
          </div>
        </Card>

        {/* weight trend */}
        <Card onClick={() => S.push('progress')} style={{ marginBottom: 14, cursor: 'pointer' }}>
          <SectionHeader title="Progress" action="View all" onAction={() => S.push('progress')} />
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 30, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5 }}>{s.weightLog[s.weightLog.length - 1].kg}<span style={{ fontSize: 14, color: 'var(--muted)' }}> kg</span></span>
            <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)', display: 'inline-flex', alignItems: 'center' }}><I.arrowDown size={14} /> 2.2 kg</span>
            <span style={{ fontSize: 12.5, color: 'var(--muted)' }}>· goal {goalKg} kg</span>
          </div>
          <div style={{ marginTop: 10 }}>
            <Sparkline points={s.weightLog} goal={goalKg} width={300} height={72} />
          </div>
        </Card>

        {/* targets */}
        <Card style={{ marginBottom: 14, padding: 0, overflow: 'hidden' }}>
          <Row icon={<I.target size={19} />} label="Daily calorie target" value={`${tg.budget.toLocaleString()} kcal`} />
          <Row icon={<I.flame size={19} />} label="Maintenance (TDEE)" value={`${tg.tdee.toLocaleString()} kcal`} />
          <Row icon={<I.leaf size={19} />} label="Diet style" value={ob.diet} cap />
          <Row icon={<I.weight size={19} />} label="Goal weight" value={`${goalKg} kg`} last />
        </Card>

        {/* settings */}
        <Card style={{ padding: 0, overflow: 'hidden' }}>
          <Row icon={<I.cog size={19} />} label="Units & preferences" chevron onClick={() => S.toast('Settings')} />
          <Row icon={<I.sync size={19} />} label="Connected apps & devices" chevron onClick={() => S.toast('Health sync')} />
          <Row icon={<I.calendar size={19} />} label="Reminders" value="On" chevron onClick={() => S.toast('Reminders')} last />
        </Card>

        <div style={{ marginTop: 16 }}><Disclaimer /></div>
      </div>
    );
  }

  function Row({ icon, label, value, chevron, onClick, last, cap }) {
    return (
      <div onClick={onClick} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', borderBottom: last ? 'none' : '1px solid var(--border)', cursor: onClick ? 'pointer' : 'default' }}>
        <div style={{ color: 'var(--muted)', flexShrink: 0 }}>{icon}</div>
        <div style={{ flex: 1, fontWeight: 600, fontSize: 14.5 }}>{label}</div>
        {value && <div style={{ fontSize: 13.5, color: 'var(--muted)', fontWeight: 600, textTransform: cap ? 'capitalize' : 'none' }}>{value}</div>}
        {chevron && <I.chevR size={18} style={{ color: 'var(--faint)' }} />}
      </div>
    );
  }

  // ---------- PAYWALL ----------
  function Paywall() {
    window.useVital();
    const [plan, setPlan] = React.useState('year');
    const feats = [
      'AI meal scan — unlimited photos',
      'Custom macro & calorie targets',
      'Adaptive coaching that adjusts weekly',
      'Recipe library & auto meal plans',
      'Advanced trends & body analytics',
    ];
    return (
      <div style={{ position: 'absolute', inset: 0, zIndex: 50, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
        <div onClick={() => S.paywall(false)} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(2px)' }} />
        <div style={{ position: 'relative', background: 'var(--bg)', borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: '92%', overflowY: 'auto', boxShadow: '0 -10px 40px rgba(0,0,0,0.3)' }}>
          {/* hero */}
          <div style={{ position: 'relative', background: 'var(--accent)', color: 'var(--on-accent)', padding: '22px 24px 26px', borderTopLeftRadius: 28, borderTopRightRadius: 28, overflow: 'hidden' }}>
            <MazeBg opacity={0.1} />
            <div style={{ position: 'relative' }}>
              <button onClick={() => S.paywall(false)} style={{ position: 'absolute', right: 0, top: 0, width: 32, height: 32, borderRadius: 999, border: 'none', background: 'rgba(0,0,0,0.15)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><I.x size={18} /></button>
              <div style={{ width: 50, height: 50, borderRadius: 14, background: 'rgba(0,0,0,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}><I.crown size={28} /></div>
              <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1.5, opacity: 0.7 }}>Vital Pro</div>
              <h2 style={{ margin: '4px 0 0', fontSize: 27, fontWeight: 800, letterSpacing: -0.8, lineHeight: 1.1, fontFamily: 'var(--font-display)' }}>Reach your goal faster.</h2>
            </div>
          </div>

          <div style={{ padding: '20px 24px calc(var(--safe-bottom) + 16px)' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>
              {feats.map((f, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 24, height: 24, borderRadius: 999, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><I.check size={15} sw={3} /></div>
                  <span style={{ fontSize: 14.5, fontWeight: 600 }}>{f}</span>
                </div>
              ))}
            </div>

            {/* plans */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <PlanOption active={plan === 'year'} onClick={() => setPlan('year')} title="Annual" price="$59.99 / yr" sub="$4.99 / mo · billed yearly" badge="Save 50%" />
              <PlanOption active={plan === 'month'} onClick={() => setPlan('month')} title="Monthly" price="$9.99 / mo" sub="Billed monthly" />
            </div>

            <Button full size="lg" onClick={() => { S.paywall(false); S.toast('Welcome to Pro 🎉'); }} style={{ marginTop: 18 }}>Start 7-day free trial</Button>
            <div style={{ textAlign: 'center', fontSize: 11.5, color: 'var(--faint)', marginTop: 12, lineHeight: 1.4 }}>
              Then {plan === 'year' ? '$59.99/yr' : '$9.99/mo'}. Cancel anytime. Renews automatically.
            </div>
          </div>
        </div>
      </div>
    );
  }

  function PlanOption({ active, onClick, title, price, sub, badge }) {
    return (
      <div onClick={onClick} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '15px 16px', borderRadius: 16, cursor: 'pointer', background: active ? 'var(--accent-soft)' : 'var(--surface)', border: active ? '1.5px solid var(--accent)' : '1px solid var(--border)' }}>
        <div style={{ width: 22, height: 22, borderRadius: 999, border: active ? 'none' : '2px solid var(--border)', background: active ? 'var(--accent)' : 'transparent', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{active && <I.check size={14} sw={3} />}</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontWeight: 800, fontSize: 15.5 }}>{title}</span>
            {badge && <span style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--on-accent)', background: 'var(--accent)', padding: '2px 8px', borderRadius: 999, textTransform: 'uppercase', letterSpacing: 0.5, whiteSpace: 'nowrap' }}>{badge}</span>}
          </div>
          <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 2 }}>{sub}</div>
        </div>
        <div style={{ fontWeight: 800, fontSize: 15, fontFamily: 'var(--font-display)', whiteSpace: 'nowrap' }}>{price}</div>
      </div>
    );
  }

  window.VitalScreens = window.VitalScreens || {};
  Object.assign(window.VitalScreens, { Plan, Profile, Paywall });
})();
