// app-shell.jsx — tab bar + router. Renders the active screen for one device.
(function () {
  const I = window.VIcon;
  const S = window.VitalStore;
  const SC = window.VitalScreens;

  const TABS = [
    { key: 'home', label: 'Home', icon: I.home },
    { key: 'log', label: 'Diary', icon: I.log },
    { key: 'workout', label: 'Train', icon: I.dumbbell },
    { key: 'plan', label: 'Plan', icon: I.plan },
    { key: 'profile', label: 'Profile', icon: I.profile },
  ];

  function TabBar({ tab }) {
    return (
      <div style={{
        display: 'flex', alignItems: 'stretch', gap: 2,
        padding: '8px 10px calc(var(--safe-bottom) + 6px)',
        background: 'var(--surface)', borderTop: '1px solid var(--border)',
      }}>
        {TABS.map((t) => {
          const on = t.key === tab;
          const Icon = t.icon;
          return (
            <button key={t.key} onClick={() => S.setTab(t.key)} style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              padding: '6px 0', border: 'none', background: 'transparent', cursor: 'pointer',
              color: on ? 'var(--accent)' : 'var(--muted)', fontFamily: 'inherit',
            }}>
              <Icon size={24} sw={on ? 2.4 : 2} />
              <span style={{ fontSize: 10.5, fontWeight: on ? 800 : 600, letterSpacing: 0.1 }}>{t.label}</span>
            </button>
          );
        })}
      </div>
    );
  }

  function Toast({ msg }) {
    if (!msg) return null;
    return (
      <div style={{ position: 'absolute', left: '50%', bottom: 'calc(var(--safe-bottom) + 86px)', transform: 'translateX(-50%)', zIndex: 40, pointerEvents: 'none' }}>
        <div className="vital-toast" style={{
          background: 'var(--text)', color: 'var(--bg)', padding: '11px 18px', borderRadius: 999,
          fontSize: 13.5, fontWeight: 700, whiteSpace: 'nowrap', boxShadow: 'var(--shadow)',
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <I.check size={16} sw={3} style={{ color: 'var(--accent)' }} />{msg}
        </div>
      </div>
    );
  }

  function tabScreen(tab, metaphor, replay) {
    switch (tab) {
      case 'home': return <SC.Home metaphor={metaphor} />;
      case 'log': return <SC.Diary />;
      case 'workout': return <SC.WorkoutHome />;
      case 'plan': return <SC.Plan />;
      case 'profile': return <SC.Profile onReplayOnboarding={replay} />;
      default: return <SC.Home metaphor={metaphor} />;
    }
  }

  function stackScreen(top) {
    switch (top.screen) {
      case 'foodSearch': return <SC.FoodSearch params={top.params} />;
      case 'foodDetail': return <SC.FoodDetail params={top.params} />;
      case 'aiSnap': return <SC.AiSnap params={top.params} />;
      case 'workoutPlayer': return <SC.WorkoutPlayer params={top.params} />;
      case 'recipe': return <SC.Recipe params={top.params} />;
      case 'progress': return <SC.Progress params={top.params} />;
      default: return null;
    }
  }

  // App: one full instance of Vital for a device. Props: metaphor (calorie hero).
  function VitalApp({ metaphor }) {
    const s = window.useVital();
    const scrollRef = React.useRef(null);
    const top = s.nav.stack[s.nav.stack.length - 1];

    // reset scroll when switching tab / pushing
    React.useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, [s.nav.tab, s.nav.stack.length]);

    let content;
    if (s.mode === 'auth') {
      content = <SC.Auth onApp={() => S.setMode('app')} onSignup={() => S.setMode('onboarding')} />;
    } else if (s.mode === 'onboarding') {
      content = <SC.Onboarding onDone={() => S.setMode('app')} />;
    } else if (top) {
      content = stackScreen(top);
    } else {
      content = (
        <React.Fragment>
          <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', WebkitOverflowScrolling: 'touch', padding: 'var(--safe-top) 18px 14px' }}>
            {tabScreen(s.nav.tab, metaphor, () => S.setMode('onboarding'))}
          </div>
          <TabBar tab={s.nav.tab} />
        </React.Fragment>
      );
    }

    return (
      <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)', color: 'var(--text)', overflow: 'hidden', fontFamily: 'var(--font-body)' }}>
        {content}
        <Toast msg={s.toast} />
        {s.paywall && <SC.Paywall />}
      </div>
    );
  }

  window.VitalApp = VitalApp;
})();
