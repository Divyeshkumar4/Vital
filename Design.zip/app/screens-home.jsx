// screens-home.jsx — dashboard: hero calorie metaphor, macros, quick actions, widgets.
(function () {
  const I = window.VIcon;
  const { Card, CalorieHero, MacroBars, BarChart, ProgressBar, SectionHeader, Pill } = window.V;
  const S = window.VitalStore;

  function QuickAction({ icon, label, onClick, accent }) {
    return (
      <button onClick={onClick} style={{
        flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
        padding: '14px 6px', borderRadius: 18, cursor: 'pointer',
        background: accent ? 'var(--accent)' : 'var(--surface)',
        color: accent ? 'var(--on-accent)' : 'var(--text)',
        border: accent ? 'none' : '1px solid var(--border)', fontFamily: 'inherit',
      }}>
        <div style={{
          width: 40, height: 40, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: accent ? 'rgba(0,0,0,0.12)' : 'var(--accent-soft)', color: accent ? 'var(--on-accent)' : 'var(--accent)',
        }}>{icon}</div>
        <span style={{ fontSize: 11.5, fontWeight: 700 }}>{label}</span>
      </button>
    );
  }

  function Home({ metaphor }) {
    const s = window.useVital();
    const t = S.totals(s);
    const tg = s.targets;
    const greeting = (() => {
      const h = new Date().getHours();
      return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
    })();
    const weekKcal = [1820, 2010, 1760, 1950, 2080, 1690, t.kcal];
    const wLabels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

    const waterPct = Math.round((s.waterMl / s.waterGoalMl) * 100);

    return (
      <div style={{ paddingBottom: 18 }}>
        {/* header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', padding: '6px 2px 18px' }}>
          <div>
            <div style={{ fontSize: 13, color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>{greeting},</div>
            <h1 style={{ margin: '2px 0 0', fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>{s.onboarding.name}</h1>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', borderRadius: 999, background: 'var(--surface)', border: '1px solid var(--border)' }}>
            <I.flame size={16} style={{ color: 'var(--accent)' }} />
            <span style={{ fontWeight: 800, fontSize: 14 }}>{s.streak}</span>
            <span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600 }}>day streak</span>
          </div>
        </div>

        {/* hero */}
        <Card style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18, paddingTop: 24, paddingBottom: 22 }}>
          <CalorieHero consumed={t.kcal} budget={tg.budget} burned={s.burnedKcal} metaphor={metaphor} size={196} />
          <div style={{ display: 'flex', width: '100%', borderTop: '1px solid var(--border)', paddingTop: 16 }}>
            <HeroStat icon={<I.apple size={16} />} label="Eaten" value={t.kcal.toLocaleString()} />
            <Divider />
            <HeroStat icon={<I.flame size={16} />} label="Burned" value={s.burnedKcal.toLocaleString()} />
            <Divider />
            <HeroStat icon={<I.target size={16} />} label="Budget" value={tg.budget.toLocaleString()} />
          </div>
        </Card>

        {/* quick actions */}
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <QuickAction accent icon={<I.plus size={22} sw={2.4} />} label="Log food" onClick={() => { S.setTab('log'); S.push('foodSearch', { meal: 'Lunch' }); }} />
          <QuickAction icon={<I.camera size={20} />} label="AI snap" onClick={() => { S.setTab('log'); S.push('aiSnap', {}); }} />
          <QuickAction icon={<I.scan size={20} />} label="Scan" onClick={() => { S.setTab('log'); S.push('foodSearch', { meal: 'Snack', scan: true }); }} />
          <QuickAction icon={<I.drop size={20} />} label="Water" onClick={() => S.addWater(250)} />
        </div>

        {/* macros */}
        <Card style={{ marginTop: 14 }}>
          <SectionHeader title="Macros" action="Details" onAction={() => S.setTab('log')} />
          <MacroBars totals={t} targets={tg} />
        </Card>

        {/* row: water + weekly */}
        <div style={{ display: 'flex', gap: 12, marginTop: 14 }}>
          <Card style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <I.drop size={20} style={{ color: 'var(--c-carbs)' }} />
              <span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 700 }}>{waterPct}%</span>
            </div>
            <div style={{ margin: '14px 0 10px' }}>
              <div style={{ fontSize: 24, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5 }}>{(s.waterMl / 1000).toFixed(1)}<span style={{ fontSize: 13, color: 'var(--muted)', fontWeight: 600 }}> / {(s.waterGoalMl / 1000).toFixed(1)} L</span></div>
              <div style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 600 }}>Water today</div>
            </div>
            <ProgressBar value={s.waterMl} max={s.waterGoalMl} color="var(--c-carbs)" height={7} />
            <div style={{ display: 'flex', gap: 7, marginTop: 12 }}>
              <button onClick={() => S.addWater(250)} style={miniBtn}>+250</button>
              <button onClick={() => S.addWater(500)} style={miniBtn}>+500 ml</button>
            </div>
          </Card>

          <Card style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
              <I.chart size={20} style={{ color: 'var(--accent)' }} />
              <span style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 700 }}>7-day</span>
            </div>
            <div style={{ fontSize: 24, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5, margin: '6px 0 2px' }}>1,857</div>
            <div style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 600, marginBottom: 12 }}>avg kcal / day</div>
            <BarChart data={weekKcal} labels={wLabels} height={56} />
          </Card>
        </div>

        {/* steps / activity */}
        <Card style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ width: 46, height: 46, borderRadius: 999, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.bolt size={22} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontWeight: 700, fontSize: 14 }}>Steps</span>
              <span style={{ fontSize: 13, color: 'var(--muted)', fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}><b style={{ color: 'var(--text)' }}>{s.steps.toLocaleString()}</b> / 10,000</span>
            </div>
            <ProgressBar value={s.steps} max={10000} height={7} />
          </div>
        </Card>

        {/* today's workout teaser */}
        <Card onClick={() => S.setTab('workout')} style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ width: 46, height: 46, borderRadius: 14, background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.dumbbell size={24} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8 }}>Today’s workout</div>
            <div style={{ fontWeight: 700, fontSize: 15, marginTop: 2 }}>{s.workout.title}</div>
          </div>
          <I.chevR size={20} style={{ color: 'var(--muted)' }} />
        </Card>
      </div>
    );
  }

  function HeroStat({ icon, label, value }) {
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
        <div style={{ color: 'var(--muted)' }}>{icon}</div>
        <div style={{ fontSize: 16, fontWeight: 800, fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--font-display)' }}>{value}</div>
        <div style={{ fontSize: 10.5, color: 'var(--muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6 }}>{label}</div>
      </div>
    );
  }
  function Divider() { return <div style={{ width: 1, background: 'var(--border)', margin: '2px 0' }} />; }

  const miniBtn = {
    flex: 1, padding: '7px 0', borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface2)',
    color: 'var(--text)', fontSize: 12, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer',
  };

  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Home = Home;
})();
