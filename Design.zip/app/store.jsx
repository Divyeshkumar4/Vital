// store.jsx — shared external store for Vital (nav + app data), synced across both device frames.
// Tweaks (appearance) live separately on the page root and are passed in as props.

(function () {
  // ---------- Nutrition math (real, Mifflin–St Jeor) ----------
  function computeTargets(p) {
    // p: { sex, age, heightCm, weightKg, activity, goal, rateKgWk }
    const bmr = p.sex === 'female'
      ? 10 * p.weightKg + 6.25 * p.heightCm - 5 * p.age - 161
      : 10 * p.weightKg + 6.25 * p.heightCm - 5 * p.age + 5;
    const actMult = { sedentary: 1.2, light: 1.375, moderate: 1.55, very: 1.725, extra: 1.9 }[p.activity] || 1.375;
    const tdee = Math.round(bmr * actMult);
    // goal adjust: ~7700 kcal per kg → daily delta from weekly rate
    const rate = p.goal === 'maintain' ? 0 : (p.rateKgWk || 0.5);
    let delta = Math.round((rate * 7700) / 7);
    if (p.goal === 'lose') delta = -delta;
    if (p.goal === 'gain') delta = +delta;
    if (p.goal === 'maintain') delta = 0;
    // safety clamp: don't go below ~1200 (f) / 1500 (m) or cut >25% of TDEE
    let budget = tdee + delta;
    const floor = p.sex === 'female' ? 1200 : 1500;
    let clamped = false;
    if (budget < Math.max(floor, tdee * 0.75)) { budget = Math.round(Math.max(floor, tdee * 0.75)); clamped = true; }
    budget = Math.round(budget / 10) * 10;
    // macros
    const proteinG = Math.round(p.weightKg * 1.8);
    const fatG = Math.round((budget * 0.27) / 9);
    const carbsG = Math.max(0, Math.round((budget - proteinG * 4 - fatG * 9) / 4));
    const fiberG = Math.round((budget / 1000) * 14);
    const bmi = +(p.weightKg / Math.pow(p.heightCm / 100, 2)).toFixed(1);
    return { bmr: Math.round(bmr), tdee, budget, proteinG, carbsG, fatG, fiberG, bmi, clamped };
  }

  const onboarding = {
    name: 'Alex', age: 29, sex: 'male',
    units: 'metric',
    heightCm: 178, weightKg: 76,
    activity: 'moderate', goal: 'lose', rateKgWk: 0.5,
    targetWeightKg: 70, bodyFat: null,
    persona: 'general', diet: 'omnivore', eatsEggs: true,
    region: 'United States', currency: 'USD',
  };

  const targets = computeTargets(onboarding);

  // Seed a partial day of food so Home/Log look alive
  const seedDiary = [
    { id: 1, meal: 'Breakfast', name: 'Greek Yogurt & Berries', brand: 'Chobani', qty: 1, unit: 'bowl', kcal: 240, p: 20, c: 28, f: 6, fib: 4, src: 'branded', verified: true },
    { id: 2, meal: 'Breakfast', name: 'Black Coffee', brand: '', qty: 1, unit: 'cup', kcal: 5, p: 0, c: 1, f: 0, fib: 0, src: 'common', verified: true },
    { id: 3, meal: 'Lunch', name: 'Grilled Chicken Bowl', brand: '', qty: 1, unit: 'bowl', kcal: 540, p: 46, c: 52, f: 16, fib: 9, src: 'common', verified: true },
    { id: 4, meal: 'Snack', name: 'Almonds', brand: '', qty: 28, unit: 'g', kcal: 164, p: 6, c: 6, f: 14, fib: 4, src: 'common', verified: true },
  ];

  const initial = {
    mode: 'app',               // 'app' | 'auth' | 'onboarding'
    onboarded: true,           // start in-app; "Replay onboarding" available from Profile
    onboarding,
    targets,
    nav: { tab: 'home', stack: [] },   // stack of { screen, params }
    diary: seedDiary,
    nextId: 100,
    waterMl: 1000,
    waterGoalMl: 2500,
    weightLog: [
      { d: '05-08', kg: 78.2 }, { d: '05-12', kg: 77.6 }, { d: '05-16', kg: 77.4 },
      { d: '05-20', kg: 76.9 }, { d: '05-24', kg: 76.5 }, { d: '05-29', kg: 76.0 },
    ],
    streak: 12,
    burnedKcal: 320,           // exercise + steps
    steps: 7240,
    workout: {
      title: 'Upper Body • Push',
      restDay: false,
      exIndex: 0,
      // sets done count per exercise
      progress: [0, 0, 0, 0],
      resting: false,
      restLeft: 0,
    },
    toast: null,
    paywall: false,
  };

  let state = initial;
  const listeners = new Set();
  function getState() { return state; }
  function setState(updater) {
    state = typeof updater === 'function' ? updater(state) : { ...state, ...updater };
    listeners.forEach((l) => l());
  }
  function subscribe(l) { listeners.add(l); return () => listeners.delete(l); }

  // ---------- nav helpers ----------
  function setTab(tab) {
    setState((s) => ({ ...s, nav: { tab, stack: [] } }));
  }
  function push(screen, params = {}) {
    setState((s) => ({ ...s, nav: { ...s.nav, stack: [...s.nav.stack, { screen, params }] } }));
  }
  function pop() {
    setState((s) => ({ ...s, nav: { ...s.nav, stack: s.nav.stack.slice(0, -1) } }));
  }
  function resetStack() {
    setState((s) => ({ ...s, nav: { ...s.nav, stack: [] } }));
  }
  function setMode(mode) {
    setState((s) => ({ ...s, mode, nav: { tab: 'home', stack: [] } }));
  }

  // ---------- data helpers ----------
  function addFood(entry) {
    setState((s) => ({
      ...s,
      diary: [...s.diary, { ...entry, id: s.nextId }],
      nextId: s.nextId + 1,
    }));
    toast('Added to ' + entry.meal);
  }
  function removeFood(id) {
    setState((s) => ({ ...s, diary: s.diary.filter((e) => e.id !== id) }));
  }
  function addWater(ml) {
    setState((s) => ({ ...s, waterMl: Math.max(0, s.waterMl + ml) }));
  }
  let toastTimer = null;
  function toast(msg) {
    setState((s) => ({ ...s, toast: msg }));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => setState((s) => ({ ...s, toast: null })), 1900);
  }
  function paywall(on) { setState((s) => ({ ...s, paywall: on })); }

  function applyOnboarding(partial) {
    setState((s) => {
      const ob = { ...s.onboarding, ...partial };
      return { ...s, onboarding: ob, targets: computeTargets(ob) };
    });
  }

  // ---------- derived ----------
  function totals(s) {
    const t = { kcal: 0, p: 0, c: 0, f: 0, fib: 0 };
    s.diary.forEach((e) => { t.kcal += e.kcal; t.p += e.p; t.c += e.c; t.f += e.f; t.fib += e.fib; });
    return t;
  }

  window.VitalStore = {
    getState, setState, subscribe,
    setTab, push, pop, resetStack, setMode,
    addFood, removeFood, addWater, toast, paywall, applyOnboarding,
    computeTargets, totals,
  };

  window.useVital = function useVital() {
    const s = React.useSyncExternalStore(subscribe, getState);
    return s;
  };
})();
