// screens-log.jsx — Food diary, search, food detail, AI snap. Live add/remove via store.
(function () {
  const I = window.VIcon;
  const { Card, MacroBars, Button, Stepper, Segmented, ProgressBar, Pill } = window.V;
  const S = window.VitalStore;

  const MEALS = ['Breakfast', 'Lunch', 'Dinner', 'Snack'];

  // food database for search
  const FOODS = [
    { name: 'Grilled Chicken Breast', brand: '', unit: '100 g', kcal: 165, p: 31, c: 0, f: 3.6, fib: 0, src: 'common', verified: true },
    { name: 'White Rice, cooked', brand: '', unit: '1 cup', kcal: 205, p: 4.3, c: 45, f: 0.4, fib: 0.6, src: 'common', verified: true },
    { name: 'Banana', brand: '', unit: '1 medium', kcal: 105, p: 1.3, c: 27, f: 0.4, fib: 3.1, src: 'common', verified: true },
    { name: 'Whole Eggs', brand: '', unit: '2 large', kcal: 156, p: 12.6, c: 1.1, f: 10.6, fib: 0, src: 'common', verified: true },
    { name: 'Oats, rolled', brand: '', unit: '40 g', kcal: 152, p: 5.3, c: 27, f: 2.6, fib: 4, src: 'common', verified: true },
    { name: 'Protein Bar', brand: 'RXBAR', unit: '1 bar', kcal: 210, p: 12, c: 24, f: 9, fib: 5, src: 'branded', verified: true },
    { name: 'Salmon Fillet', brand: '', unit: '140 g', kcal: 280, p: 39, c: 0, f: 13, fib: 0, src: 'common', verified: true },
    { name: 'Avocado', brand: '', unit: '1/2 fruit', kcal: 160, p: 2, c: 8.5, f: 14.7, fib: 6.7, src: 'common', verified: true },
    { name: 'Greek Yogurt, plain', brand: 'Fage 0%', unit: '170 g', kcal: 90, p: 18, c: 6, f: 0, fib: 0, src: 'branded', verified: true },
    { name: 'Almond Butter', brand: '', unit: '1 tbsp', kcal: 98, p: 3.4, c: 3, f: 8.9, fib: 1.6, src: 'common', verified: false },
    { name: 'Sweet Potato, baked', brand: '', unit: '1 medium', kcal: 112, p: 2, c: 26, f: 0.1, fib: 3.9, src: 'common', verified: true },
    { name: 'Sourdough Bread', brand: '', unit: '1 slice', kcal: 120, p: 4, c: 23, f: 1, fib: 1.2, src: 'common', verified: true },
  ];

  const RECENT = ['Greek Yogurt, plain', 'Grilled Chicken Breast', 'Banana', 'Oats, rolled'];

  // ---------- DIARY ----------
  function MealGroup({ meal, entries, onAdd }) {
    const kcal = entries.reduce((a, e) => a + e.kcal, 0);
    return (
      <Card style={{ marginBottom: 14, padding: 0, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '15px 16px 13px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontWeight: 800, fontSize: 15.5, fontFamily: 'var(--font-display)' }}>{meal}</span>
            {kcal > 0 && <span style={{ fontSize: 12.5, color: 'var(--muted)', fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{kcal} kcal</span>}
          </div>
          <button onClick={onAdd} style={{ width: 30, height: 30, borderRadius: 999, border: 'none', background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <I.plus size={18} sw={2.5} />
          </button>
        </div>
        {entries.length > 0 && entries.map((e) => (
          <div key={e.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 16px', borderTop: '1px solid var(--border)' }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', flexShrink: 0 }}>
              <I.fork size={17} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 600, fontSize: 14, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{e.name}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>{e.qty} {e.unit} · P{Math.round(e.p)} C{Math.round(e.c)} F{Math.round(e.f)}</div>
            </div>
            <div style={{ fontWeight: 700, fontSize: 14, fontVariantNumeric: 'tabular-nums' }}>{e.kcal}</div>
            <button onClick={() => S.removeFood(e.id)} style={{ border: 'none', background: 'transparent', color: 'var(--faint)', cursor: 'pointer', padding: 4 }}><I.x size={16} /></button>
          </div>
        ))}
        {entries.length === 0 && (
          <div onClick={onAdd} style={{ padding: '13px 16px', borderTop: '1px solid var(--border)', fontSize: 13, color: 'var(--faint)', cursor: 'pointer' }}>
            Nothing logged — tap to add
          </div>
        )}
      </Card>
    );
  }

  function Diary() {
    const s = window.useVital();
    const t = S.totals(s);
    const tg = s.targets;
    const remaining = tg.budget - t.kcal + s.burnedKcal;
    return (
      <div style={{ paddingBottom: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 2px 16px' }}>
          <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>Diary</h1>
          <Pill icon={<I.calendar size={15} />} label="Today" tone="neutral" />
        </div>

        {/* summary strip */}
        <Card style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 12 }}>
            <div>
              <div style={{ fontSize: 28, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5, lineHeight: 1 }}>{remaining.toLocaleString()}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600, marginTop: 3 }}>kcal remaining</div>
            </div>
            <div style={{ textAlign: 'right', fontSize: 12.5, color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>
              <span style={{ color: 'var(--text)', fontWeight: 700 }}>{t.kcal.toLocaleString()}</span> eaten · <span style={{ color: 'var(--text)', fontWeight: 700 }}>{s.burnedKcal}</span> burned
            </div>
          </div>
          <ProgressBar value={t.kcal} max={tg.budget} height={9} />
          <div style={{ marginTop: 16 }}><MacroBars totals={t} targets={tg} compact /></div>
        </Card>

        {MEALS.map((m) => (
          <MealGroup key={m} meal={m} entries={s.diary.filter((e) => e.meal === m)} onAdd={() => S.push('foodSearch', { meal: m })} />
        ))}
      </div>
    );
  }

  // ---------- FOOD SEARCH ----------
  function FoodSearch({ params }) {
    window.useVital();
    const [q, setQ] = React.useState('');
    const [meal, setMeal] = React.useState(params.meal || 'Lunch');
    const [scanning, setScanning] = React.useState(!!params.scan);
    const results = q.trim()
      ? FOODS.filter((f) => (f.name + ' ' + f.brand).toLowerCase().includes(q.toLowerCase()))
      : FOODS.filter((f) => RECENT.includes(f.name));

    React.useEffect(() => {
      if (!scanning) return;
      const t = setTimeout(() => { setScanning(false); setQ('Protein Bar'); }, 1800);
      return () => clearTimeout(t);
    }, [scanning]);

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <Header title="Add food" onBack={() => S.pop()} />
        <div style={{ padding: '4px 18px 12px' }}>
          <Segmented full options={MEALS} value={meal} onChange={setMeal} />
          <div style={{ position: 'relative', marginTop: 12 }}>
            <I.search size={18} style={{ position: 'absolute', left: 14, top: 15, color: 'var(--muted)' }} />
            <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search 1M+ foods"
              style={{ width: '100%', boxSizing: 'border-box', height: 48, padding: '0 44px 0 42px', borderRadius: 14, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', fontSize: 15, fontFamily: 'inherit', outline: 'none' }} />
            <button onClick={() => setScanning(true)} style={{ position: 'absolute', right: 8, top: 8, width: 32, height: 32, borderRadius: 10, border: 'none', background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
              <I.scan size={18} />
            </button>
          </div>
        </div>

        {scanning ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, color: 'var(--muted)' }}>
            <div className="vital-scan" style={{ width: 120, height: 120, borderRadius: 24, border: '2px solid var(--accent)', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <I.scan size={46} style={{ color: 'var(--accent)' }} />
            </div>
            <div style={{ fontWeight: 600 }}>Scanning barcode…</div>
          </div>
        ) : (
          <div style={{ flex: 1, overflowY: 'auto', padding: '0 18px 18px' }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1, margin: '6px 2px 10px' }}>
              {q.trim() ? `${results.length} results` : 'Recent'}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {results.map((f, i) => (
                <div key={i} onClick={() => S.push('foodDetail', { food: f, meal })} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderRadius: 14, background: 'var(--surface)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                  <div style={{ width: 38, height: 38, borderRadius: 11, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', flexShrink: 0 }}>
                    <I.fork size={18} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 14.5, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{f.name}</span>
                      {f.verified && <I.check size={13} sw={3} style={{ color: 'var(--accent)', flexShrink: 0 }} />}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--muted)' }}>{f.brand ? f.brand + ' · ' : ''}{f.unit} · {f.kcal} kcal</div>
                  </div>
                  <div style={{ width: 28, height: 28, borderRadius: 999, border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)', flexShrink: 0 }}>
                    <I.plus size={16} sw={2.5} />
                  </div>
                </div>
              ))}
              {results.length === 0 && (
                <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--faint)' }}>
                  <I.search size={32} style={{ marginBottom: 10, opacity: 0.5 }} />
                  <div style={{ fontSize: 14 }}>No foods match “{q}”.</div>
                  <div style={{ fontSize: 12.5, marginTop: 4 }}>Try a barcode scan instead.</div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ---------- FOOD DETAIL ----------
  function FoodDetail({ params }) {
    window.useVital();
    const f = params.food;
    const [qty, setQty] = React.useState(1);
    const [meal, setMeal] = React.useState(params.meal || 'Lunch');
    const scale = (v) => Math.round(v * qty * 10) / 10;
    const macros = [
      { k: 'Protein', v: scale(f.p), c: 'var(--c-protein)', cal: scale(f.p) * 4 },
      { k: 'Carbs', v: scale(f.c), c: 'var(--c-carbs)', cal: scale(f.c) * 4 },
      { k: 'Fat', v: scale(f.f), c: 'var(--c-fat)', cal: scale(f.f) * 9 },
    ];
    const totalCal = Math.round(f.kcal * qty);
    const ringTotal = macros.reduce((a, m) => a + m.cal, 0) || 1;

    function add() {
      S.addFood({ meal, name: f.name, brand: f.brand, qty, unit: f.unit, kcal: totalCal, p: scale(f.p), c: scale(f.c), f: scale(f.f), fib: scale(f.fib), src: f.src, verified: f.verified });
      S.resetStack();
      S.setTab('log');
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <Header title="" onBack={() => S.pop()} />
        <div style={{ flex: 1, overflowY: 'auto', padding: '0 22px 18px' }}>
          <h1 style={{ margin: '0 0 8px', fontSize: 24, fontWeight: 800, letterSpacing: -0.6, lineHeight: 1.12, fontFamily: 'var(--font-display)' }}>{f.name}</h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', color: 'var(--muted)', fontSize: 13.5, marginBottom: 22 }}>
            <span style={{ whiteSpace: 'nowrap' }}>{f.brand ? f.brand + ' · ' : ''}per {f.unit}</span>
            {f.verified && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, color: 'var(--accent)', fontWeight: 700, whiteSpace: 'nowrap' }}><I.check size={13} sw={3} /> Verified</span>}
          </div>

          {/* calorie + macro donut */}
          <Card style={{ display: 'flex', alignItems: 'center', gap: 22, marginBottom: 16 }}>
            <MacroDonut macros={macros} total={ringTotal} kcal={totalCal} />
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12 }}>
              {macros.map((m) => (
                <div key={m.k} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 999, background: m.c }} />
                  <span style={{ flex: 1, fontSize: 13.5, color: 'var(--muted)', fontWeight: 600 }}>{m.k}</span>
                  <span style={{ fontWeight: 700, fontSize: 14, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{m.v} g</span>
                </div>
              ))}
            </div>
          </Card>

          {/* meal + serving */}
          <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1, margin: '6px 2px 10px' }}>Meal</div>
          <Segmented full options={MEALS} value={meal} onChange={setMeal} />
          <Card style={{ marginTop: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14.5 }}>Servings</div>
              <div style={{ fontSize: 12.5, color: 'var(--muted)' }}>{f.unit}</div>
            </div>
            <Stepper value={qty} onChange={setQty} step={0.5} min={0.5} max={20} />
          </Card>
        </div>

        <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
          <Button full size="lg" onClick={add} icon={<I.plus size={20} sw={2.5} />}>Add to {meal} · {totalCal} kcal</Button>
        </div>
      </div>
    );
  }

  function MacroDonut({ macros, total, kcal }) {
    const size = 104, sw = 13, r = (size - sw) / 2, C = 2 * Math.PI * r;
    let off = 0;
    return (
      <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--track)" strokeWidth={sw} />
          {macros.map((m, i) => {
            const frac = m.cal / total;
            const seg = <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={m.c} strokeWidth={sw}
              strokeDasharray={`${C * frac} ${C}`} strokeDashoffset={-C * off} />;
            off += frac;
            return seg;
          })}
        </svg>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontSize: 22, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5, lineHeight: 1 }}>{kcal}</div>
          <div style={{ fontSize: 9.5, color: 'var(--muted)', fontWeight: 700, letterSpacing: 0.5 }}>KCAL</div>
        </div>
      </div>
    );
  }

  // ---------- AI SNAP ----------
  function AiSnap() {
    window.useVital();
    const [phase, setPhase] = React.useState('aim'); // aim | analyzing | result
    const detected = [
      { name: 'Grilled chicken', kcal: 220, p: 41, c: 0, f: 5, fib: 0, conf: 0.94 },
      { name: 'Brown rice', kcal: 170, p: 4, c: 36, f: 1.4, fib: 2.5, conf: 0.88 },
      { name: 'Steamed broccoli', kcal: 55, p: 3.7, c: 11, f: 0.6, fib: 5, conf: 0.81 },
    ];
    const [items, setItems] = React.useState(detected.map((d) => ({ ...d, on: true })));
    const sum = items.filter((i) => i.on).reduce((a, i) => ({ kcal: a.kcal + i.kcal, p: a.p + i.p, c: a.c + i.c, f: a.f + i.f, fib: a.fib + i.fib }), { kcal: 0, p: 0, c: 0, f: 0, fib: 0 });

    React.useEffect(() => {
      if (phase !== 'analyzing') return;
      const t = setTimeout(() => setPhase('result'), 2100);
      return () => clearTimeout(t);
    }, [phase]);

    function logAll() {
      items.filter((i) => i.on).forEach((i) => S.addFood({ meal: 'Lunch', name: i.name, brand: 'AI estimate', qty: 1, unit: 'serving', kcal: i.kcal, p: i.p, c: i.c, f: i.f, fib: i.fib, src: 'ai', verified: false }));
      S.resetStack(); S.setTab('log');
    }

    if (phase === 'result') {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <Header title="Review meal" onBack={() => S.pop()} />
          <div style={{ flex: 1, overflowY: 'auto', padding: '0 22px 18px' }}>
            <div style={{ background: 'var(--surface2)', borderRadius: 20, overflow: 'hidden', marginBottom: 8 }}>
              <image-slot id="aisnap-meal" shape="rounded" radius="20" fit="cover" placeholder="Drop your meal photo"
                style={{ display: 'block', width: '100%', height: '150px', color: '#9aa1ab' }}></image-slot>
            </div>
            <p style={{ fontSize: 13, color: 'var(--muted)', margin: '12px 2px 16px', lineHeight: 1.45 }}>
              We detected <b style={{ color: 'var(--text)' }}>{items.length} items</b>. Toggle anything we got wrong, then log.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {items.map((it, idx) => (
                <div key={idx} onClick={() => setItems((p) => p.map((x, i) => i === idx ? { ...x, on: !x.on } : x))}
                  style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 14px', borderRadius: 14, background: it.on ? 'var(--surface)' : 'var(--surface2)', border: it.on ? '1px solid var(--border)' : '1px dashed var(--border)', cursor: 'pointer', opacity: it.on ? 1 : 0.55 }}>
                  <div style={{ width: 22, height: 22, borderRadius: 7, background: it.on ? 'var(--accent)' : 'transparent', border: it.on ? 'none' : '2px solid var(--border)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{it.on && <I.check size={14} sw={3} />}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14.5 }}>{it.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--muted)' }}>{it.kcal} kcal · P{it.p} C{it.c} F{it.f}</div>
                  </div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: it.conf > 0.85 ? 'var(--accent)' : 'var(--muted)' }}>{Math.round(it.conf * 100)}%</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
            <Button full size="lg" onClick={logAll}>Log {Math.round(sum.kcal)} kcal · {items.filter(i => i.on).length} items</Button>
          </div>
        </div>
      );
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#08090A', color: '#fff' }}>
        <Header title="AI meal scan" onBack={() => S.pop()} dark />
        <div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', inset: 24, borderRadius: 28, background: 'linear-gradient(135deg,#1a1d22,#0d0f12)' }} />
          {/* framing brackets */}
          <div style={{ position: 'absolute', inset: 48 }}>
            {[[0,0],[1,0],[0,1],[1,1]].map(([x,y],i) => (
              <div key={i} style={{ position: 'absolute', width: 34, height: 34, [x?'right':'left']: 0, [y?'bottom':'top']: 0,
                borderTop: y?'none':'3px solid var(--accent)', borderBottom: y?'3px solid var(--accent)':'none',
                borderLeft: x?'none':'3px solid var(--accent)', borderRight: x?'3px solid var(--accent)':'none',
                borderRadius: 6 }} />
            ))}
          </div>
          {phase === 'analyzing' ? (
            <div style={{ textAlign: 'center', position: 'relative' }}>
              <div className="vital-spin" style={{ width: 54, height: 54, borderRadius: 999, border: '3px solid rgba(255,255,255,0.15)', borderTopColor: 'var(--accent)', margin: '0 auto 16px' }} />
              <div style={{ fontWeight: 600 }}>Analyzing your plate…</div>
              <div style={{ fontSize: 12.5, color: 'rgba(255,255,255,0.5)', marginTop: 4 }}>Identifying foods & portions</div>
            </div>
          ) : (
            <div style={{ textAlign: 'center', position: 'relative', color: 'rgba(255,255,255,0.65)' }}>
              <I.camera size={40} /><div style={{ fontSize: 13.5, marginTop: 10, maxWidth: 180 }}>Center your meal in the frame</div>
            </div>
          )}
        </div>
        <div style={{ padding: '20px 22px calc(var(--safe-bottom) + 22px)', display: 'flex', justifyContent: 'center' }}>
          <button onClick={() => setPhase('analyzing')} disabled={phase === 'analyzing'}
            style={{ width: 72, height: 72, borderRadius: 999, border: '5px solid rgba(255,255,255,0.25)', background: 'var(--accent)', cursor: 'pointer', opacity: phase === 'analyzing' ? 0.5 : 1 }} />
        </div>
      </div>
    );
  }

  // shared header
  function Header({ title, onBack, dark }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 'var(--safe-top) 18px 12px' }}>
        <button onClick={onBack} style={{ width: 38, height: 38, borderRadius: 999, border: dark ? '1px solid rgba(255,255,255,0.18)' : '1px solid var(--border)', background: dark ? 'rgba(255,255,255,0.08)' : 'var(--surface)', color: dark ? '#fff' : 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}>
          <I.chevL size={20} />
        </button>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 800, letterSpacing: -0.3, fontFamily: 'var(--font-display)', flex: 1, whiteSpace: 'nowrap' }}>{title}</h2>
      </div>
    );
  }

  window.VitalScreens = window.VitalScreens || {};
  Object.assign(window.VitalScreens, { Diary, FoodSearch, FoodDetail, AiSnap });
})();
