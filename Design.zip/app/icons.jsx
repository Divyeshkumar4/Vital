// icons.jsx — clean line-icon set for Vital. Stroke uses currentColor so they inherit text color.
(function () {
  function Ico({ d, size = 24, sw = 2, fill = 'none', children, vb = 24, ...rest }) {
    return (
      <svg width={size} height={size} viewBox={`0 0 ${vb} ${vb}`} fill="none"
        stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" {...rest}>
        {d ? <path d={d} fill={fill} stroke={fill === 'none' ? 'currentColor' : 'none'} /> : children}
      </svg>
    );
  }

  const I = {
    home: (p) => <Ico {...p}><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5" /></Ico>,
    log: (p) => <Ico {...p}><path d="M5 4.5h11l3 3V19.5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-14a1 1 0 0 1 1-1Z" /><path d="M8 10h8M8 14h6" /></Ico>,
    dumbbell: (p) => <Ico {...p}><path d="M6.5 6.5v11M3.5 9v6M17.5 6.5v11M20.5 9v6M6.5 12h11" /></Ico>,
    plan: (p) => <Ico {...p}><path d="M4 6.5h16M4 12h16M4 17.5h10" /><circle cx="20" cy="17.5" r="1.4" fill="currentColor" stroke="none" /></Ico>,
    profile: (p) => <Ico {...p}><circle cx="12" cy="8" r="3.6" /><path d="M5 20c0-3.6 3.1-6 7-6s7 2.4 7 6" /></Ico>,
    flame: (p) => <Ico {...p}><path d="M12 3c2 3 .5 4.5 0 5.5C11 7 9.5 6 9.5 6S7 8 7 11.5a5 5 0 0 0 10 0c0-2.2-1.2-3.7-2-5-.7 1.4-2 1.6-3 .5Z" /></Ico>,
    drop: (p) => <Ico {...p}><path d="M12 3.5C12 3.5 6 9.5 6 14a6 6 0 0 0 12 0c0-4.5-6-10.5-6-10.5Z" /></Ico>,
    scan: (p) => <Ico {...p}><path d="M4 8V5.5a1.5 1.5 0 0 1 1.5-1.5H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16" /><path d="M7 12h10" /></Ico>,
    camera: (p) => <Ico {...p}><path d="M3.5 8.5A1.5 1.5 0 0 1 5 7h2l1.2-2h7.6L17 7h2a1.5 1.5 0 0 1 1.5 1.5V18a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 18Z" /><circle cx="12" cy="13" r="3.4" /></Ico>,
    plus: (p) => <Ico {...p}><path d="M12 5v14M5 12h14" /></Ico>,
    minus: (p) => <Ico {...p}><path d="M5 12h14" /></Ico>,
    weight: (p) => <Ico {...p}><circle cx="12" cy="12" r="8.5" /><path d="M12 12l3-3.2" /></Ico>,
    chevR: (p) => <Ico {...p}><path d="M9 5l7 7-7 7" /></Ico>,
    chevL: (p) => <Ico {...p}><path d="M15 5l-7 7 7 7" /></Ico>,
    chevD: (p) => <Ico {...p}><path d="M5 9l7 7 7-7" /></Ico>,
    chevU: (p) => <Ico {...p}><path d="M5 15l7-7 7 7" /></Ico>,
    search: (p) => <Ico {...p}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></Ico>,
    star: (p) => <Ico {...p}><path d="M12 4l2.3 4.7 5.2.8-3.8 3.7.9 5.2L12 16.7 7.4 18.4l.9-5.2L4.5 9.5l5.2-.8Z" /></Ico>,
    starFill: (p) => <Ico {...p} fill="currentColor"><path d="M12 4l2.3 4.7 5.2.8-3.8 3.7.9 5.2L12 16.7 7.4 18.4l.9-5.2L4.5 9.5l5.2-.8Z" fill="currentColor" stroke="currentColor" /></Ico>,
    check: (p) => <Ico {...p}><path d="M5 12.5l4.5 4.5L19 7" /></Ico>,
    x: (p) => <Ico {...p}><path d="M6 6l12 12M18 6L6 18" /></Ico>,
    bolt: (p) => <Ico {...p}><path d="M13 3 5 13h6l-1 8 8-10h-6l1-8Z" /></Ico>,
    clock: (p) => <Ico {...p}><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></Ico>,
    crown: (p) => <Ico {...p}><path d="M4 8l3.5 3L12 5l4.5 6L20 8l-1.5 9h-13L4 8Z" /></Ico>,
    edit: (p) => <Ico {...p}><path d="M5 19h14M14 5.5l3.5 3.5L9 17.5l-4 1 1-4 8-9Z" /></Ico>,
    copy: (p) => <Ico {...p}><rect x="8" y="8" width="11" height="11" rx="2" /><path d="M5 15.5V6.5A1.5 1.5 0 0 1 6.5 5H15" /></Ico>,
    trash: (p) => <Ico {...p}><path d="M4.5 7h15M9 7V5.5A1.5 1.5 0 0 1 10.5 4h3A1.5 1.5 0 0 1 15 5.5V7M6.5 7l1 12.5A1.5 1.5 0 0 0 9 21h6a1.5 1.5 0 0 0 1.5-1.5L17.5 7" /></Ico>,
    calendar: (p) => <Ico {...p}><rect x="4" y="5.5" width="16" height="15" rx="2" /><path d="M4 10h16M8 3.5v4M16 3.5v4" /></Ico>,
    cog: (p) => <Ico {...p}><circle cx="12" cy="12" r="3.2" /><path d="M12 3.5v2.2M12 18.3v2.2M20.5 12h-2.2M5.7 12H3.5M18 6l-1.6 1.6M7.6 16.4 6 18M18 18l-1.6-1.6M7.6 7.6 6 6" /></Ico>,
    sync: (p) => <Ico {...p}><path d="M5 12a7 7 0 0 1 12-5l2 2M19 12a7 7 0 0 1-12 5l-2-2" /><path d="M19 4v5h-5M5 20v-5h5" /></Ico>,
    chart: (p) => <Ico {...p}><path d="M4 19V5M4 19h16" /><path d="M8 16l3.5-4 3 2.5L20 8" /></Ico>,
    apple: (p) => <Ico {...p}><path d="M16 13.5c0 3-2 5.5-3.4 5.5-.8 0-1.2-.5-2.1-.5s-1.4.5-2.2.5C6.8 19 5 16.2 5 13c0-3 1.8-4.5 3.3-4.5.9 0 1.6.5 2.2.5s1.2-.6 2.4-.6c1 0 2 .5 2.6 1.3-1.5 1-1.5 3.2.5 3.8Z" /><path d="M12.5 6.2c.6-.8.5-1.9.4-2.2-.8.1-1.6.6-2 1.2" /></Ico>,
    target: (p) => <Ico {...p}><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4" /><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" /></Ico>,
    leaf: (p) => <Ico {...p}><path d="M19 5c-8 0-13 3.5-13 10 0 0 0 0 0 0a1 1 0 0 0 1 1c6.5 0 12-5 12-11Z" /><path d="M6 18C9 13 13 9.5 17 7.5" /></Ico>,
    info: (p) => <Ico {...p}><circle cx="12" cy="12" r="8.5" /><path d="M12 11v5M12 7.8v.2" /></Ico>,
    play: (p) => <Ico {...p} fill="currentColor"><path d="M8 5.5v13l11-6.5-11-6.5Z" fill="currentColor" stroke="currentColor" /></Ico>,
    music: (p) => <Ico {...p}><circle cx="7" cy="17" r="2.5" /><circle cx="17" cy="15" r="2.5" /><path d="M9.5 17V6l10-2v11" /></Ico>,
    fork: (p) => <Ico {...p}><path d="M7 3v7a2 2 0 0 0 4 0V3M9 10v11M16 3c-1.5 0-2.5 2-2.5 5s1 4 2.5 4M16 3v18" /></Ico>,
    arrowUp: (p) => <Ico {...p}><path d="M12 19V5M6 11l6-6 6 6" /></Ico>,
    arrowDown: (p) => <Ico {...p}><path d="M12 5v14M6 13l6 6 6-6" /></Ico>,
  };

  window.VIcon = I;
})();
