// screens-recipe.jsx — recipe / meal detail with user-fillable photo slots.
(function () {
  const I = window.VIcon;
  const { Card, Button, Stepper, Segmented, ProgressBar } = window.V;
  const S = window.VitalStore;

  // recipe DB — keyed by id. Quantities are per 1 serving; stepper scales them.
  const RECIPES = {
    oats: {
      id: 'oats', name: 'Protein Oats & Berries', meal: 'Breakfast',
      kcal: 420, p: 32, c: 52, f: 9, fib: 8, mins: 8, level: 'Easy',
      blurb: 'A fast, high-protein start that keeps you full to lunch.',
      ingredients: [
        { q: 40, u: 'g', item: 'Rolled oats' },
        { q: 1, u: 'scoop', item: 'Whey protein, vanilla' },
        { q: 200, u: 'ml', item: 'Semi-skimmed milk' },
        { q: 80, u: 'g', item: 'Mixed berries' },
        { q: 1, u: 'tbsp', item: 'Almond butter' },
        { q: 1, u: 'pinch', item: 'Cinnamon' },
      ],
      steps: [
        'Combine oats and milk in a bowl and microwave for 2 minutes.',
        'Stir through the whey protein until smooth.',
        'Top with berries, a swirl of almond butter and a pinch of cinnamon.',
      ],
    },
    chickenbowl: {
      id: 'chickenbowl', name: 'Chicken & Quinoa Bowl', meal: 'Lunch',
      kcal: 540, p: 46, c: 52, f: 16, fib: 9, mins: 15, level: 'Easy',
      blurb: 'Balanced macros, meal-prep friendly, ready in 15.',
      ingredients: [
        { q: 150, u: 'g', item: 'Chicken breast' },
        { q: 80, u: 'g', item: 'Quinoa, dry' },
        { q: 100, u: 'g', item: 'Cherry tomatoes' },
        { q: 0.5, u: '', item: 'Avocado' },
        { q: 1, u: 'handful', item: 'Baby spinach' },
        { q: 1, u: 'tbsp', item: 'Olive oil' },
      ],
      steps: [
        'Rinse and simmer quinoa for 12 minutes, then fluff.',
        'Season and grill the chicken 4–5 min per side; slice.',
        'Build the bowl with quinoa, spinach, tomatoes and avocado.',
        'Dress with olive oil and a squeeze of lemon.',
      ],
    },
    salmon: {
      id: 'salmon', name: 'Salmon, Greens & Sweet Potato', meal: 'Dinner',
      kcal: 610, p: 44, c: 41, f: 27, fib: 9, mins: 22, level: 'Medium',
      blurb: 'Omega-3 rich and satisfying — a proper plate.',
      ingredients: [
        { q: 140, u: 'g', item: 'Salmon fillet' },
        { q: 200, u: 'g', item: 'Sweet potato' },
        { q: 100, u: 'g', item: 'Tenderstem broccoli' },
        { q: 100, u: 'g', item: 'Asparagus' },
        { q: 1, u: 'tbsp', item: 'Olive oil' },
        { q: 1, u: 'clove', item: 'Garlic' },
      ],
      steps: [
        'Cube the sweet potato, toss in oil, roast at 200°C for 20 min.',
        'Add salmon to the tray for the last 12 minutes.',
        'Steam the broccoli and asparagus until just tender.',
        'Plate up and finish with garlic and lemon.',
      ],
    },
    yogurt: {
      id: 'yogurt', name: 'Greek Yogurt & Almonds', meal: 'Snack',
      kcal: 250, p: 22, c: 14, f: 12, fib: 3, mins: 2, level: 'Easy',
      blurb: 'A two-minute, protein-dense snack.',
      ingredients: [
        { q: 170, u: 'g', item: 'Greek yogurt, 0%' },
        { q: 20, u: 'g', item: 'Almonds' },
        { q: 1, u: 'tsp', item: 'Honey' },
        { q: 1, u: 'handful', item: 'Berries' },
      ],
      steps: [
        'Spoon the yogurt into a bowl.',
        'Top with almonds, a drizzle of honey and berries.',
      ],
    },
  };

  function fmtQ(q) {
    if (q === 0.5) return '½';
    if (Number.isInteger(q)) return String(q);
    return (Math.round(q * 100) / 100).toString();
  }

  function Recipe({ params }) {
    window.useVital();
    const r = RECIPES[params.id] || RECIPES.chickenbowl;
    const [servings, setServings] = React.useState(1);
    const [fav, setFav] = React.useState(false);
    const sc = (v) => Math.round(v * servings);

    function logIt() {
      S.addFood({ meal: r.meal, name: r.name, brand: 'Vital recipe', qty: servings, unit: servings > 1 ? 'servings' : 'serving', kcal: sc(r.kcal), p: sc(r.p), c: sc(r.c), f: sc(r.f), fib: sc(r.fib), src: 'recipe', verified: true });
      S.resetStack();
      S.setTab('log');
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {/* hero photo slot */}
          <div style={{ position: 'relative', background: 'var(--surface2)' }}>
            <image-slot
              id={'recipe-hero-' + r.id}
              shape="rect"
              fit="cover"
              placeholder="Drop a food photo"
              style={{ display: 'block', width: '100%', height: '240px', color: '#9aa1ab' }}
            ></image-slot>
            {/* top controls over the photo */}
            <div style={{ position: 'absolute', top: 'var(--safe-top)', left: 14, right: 14, display: 'flex', justifyContent: 'space-between', pointerEvents: 'none' }}>
              <button onClick={() => S.pop()} style={{ ...glassBtn, pointerEvents: 'auto' }}><I.chevL size={20} /></button>
              <button onClick={() => setFav((f) => !f)} style={{ ...glassBtn, pointerEvents: 'auto', color: fav ? 'var(--accent)' : '#fff' }}>{fav ? <I.starFill size={19} /> : <I.star size={19} />}</button>
            </div>
            {/* gradient + title */}
            <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, padding: '40px 22px 16px', background: 'linear-gradient(to top, rgba(0,0,0,0.78), transparent)', pointerEvents: 'none' }}>
              <span style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1.2, color: 'var(--accent)' }}>{r.meal}</span>
              <h1 style={{ margin: '6px 0 0', fontSize: 26, fontWeight: 800, letterSpacing: -0.6, lineHeight: 1.08, color: '#fff', fontFamily: 'var(--font-display)' }}>{r.name}</h1>
            </div>
          </div>

          <div style={{ padding: '18px 22px 18px' }}>
            <p style={{ margin: '0 0 16px', fontSize: 14, color: 'var(--muted)', lineHeight: 1.5 }}>{r.blurb}</p>

            {/* meta chips */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 18 }}>
              <Meta icon={<I.clock size={16} />} label={r.mins + ' min'} />
              <Meta icon={<I.bolt size={16} />} label={r.level} />
              <Meta icon={<I.flame size={16} />} label={sc(r.kcal) + ' kcal'} />
            </div>

            {/* macros per current servings */}
            <Card style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
              <MacroCol k="Protein" v={sc(r.p)} c="var(--c-protein)" />
              <MacroCol k="Carbs" v={sc(r.c)} c="var(--c-carbs)" />
              <MacroCol k="Fat" v={sc(r.f)} c="var(--c-fat)" />
              <MacroCol k="Fiber" v={sc(r.fib)} c="var(--c-fiber)" />
            </Card>

            {/* servings */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 16, fontFamily: 'var(--font-display)' }}>Servings</div>
                <div style={{ fontSize: 12.5, color: 'var(--muted)', whiteSpace: 'nowrap' }}>Scales the ingredients</div>
              </div>
              <Stepper value={servings} onChange={setServings} step={1} min={1} max={8} />
            </div>

            {/* ingredients */}
            <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', margin: '6px 2px 12px' }}>Ingredients</div>
            <Card style={{ padding: 0, overflow: 'hidden', marginBottom: 20 }}>
              {r.ingredients.map((ing, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 16px', borderTop: i ? '1px solid var(--border)' : 'none' }}>
                  <div style={{ width: 8, height: 8, borderRadius: 999, background: 'var(--accent)', flexShrink: 0 }} />
                  <span style={{ flex: 1, fontSize: 14.5, fontWeight: 500 }}>{ing.item}</span>
                  <span style={{ fontSize: 13.5, color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{fmtQ(ing.q * servings)} {ing.u}</span>
                </div>
              ))}
            </Card>

            {/* method */}
            <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', margin: '6px 2px 12px' }}>Method</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {r.steps.map((st, i) => (
                <div key={i} style={{ display: 'flex', gap: 14 }}>
                  <div style={{ width: 30, height: 30, borderRadius: 999, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 14, flexShrink: 0, fontFamily: 'var(--font-display)' }}>{i + 1}</div>
                  <p style={{ margin: 0, fontSize: 14.5, lineHeight: 1.5, paddingTop: 4, color: 'var(--text)' }}>{st}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
          <Button full size="lg" onClick={logIt} icon={<I.plus size={20} sw={2.5} />}>Log to {r.meal} · {sc(r.kcal)} kcal</Button>
        </div>
      </div>
    );
  }

  function Meta({ icon, label }) {
    return (
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 13px', borderRadius: 12, background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)' }}>
        <span style={{ color: 'var(--muted)' }}>{icon}</span>
        <span style={{ fontSize: 13, fontWeight: 700, whiteSpace: 'nowrap' }}>{label}</span>
      </div>
    );
  }
  function MacroCol({ k, v, c }) {
    return (
      <div style={{ flex: 1, textAlign: 'center' }}>
        <div style={{ width: 26, height: 5, borderRadius: 99, background: c, margin: '0 auto 9px' }} />
        <div style={{ fontSize: 19, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.3, fontVariantNumeric: 'tabular-nums' }}>{v}<span style={{ fontSize: 11, color: 'var(--muted)' }}>g</span></div>
        <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 2 }}>{k}</div>
      </div>
    );
  }

  const glassBtn = {
    width: 38, height: 38, borderRadius: 999, border: 'none',
    background: 'rgba(0,0,0,0.42)', backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)',
    color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
  };

  window.VitalRecipes = RECIPES;
  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Recipe = Recipe;
})();
