// screens-workout.jsx — workout overview + in-gym player (set tracker + rest timer).
(function () {
  const I = window.VIcon;
  const { Card, Button, ProgressBar, Pill, MazeBg } = window.V;
  const S = window.VitalStore;

  const PLAN = {
    title: 'Upper Body • Push',
    meta: '5 exercises · ~48 min · 320 kcal',
    exercises: [
      { name: 'Barbell Bench Press', sets: 4, reps: '8–10', weight: '60 kg', rest: 90, muscle: 'Chest' },
      { name: 'Incline Dumbbell Press', sets: 3, reps: '10–12', weight: '22 kg', rest: 75, muscle: 'Upper chest' },
      { name: 'Overhead Press', sets: 3, reps: '8–10', weight: '40 kg', rest: 90, muscle: 'Shoulders' },
      { name: 'Cable Lateral Raise', sets: 3, reps: '12–15', weight: '7 kg', rest: 60, muscle: 'Side delts' },
      { name: 'Tricep Rope Pushdown', sets: 3, reps: '12–15', weight: '25 kg', rest: 60, muscle: 'Triceps' },
    ],
  };

  function WorkoutHome() {
    const s = window.useVital();
    const totalSets = PLAN.exercises.reduce((a, e) => a + e.sets, 0);
    const week = [
      { d: 'Mon', name: 'Upper • Push', done: true },
      { d: 'Tue', name: 'Lower • Quads', done: true },
      { d: 'Wed', name: 'Rest', rest: true },
      { d: 'Thu', name: 'Upper • Pull', done: true },
      { d: 'Fri', name: 'Upper • Push', today: true },
      { d: 'Sat', name: 'Lower • Posterior' },
      { d: 'Sun', name: 'Rest', rest: true },
    ];
    return (
      <div style={{ paddingBottom: 18 }}>
        <div style={{ padding: '6px 2px 16px' }}>
          <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>Train</h1>
          <div style={{ fontSize: 13.5, color: 'var(--muted)', marginTop: 2 }}>Week 3 · Push / Pull / Legs</div>
        </div>

        {/* today hero */}
        <Card accent style={{ position: 'relative', overflow: 'hidden', paddingTop: 20, paddingBottom: 20 }}>
          <MazeBg opacity={0.1} />
          <div style={{ position: 'relative' }}>
            <div style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1.5, opacity: 0.65 }}>Today</div>
            <div style={{ fontSize: 27, fontWeight: 800, letterSpacing: -0.6, marginTop: 6, fontFamily: 'var(--font-display)' }}>{PLAN.title}</div>
            <div style={{ fontSize: 13.5, opacity: 0.8, marginTop: 4, fontWeight: 600 }}>{PLAN.meta}</div>
            <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
              <button onClick={() => S.push('workoutPlayer', {})} style={{ flex: 1, height: 50, borderRadius: 14, border: 'none', background: 'var(--on-accent)', color: 'var(--accent)', fontWeight: 800, fontSize: 15.5, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                <I.play size={18} /> Start workout
              </button>
            </div>
          </div>
        </Card>

        {/* exercise list */}
        <div style={{ margin: '18px 2px 12px', fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>{PLAN.exercises.length} exercises · {totalSets} sets</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {PLAN.exercises.map((e, i) => (
            <Card key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14 }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', fontWeight: 800, fontFamily: 'var(--font-display)', flexShrink: 0 }}>{i + 1}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 14.5 }}>{e.name}</div>
                <div style={{ fontSize: 12.5, color: 'var(--muted)' }}>{e.sets} × {e.reps} · {e.weight}</div>
              </div>
              <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--accent)', background: 'var(--accent-soft)', padding: '4px 9px', borderRadius: 999 }}>{e.muscle}</span>
            </Card>
          ))}
        </div>

        {/* week strip */}
        <div style={{ margin: '22px 2px 12px', fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>This week</div>
        <div style={{ display: 'flex', gap: 7 }}>
          {week.map((w, i) => (
            <div key={i} style={{
              flex: 1, textAlign: 'center', padding: '12px 4px', borderRadius: 14,
              background: w.today ? 'var(--accent)' : 'var(--surface)', color: w.today ? 'var(--on-accent)' : 'var(--text)',
              border: w.today ? 'none' : '1px solid var(--border)',
            }}>
              <div style={{ fontSize: 10.5, fontWeight: 700, opacity: 0.7, textTransform: 'uppercase' }}>{w.d}</div>
              <div style={{ margin: '8px auto 0', width: 24, height: 24, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: w.done ? 'var(--accent-soft)' : w.today ? 'rgba(0,0,0,0.15)' : 'var(--surface2)',
                color: w.done ? 'var(--accent)' : 'inherit' }}>
                {w.done ? <I.check size={14} sw={3} /> : w.rest ? <span style={{ fontSize: 9, fontWeight: 700, opacity: 0.6 }}>—</span> : <I.dumbbell size={13} />}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ---------- PLAYER ----------
  function WorkoutPlayer() {
    window.useVital();
    const [exIndex, setExIndex] = React.useState(0);
    const [done, setDone] = React.useState(PLAN.exercises.map(() => 0)); // sets completed per exercise
    const [resting, setResting] = React.useState(false);
    const [restLeft, setRestLeft] = React.useState(0);
    const [finished, setFinished] = React.useState(false);
    const ex = PLAN.exercises[exIndex];
    const setsDone = done[exIndex];
    const totalDone = done.reduce((a, b) => a + b, 0);
    const totalSets = PLAN.exercises.reduce((a, e) => a + e.sets, 0);

    React.useEffect(() => {
      if (!resting) return;
      if (restLeft <= 0) { setResting(false); return; }
      const t = setTimeout(() => setRestLeft((r) => r - 1), 1000);
      return () => clearTimeout(t);
    }, [resting, restLeft]);

    function completeSet() {
      const newCount = Math.min(ex.sets, setsDone + 1);
      const nd = done.slice(); nd[exIndex] = newCount; setDone(nd);
      if (newCount < ex.sets) {
        setRestLeft(ex.rest); setResting(true);
      } else {
        // exercise complete → advance
        if (exIndex < PLAN.exercises.length - 1) {
          setTimeout(() => { setExIndex(exIndex + 1); setRestLeft(PLAN.exercises[exIndex + 1].rest); setResting(true); }, 250);
        } else {
          setFinished(true);
        }
      }
    }

    if (finished) {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--accent)', color: 'var(--on-accent)', position: 'relative', overflow: 'hidden' }}>
          <MazeBg opacity={0.1} />
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: 30, position: 'relative' }}>
            <div style={{ width: 88, height: 88, borderRadius: 999, background: 'rgba(0,0,0,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 22 }}>
              <I.check size={46} sw={3} />
            </div>
            <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, opacity: 0.7 }}>Workout complete</div>
            <h1 style={{ fontSize: 34, fontWeight: 800, letterSpacing: -1, margin: '10px 0 4px', fontFamily: 'var(--font-display)' }}>Nice work.</h1>
            <p style={{ fontSize: 15, opacity: 0.82, margin: '0 0 30px', fontWeight: 600 }}>{totalSets} sets · ~48 min · 320 kcal burned</p>
            <div style={{ display: 'flex', gap: 28, marginBottom: 36 }}>
              <Stat big label="Sets" value={totalSets} />
              <Stat big label="Volume" value="6.4t" />
              <Stat big label="kcal" value="320" />
            </div>
          </div>
          <div style={{ padding: '0 22px calc(var(--safe-bottom) + 16px)', position: 'relative' }}>
            <button onClick={() => { S.pop(); S.toast('Workout logged'); }} style={{ width: '100%', height: 54, borderRadius: 14, border: 'none', background: 'var(--on-accent)', color: 'var(--accent)', fontWeight: 800, fontSize: 16, fontFamily: 'inherit', cursor: 'pointer' }}>Done</button>
          </div>
        </div>
      );
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        {/* top bar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 'var(--safe-top) 18px 10px' }}>
          <button onClick={() => S.pop()} style={{ width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><I.x size={20} /></button>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', marginBottom: 5 }}>
              <span>Exercise {exIndex + 1} of {PLAN.exercises.length}</span>
              <span>{totalDone}/{totalSets} sets</span>
            </div>
            <ProgressBar value={totalDone} max={totalSets} height={6} />
          </div>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '14px 22px 18px' }}>
          <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: 1 }}>{ex.muscle}</div>
          <h1 style={{ margin: '6px 0 4px', fontSize: 28, fontWeight: 800, letterSpacing: -0.8, lineHeight: 1.05, fontFamily: 'var(--font-display)' }}>{ex.name}</h1>
          <div style={{ fontSize: 14.5, color: 'var(--muted)', fontWeight: 600 }}>Target: {ex.reps} reps · {ex.weight}</div>

          {/* rest timer OR set tracker */}
          {resting ? (
            <Card style={{ marginTop: 20, textAlign: 'center', paddingTop: 28, paddingBottom: 28 }}>
              <RestRing total={ex.rest} left={restLeft} />
              <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginTop: 22 }}>
                <button onClick={() => setRestLeft((r) => r + 15)} style={restBtn}>+15s</button>
                <button onClick={() => { setResting(false); setRestLeft(0); }} style={{ ...restBtn, background: 'var(--accent)', color: 'var(--on-accent)', border: 'none' }}>Skip rest</button>
              </div>
            </Card>
          ) : (
            <div style={{ marginTop: 20 }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {Array.from({ length: ex.sets }).map((_, i) => {
                  const isDone = i < setsDone;
                  const isCurrent = i === setsDone;
                  return (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', borderRadius: 16,
                      background: isCurrent ? 'var(--accent-soft)' : 'var(--surface)',
                      border: isCurrent ? '1.5px solid var(--accent)' : '1px solid var(--border)',
                      opacity: isDone ? 0.55 : 1,
                    }}>
                      <div style={{ width: 30, height: 30, borderRadius: 999, background: isDone ? 'var(--accent)' : 'var(--surface2)', color: isDone ? 'var(--on-accent)' : 'var(--muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13, flexShrink: 0 }}>
                        {isDone ? <I.check size={15} sw={3} /> : i + 1}
                      </div>
                      <div style={{ flex: 1, fontSize: 14, fontWeight: 600 }}>Set {i + 1}</div>
                      <div style={{ fontSize: 13, color: 'var(--muted)', fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{ex.reps} × {ex.weight}</div>
                    </div>
                  );
                })}
              </div>
              <button onClick={completeSet} style={{ width: '100%', marginTop: 16, height: 56, borderRadius: 16, border: 'none', background: 'var(--accent)', color: 'var(--on-accent)', fontWeight: 800, fontSize: 16.5, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, whiteSpace: 'nowrap' }}>
                <I.check size={22} sw={2.8} /> Complete set {setsDone + 1}
              </button>
            </div>
          )}
        </div>

        {/* exercise nav */}
        <div style={{ display: 'flex', gap: 10, padding: '12px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
          <button onClick={() => { setExIndex(Math.max(0, exIndex - 1)); setResting(false); }} disabled={exIndex === 0} style={{ ...navBtn, opacity: exIndex === 0 ? 0.4 : 1 }}><I.chevL size={18} /> Prev</button>
          <button onClick={() => { if (exIndex < PLAN.exercises.length - 1) { setExIndex(exIndex + 1); setResting(false); } }} disabled={exIndex === PLAN.exercises.length - 1} style={{ ...navBtn, opacity: exIndex === PLAN.exercises.length - 1 ? 0.4 : 1 }}>Skip <I.chevR size={18} /></button>
        </div>
      </div>
    );
  }

  function RestRing({ total, left }) {
    const size = 168, sw = 12, r = (size - sw) / 2, C = 2 * Math.PI * r;
    const pct = left / total;
    const mm = Math.floor(left / 60), ss = left % 60;
    return (
      <div style={{ position: 'relative', width: size, height: size, margin: '0 auto' }}>
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--track)" strokeWidth={sw} />
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--accent)" strokeWidth={sw} strokeLinecap="round"
            strokeDasharray={C} strokeDashoffset={C * (1 - pct)} style={{ transition: 'stroke-dashoffset 1s linear' }} />
        </svg>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1.5 }}>Rest</div>
          <div style={{ fontSize: 44, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -1, fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>{mm}:{ss.toString().padStart(2, '0')}</div>
        </div>
      </div>
    );
  }

  function Stat({ label, value, big }) {
    return (
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: big ? 30 : 20, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5 }}>{value}</div>
        <div style={{ fontSize: 11, fontWeight: 700, opacity: 0.7, textTransform: 'uppercase', letterSpacing: 0.8, marginTop: 2 }}>{label}</div>
      </div>
    );
  }

  const restBtn = { padding: '11px 20px', borderRadius: 12, border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)', fontWeight: 700, fontSize: 13.5, fontFamily: 'inherit', cursor: 'pointer' };
  const navBtn = { flex: 1, height: 46, borderRadius: 12, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', fontWeight: 700, fontSize: 14, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 };

  window.VitalScreens = window.VitalScreens || {};
  Object.assign(window.VitalScreens, { WorkoutHome, WorkoutPlayer });
})();
