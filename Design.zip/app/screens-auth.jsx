// screens-auth.jsx — Welcome → Sign in / Sign up / Forgot password.
(function () {
  const I = window.VIcon;
  const { Button, MazeBg } = window.V;
  const S = window.VitalStore;

  const inputStyle = {
    width: '100%', boxSizing: 'border-box', height: 52, padding: '0 16px', borderRadius: 14,
    border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)',
    fontSize: 16, fontFamily: 'inherit', outline: 'none', fontWeight: 600,
  };

  function Labeled({ label, children }) {
    return (
      <div>
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 9 }}>{label}</div>
        {children}
      </div>
    );
  }

  function Social({ label, icon }) {
    return (
      <button onClick={() => S.toast('Continuing with ' + label)} style={{
        flex: 1, height: 50, borderRadius: 14, border: '1px solid var(--border)', background: 'var(--surface)',
        color: 'var(--text)', fontWeight: 700, fontSize: 14, fontFamily: 'inherit', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9,
      }}>{icon}{label}</button>
    );
  }

  function AuthHeader({ onBack, title, sub }) {
    return (
      <div style={{ padding: 'var(--safe-top) 24px 0' }}>
        {onBack && <button onClick={onBack} style={{ width: 40, height: 40, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', marginBottom: 18 }}><I.chevL size={20} /></button>}
        <h1 style={{ margin: 0, fontSize: 30, fontWeight: 800, letterSpacing: -1, lineHeight: 1.05, fontFamily: 'var(--font-display)' }}>{title}</h1>
        {sub && <p style={{ margin: '8px 0 0', fontSize: 15, color: 'var(--muted)', lineHeight: 1.4 }}>{sub}</p>}
      </div>
    );
  }

  const APPLE = <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M16 13.5c0 3-2 5.5-3.4 5.5-.8 0-1.2-.5-2.1-.5s-1.4.5-2.2.5C6.8 19 5 16.2 5 13c0-3 1.8-4.5 3.3-4.5.9 0 1.6.5 2.2.5s1.2-.6 2.4-.6c1 0 2 .5 2.6 1.3-1.5 1-1.5 3.2.5 3.8ZM12.9 6.2c.6-.8.5-1.9.4-2.2-.8.1-1.6.6-2 1.2-.4.5-.7 1.3-.6 2 .8.1 1.6-.3 2.2-1Z"/></svg>;
  const GOOG = <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#4285F4" d="M21.6 12.2c0-.6-.1-1.2-.2-1.8H12v3.6h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3Z"/><path fill="#34A853" d="M12 22c2.7 0 5-.9 6.6-2.5l-3.2-2.5c-.9.6-2 .9-3.4.9-2.6 0-4.8-1.7-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.4 13.8a6 6 0 0 1 0-3.6V7.6H3.1a10 10 0 0 0 0 8.8l3.3-2.6Z"/><path fill="#EA4335" d="M12 6.1c1.5 0 2.8.5 3.8 1.5l2.8-2.8A10 10 0 0 0 3.1 7.6l3.3 2.6C7.2 7.8 9.4 6.1 12 6.1Z"/></svg>;

  function Auth({ onApp, onSignup }) {
    window.useVital();
    const [view, setView] = React.useState('welcome'); // welcome | signin | signup | forgot
    const [email, setEmail] = React.useState('');
    const [pw, setPw] = React.useState('');
    const [name, setName] = React.useState('');
    const scrollRef = React.useRef(null);
    React.useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, [view]);

    // ---------- WELCOME ----------
    if (view === 'welcome') {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', padding: '0 28px 36px' }}>
            <MazeBg opacity={0.1} />
            <div style={{ position: 'absolute', top: 'calc(var(--safe-top) + 8px)', left: 28, display: 'flex', alignItems: 'center', gap: 11 }}>
              <div style={{ width: 38, height: 38, borderRadius: 11, background: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 13h4l2.5 6 3-14 2.5 8H20" /></svg>
              </div>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, letterSpacing: -0.5 }}>Vital</span>
            </div>
            <div style={{ position: 'relative' }}>
              <h1 style={{ margin: 0, fontSize: 40, fontWeight: 800, letterSpacing: -1.6, lineHeight: 0.98, fontFamily: 'var(--font-display)' }}>Train smarter.<br />Eat better.</h1>
              <p style={{ margin: '14px 0 0', fontSize: 16, fontWeight: 600, opacity: 0.78, maxWidth: 300, lineHeight: 1.4 }}>Your calories, macros and workouts — one science-backed app.</p>
            </div>
          </div>
          <div style={{ padding: '22px 24px calc(var(--safe-bottom) + 14px)', background: 'var(--bg)', display: 'flex', flexDirection: 'column', gap: 11 }}>
            <Button full size="lg" onClick={() => setView('signup')}>Get started — it’s free</Button>
            <button onClick={() => setView('signin')} style={{ height: 50, borderRadius: 14, border: 'none', background: 'transparent', color: 'var(--text)', fontWeight: 700, fontSize: 15, fontFamily: 'inherit', cursor: 'pointer' }}>
              I already have an account
            </button>
          </div>
        </div>
      );
    }

    // ---------- SIGN IN ----------
    if (view === 'signin') {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <AuthHeader onBack={() => setView('welcome')} title="Welcome back" sub="Pick up right where you left off." />
          <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '26px 24px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
            <Labeled label="Email"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" style={inputStyle} /></Labeled>
            <Labeled label="Password"><input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="••••••••" style={inputStyle} /></Labeled>
            <div style={{ textAlign: 'right', marginTop: -6 }}>
              <span onClick={() => setView('forgot')} style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--accent)', cursor: 'pointer' }}>Forgot password?</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '4px 0' }}>
              <div style={{ flex: 1, height: 1, background: 'var(--border)' }} /><span style={{ fontSize: 12, color: 'var(--faint)', fontWeight: 600 }}>or</span><div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}><Social label="Apple" icon={APPLE} /><Social label="Google" icon={GOOG} /></div>
          </div>
          <div style={{ padding: '14px 24px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)' }}>
            <Button full size="lg" onClick={() => { S.toast('Signed in'); onApp(); }}>Sign in</Button>
          </div>
        </div>
      );
    }

    // ---------- SIGN UP ----------
    if (view === 'signup') {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <AuthHeader onBack={() => setView('welcome')} title="Create account" sub="Two minutes to your personalised plan." />
          <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '26px 24px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
            <Labeled label="Name"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" style={inputStyle} /></Labeled>
            <Labeled label="Email"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" style={inputStyle} /></Labeled>
            <Labeled label="Password"><input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="At least 8 characters" style={inputStyle} /></Labeled>
            <div style={{ display: 'flex', gap: 10, marginTop: 2 }}><Social label="Apple" icon={APPLE} /><Social label="Google" icon={GOOG} /></div>
            <p style={{ fontSize: 11.5, color: 'var(--faint)', lineHeight: 1.5, margin: '2px 4px 0', textAlign: 'center' }}>By continuing you agree to our Terms and Privacy Policy.</p>
          </div>
          <div style={{ padding: '14px 24px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)' }}>
            <Button full size="lg" onClick={() => { if (name) S.applyOnboarding({ name }); onSignup(); }}>Create account</Button>
          </div>
        </div>
      );
    }

    // ---------- FORGOT ----------
    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <AuthHeader onBack={() => setView('signin')} title="Reset password" sub="We’ll email you a secure reset link." />
        <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '26px 24px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
          <Labeled label="Email"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" style={inputStyle} /></Labeled>
        </div>
        <div style={{ padding: '14px 24px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)' }}>
          <Button full size="lg" onClick={() => { S.toast('Reset link sent'); setView('signin'); }}>Send reset link</Button>
        </div>
      </div>
    );
  }

  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Auth = Auth;
})();
