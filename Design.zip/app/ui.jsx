// ui.jsx — Vital UI primitives. Theme via CSS vars set on the app root.
// Exposes window.V (components) and window.VTheme (theme builder).
(function () {
  const I = window.VIcon;

  // ---------- theme ----------
  const ACCENTS = {
    lime:   { accent: '#C8F751', on: '#0B0C0E' },
    blue:   { accent: '#4D8DFF', on: '#FFFFFF' },
    coral:  { accent: '#FF6A4D', on: '#1A0B07' },
    violet: { accent: '#A47BFF', on: '#FFFFFF' },
  };
  function buildTheme(accentKey, dark) {
    const a = ACCENTS[accentKey] || ACCENTS.lime;
    const accentDim = a.accent.replace(')', '') ; // not used
    if (dark) {
      return {
        '--bg': '#0B0C0E', '--surface': '#15171B', '--surface2': '#1D2026',
        '--border': 'rgba(255,255,255,0.08)', '--text': '#F3F5F4',
        '--muted': '#9AA0A8', '--faint': '#5C626B',
        '--accent': a.accent, '--on-accent': a.on,
        '--accent-soft': hexA(a.accent, 0.14),
        '--c-protein': a.accent, '--c-carbs': '#5EC8FF', '--c-fat': '#FFB259', '--c-fiber': '#B69CFF',
        '--track': 'rgba(255,255,255,0.09)',
        '--shadow': '0 12px 30px rgba(0,0,0,0.45)',
      };
    }
    return {
      '--bg': '#EFF1EC', '--surface': '#FFFFFF', '--surface2': '#F4F6F1',
      '--border': 'rgba(15,18,20,0.09)', '--text': '#14171A',
      '--muted': '#5C636B', '--faint': '#9AA1A9',
      '--accent': a.accent, '--on-accent': a.on,
      '--accent-soft': hexA(a.accent, 0.20),
      '--c-protein': darken(a.accent), '--c-carbs': '#1F93D6', '--c-fat': '#E0892A', '--c-fiber': '#8B5CF6',
      '--track': 'rgba(15,18,20,0.08)',
      '--shadow': '0 12px 30px rgba(15,18,20,0.10)',
    };
  }
  function hexA(hex, a) {
    const h = hex.replace('#', '');
    const n = parseInt(h.length === 3 ? h.split('').map(x => x + x).join('') : h, 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  }
  function darken(hex) {
    const h = hex.replace('#', '');
    const n = parseInt(h, 16);
    const r = Math.round(((n >> 16) & 255) * 0.7), g = Math.round(((n >> 8) & 255) * 0.7), b = Math.round((n & 255) * 0.7);
    return `rgb(${r},${g},${b})`;
  }
  const DENSITY = {
    compact: { pad: 13, gap: 10, radius: 18 },
    regular: { pad: 16, gap: 14, radius: 22 },
    comfy:   { pad: 20, gap: 18, radius: 26 },
  };

  // ---------- Card ----------
  function Card({ children, style = {}, pad, onClick, accent }) {
    return (
      <div onClick={onClick} style={{
        background: accent ? 'var(--accent)' : 'var(--surface)',
        color: accent ? 'var(--on-accent)' : 'var(--text)',
        border: accent ? 'none' : '1px solid var(--border)',
        borderRadius: 'var(--radius)',
        padding: pad != null ? pad : 'var(--pad)',
        boxSizing: 'border-box',
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}>{children}</div>
    );
  }

  // ---------- Pill / chip ----------
  function Pill({ label, value, tone = 'neutral', icon, onClick, active }) {
    const tones = {
      neutral: { bg: 'var(--surface2)', fg: 'var(--text)' },
      accent: { bg: 'var(--accent)', fg: 'var(--on-accent)' },
      soft: { bg: 'var(--accent-soft)', fg: 'var(--accent)' },
      ghost: { bg: 'transparent', fg: 'var(--muted)' },
    };
    const tn = active ? tones.accent : (tones[tone] || tones.neutral);
    return (
      <div onClick={onClick} style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '7px 12px', borderRadius: 999, background: tn.bg, color: tn.fg,
        fontSize: 12.5, fontWeight: 600, whiteSpace: 'nowrap',
        border: tone === 'ghost' && !active ? '1px solid var(--border)' : 'none',
        cursor: onClick ? 'pointer' : 'default', letterSpacing: 0.1,
      }}>
        {icon}
        {label && <span style={{ opacity: value ? 0.62 : 1 }}>{label}</span>}
        {value != null && <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{value}</span>}
      </div>
    );
  }

  // ---------- Button ----------
  function Button({ children, onClick, variant = 'primary', size = 'lg', full, icon, style = {} }) {
    const variants = {
      primary: { bg: 'var(--accent)', fg: 'var(--on-accent)', bd: 'none' },
      dark: { bg: 'var(--surface2)', fg: 'var(--text)', bd: '1px solid var(--border)' },
      ghost: { bg: 'transparent', fg: 'var(--text)', bd: '1px solid var(--border)' },
    };
    const v = variants[variant] || variants.primary;
    const sz = size === 'sm' ? { h: 38, fs: 13, px: 14 } : size === 'md' ? { h: 46, fs: 14.5, px: 18 } : { h: 54, fs: 16, px: 22 };
    return (
      <button onClick={onClick} style={{
        height: sz.h, padding: `0 ${sz.px}px`, borderRadius: 14,
        background: v.bg, color: v.fg, border: v.bd,
        fontSize: sz.fs, fontWeight: 700, fontFamily: 'inherit', letterSpacing: 0.2,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8, whiteSpace: 'nowrap',
        width: full ? '100%' : undefined, cursor: 'pointer', ...style,
      }}>{icon}{children}</button>
    );
  }

  // ---------- Stepper ----------
  function Stepper({ value, onChange, step = 1, unit = '', min = 0, max = 9999, big }) {
    const btn = (dir) => (
      <button onClick={() => onChange(Math.min(max, Math.max(min, +(value + dir * step).toFixed(2))))}
        style={{
          width: big ? 46 : 34, height: big ? 46 : 34, borderRadius: 999,
          border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
        }}>
        {dir > 0 ? <I.plus size={big ? 22 : 18} /> : <I.minus size={big ? 22 : 18} />}
      </button>
    );
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: big ? 16 : 10 }}>
        {btn(-1)}
        <div style={{ minWidth: big ? 84 : 56, textAlign: 'center', fontWeight: 800, fontSize: big ? 30 : 17, fontVariantNumeric: 'tabular-nums' }}>
          {value}{unit && <span style={{ fontSize: big ? 15 : 12, color: 'var(--muted)', marginLeft: 3 }}>{unit}</span>}
        </div>
        {btn(1)}
      </div>
    );
  }

  // ---------- Segmented control ----------
  function Segmented({ options, value, onChange, full }) {
    return (
      <div style={{
        display: 'flex', gap: 4, padding: 4, background: 'var(--surface2)',
        borderRadius: 13, width: full ? '100%' : undefined,
      }}>
        {options.map((o) => {
          const val = typeof o === 'string' ? o : o.value;
          const lbl = typeof o === 'string' ? o : o.label;
          const on = val === value;
          return (
            <button key={val} onClick={() => onChange(val)} style={{
              flex: full ? 1 : undefined, padding: '8px 13px', borderRadius: 10, border: 'none',
              background: on ? 'var(--accent)' : 'transparent', color: on ? 'var(--on-accent)' : 'var(--muted)',
              fontWeight: 700, fontSize: 13, fontFamily: 'inherit', cursor: 'pointer', whiteSpace: 'nowrap',
              transition: 'all .15s',
            }}>{lbl}</button>
          );
        })}
      </div>
    );
  }

  // ---------- Linear progress ----------
  function ProgressBar({ value, max, color = 'var(--accent)', height = 8, track = 'var(--track)' }) {
    const pct = Math.max(0, Math.min(100, (value / max) * 100));
    return (
      <div style={{ height, background: track, borderRadius: 999, overflow: 'hidden' }}>
        <div style={{ width: pct + '%', height: '100%', background: color, borderRadius: 999, transition: 'width .5s cubic-bezier(.4,0,.2,1)' }} />
      </div>
    );
  }

  // ---------- Macro bars ----------
  function MacroBars({ totals, targets, compact }) {
    const rows = [
      { k: 'Protein', v: totals.p, t: targets.proteinG, c: 'var(--c-protein)' },
      { k: 'Carbs', v: totals.c, t: targets.carbsG, c: 'var(--c-carbs)' },
      { k: 'Fat', v: totals.f, t: targets.fatG, c: 'var(--c-fat)' },
      { k: 'Fiber', v: totals.fib, t: targets.fiberG, c: 'var(--c-fiber)' },
    ];
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: compact ? 9 : 13 }}>
        {rows.map((r) => (
          <div key={r.k}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 5 }}>
              <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text)' }}>{r.k}</span>
              <span style={{ fontSize: 12, color: 'var(--muted)', fontVariantNumeric: 'tabular-nums' }}>
                <b style={{ color: 'var(--text)' }}>{Math.round(r.v)}</b> / {r.t} g
                <span style={{ color: 'var(--faint)', marginLeft: 6 }}>{Math.round((r.v / r.t) * 100)}%</span>
              </span>
            </div>
            <ProgressBar value={r.v} max={r.t} color={r.c} height={compact ? 6 : 8} />
          </div>
        ))}
      </div>
    );
  }

  // ---------- Calorie hero (4 metaphors) ----------
  function CalorieHero({ consumed, budget, burned, metaphor = 'ring', size = 200 }) {
    const remaining = Math.round(budget - consumed + burned);
    const pct = Math.max(0, Math.min(1, consumed / budget));
    const center = (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', lineHeight: 1 }}>
        <div style={{ fontSize: size * 0.235, fontWeight: 800, fontVariantNumeric: 'tabular-nums', letterSpacing: -1, fontFamily: 'var(--font-display)' }}>
          {remaining < 0 ? '+' + Math.abs(remaining) : remaining}
        </div>
        <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1.5, marginTop: 5 }}>
          {remaining < 0 ? 'over' : 'kcal left'}
        </div>
      </div>
    );

    if (metaphor === 'ring' || metaphor === 'arc') {
      const arc = metaphor === 'arc';
      const stroke = size * 0.085;
      const r = (size - stroke) / 2;
      const circ = 2 * Math.PI * r;
      const span = arc ? 0.75 : 1;            // arc covers 270°
      const dash = circ * span;
      const filled = dash * pct;
      const rot = arc ? 135 : -90;
      return (
        <div style={{ position: 'relative', width: size, height: arc ? size * 0.86 : size }}>
          <svg width={size} height={size} style={{ transform: `rotate(${rot}deg)`, display: 'block' }}>
            <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--track)" strokeWidth={stroke}
              strokeDasharray={`${dash} ${circ}`} strokeLinecap="round" />
            <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--accent)" strokeWidth={stroke}
              strokeDasharray={`${filled} ${circ}`} strokeLinecap="round"
              style={{ transition: 'stroke-dasharray .7s cubic-bezier(.4,0,.2,1)' }} />
          </svg>
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: arc ? '14%' : 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {center}
          </div>
        </div>
      );
    }

    if (metaphor === 'battery') {
      const cells = 12, lit = Math.round(pct * cells);
      return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
          {center}
          <div style={{ display: 'flex', gap: 4, width: size * 0.92 }}>
            {Array.from({ length: cells }).map((_, i) => (
              <div key={i} style={{ flex: 1, height: 22, borderRadius: 4, background: i < lit ? 'var(--accent)' : 'var(--track)', transition: 'background .3s' }} />
            ))}
          </div>
        </div>
      );
    }

    // bar
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18, width: '100%' }}>
        {center}
        <div style={{ width: '100%' }}>
          <div style={{ height: 18, borderRadius: 999, background: 'var(--track)', overflow: 'hidden' }}>
            <div style={{ width: pct * 100 + '%', height: '100%', background: 'var(--accent)', borderRadius: 999, transition: 'width .6s' }} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, fontSize: 11.5, color: 'var(--muted)', fontWeight: 600 }}>
            <span>{consumed} eaten</span><span>{budget} goal</span>
          </div>
        </div>
      </div>
    );
  }

  // ---------- Weekly bar chart ----------
  function BarChart({ data, labels, color = 'var(--accent)', height = 80, goalRatio }) {
    const max = Math.max(...data, 1);
    return (
      <div>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 7, height }}>
          {data.map((v, i) => (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: '100%' }}>
              <div style={{ height: (v / max) * 100 + '%', background: i === data.length - 1 ? color : 'var(--track)', borderRadius: 5, minHeight: 4, transition: 'height .5s' }} />
            </div>
          ))}
        </div>
        {labels && (
          <div style={{ display: 'flex', gap: 7, marginTop: 7 }}>
            {labels.map((l, i) => <div key={i} style={{ flex: 1, textAlign: 'center', fontSize: 10.5, color: 'var(--faint)', fontWeight: 600 }}>{l}</div>)}
          </div>
        )}
      </div>
    );
  }

  // ---------- Sparkline / trend ----------
  function Sparkline({ points, width = 260, height = 70, color = 'var(--accent)', goal }) {
    const xs = points.map((p) => p.kg ?? p);
    const min = Math.min(...xs) - 0.4, max = Math.max(...xs) + 0.4;
    const px = (i) => (i / (points.length - 1)) * width;
    const py = (v) => height - ((v - min) / (max - min)) * height;
    const d = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${px(i).toFixed(1)} ${py(p.kg ?? p).toFixed(1)}`).join(' ');
    const area = d + ` L ${width} ${height} L 0 ${height} Z`;
    const gid = 'sg' + Math.round(width);
    return (
      <svg width="100%" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ display: 'block', overflow: 'visible' }}>
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.28" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {goal != null && <line x1="0" y1={py(goal)} x2={width} y2={py(goal)} stroke="var(--faint)" strokeWidth="1" strokeDasharray="4 4" />}
        <path d={area} fill={`url(#${gid})`} />
        <path d={d} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        {points.map((p, i) => i === points.length - 1 && (
          <circle key={i} cx={px(i)} cy={py(p.kg ?? p)} r="4" fill={color} stroke="var(--surface)" strokeWidth="2" />
        ))}
      </svg>
    );
  }

  // ---------- Section header ----------
  function SectionHeader({ title, action, onAction }) {
    return (
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <h3 style={{ margin: 0, fontSize: 17, fontWeight: 800, letterSpacing: -0.3, fontFamily: 'var(--font-display)' }}>{title}</h3>
        {action && <span onClick={onAction} style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)', cursor: 'pointer' }}>{action}</span>}
      </div>
    );
  }

  // ---------- Maze texture (brand element) ----------
  function MazeBg({ opacity = 0.06, color = 'var(--on-accent)' }) {
    return (
      <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0, opacity, pointerEvents: 'none' }} preserveAspectRatio="xMidYMid slice">
        <pattern id="maze" width="44" height="44" patternUnits="userSpaceOnUse">
          <path d="M0 11h22v22h22M11 0v22h22M0 33h11v11" fill="none" stroke={color} strokeWidth="2.5" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#maze)" />
      </svg>
    );
  }

  // ---------- Disclaimer ----------
  function Disclaimer({ text }) {
    return (
      <div style={{ display: 'flex', gap: 8, padding: '0 4px', marginTop: 4 }}>
        <I.info size={14} style={{ color: 'var(--faint)', flexShrink: 0, marginTop: 1 }} />
        <p style={{ margin: 0, fontSize: 10.5, lineHeight: 1.45, color: 'var(--faint)' }}>
          {text || 'Estimates only — not medical advice. Consult a professional before changing your nutrition or training.'}
        </p>
      </div>
    );
  }

  window.VTheme = { buildTheme, DENSITY, ACCENTS };
  window.V = { Card, Pill, Button, Stepper, Segmented, ProgressBar, MacroBars, CalorieHero, BarChart, Sparkline, SectionHeader, MazeBg, Disclaimer };
})();
