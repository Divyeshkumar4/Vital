// app/bundle.jsx — concatenated app modules (single Babel compile)

/* ===== app/store.jsx ===== */
// store.jsx — shared external store for Vital (nav + app data), synced across both device frames.
// Tweaks (appearance) live separately on the page root and are passed in as props.

(function () {
  // ---------- Nutrition math (real, Mifflin–St Jeor) ----------
  function computeTargets(p) {
    // p: { sex, age, heightCm, weightKg, activity, goal, rateKgWk }
    const bmr = p.sex === 'female'
      ? 10 * p.weightKg + 6.25 * p.heightCm - 5 * p.age - 161
      : 10 * p.weightKg + 6.25 * p.heightCm - 5 * p.age + 5;
    const actMult = { sedentary: 1.2, light: 1.375, moderate: 1.55, very: 1.725, extra: 1.9 }[p.activity] || 1.375;
    const tdee = Math.round(bmr * actMult);
    // goal adjust: ~7700 kcal per kg → daily delta from weekly rate
    const rate = p.goal === 'maintain' ? 0 : (p.rateKgWk || 0.5);
    let delta = Math.round((rate * 7700) / 7);
    if (p.goal === 'lose') delta = -delta;
    if (p.goal === 'gain') delta = +delta;
    if (p.goal === 'maintain') delta = 0;
    // safety clamp: don't go below ~1200 (f) / 1500 (m) or cut >25% of TDEE
    let budget = tdee + delta;
    const floor = p.sex === 'female' ? 1200 : 1500;
    let clamped = false;
    if (budget < Math.max(floor, tdee * 0.75)) { budget = Math.round(Math.max(floor, tdee * 0.75)); clamped = true; }
    budget = Math.round(budget / 10) * 10;
    // macros
    const proteinG = Math.round(p.weightKg * 1.8);
    const fatG = Math.round((budget * 0.27) / 9);
    const carbsG = Math.max(0, Math.round((budget - proteinG * 4 - fatG * 9) / 4));
    const fiberG = Math.round((budget / 1000) * 14);
    const bmi = +(p.weightKg / Math.pow(p.heightCm / 100, 2)).toFixed(1);
    return { bmr: Math.round(bmr), tdee, budget, proteinG, carbsG, fatG, fiberG, bmi, clamped };
  }

  const onboarding = {
    name: 'Alex', age: 29, sex: 'male',
    units: 'metric',
    heightCm: 178, weightKg: 76,
    activity: 'moderate', goal: 'lose', rateKgWk: 0.5,
    targetWeightKg: 70, bodyFat: null,
    persona: 'general', diet: 'omnivore', eatsEggs: true,
    region: 'United States', currency: 'USD',
  };

  const targets = computeTargets(onboarding);

  // Seed a partial day of food so Home/Log look alive
  const seedDiary = [
    { id: 1, meal: 'Breakfast', name: 'Greek Yogurt & Berries', brand: 'Chobani', qty: 1, unit: 'bowl', kcal: 240, p: 20, c: 28, f: 6, fib: 4, src: 'branded', verified: true },
    { id: 2, meal: 'Breakfast', name: 'Black Coffee', brand: '', qty: 1, unit: 'cup', kcal: 5, p: 0, c: 1, f: 0, fib: 0, src: 'common', verified: true },
    { id: 3, meal: 'Lunch', name: 'Grilled Chicken Bowl', brand: '', qty: 1, unit: 'bowl', kcal: 540, p: 46, c: 52, f: 16, fib: 9, src: 'common', verified: true },
    { id: 4, meal: 'Snack', name: 'Almonds', brand: '', qty: 28, unit: 'g', kcal: 164, p: 6, c: 6, f: 14, fib: 4, src: 'common', verified: true },
  ];

  const initial = {
    mode: 'app',               // 'app' | 'auth' | 'onboarding'
    onboarded: true,           // start in-app; "Replay onboarding" available from Profile
    onboarding,
    targets,
    nav: { tab: 'home', stack: [] },   // stack of { screen, params }
    diary: seedDiary,
    nextId: 100,
    waterMl: 1000,
    waterGoalMl: 2500,
    weightLog: [
      { d: '05-08', kg: 78.2 }, { d: '05-12', kg: 77.6 }, { d: '05-16', kg: 77.4 },
      { d: '05-20', kg: 76.9 }, { d: '05-24', kg: 76.5 }, { d: '05-29', kg: 76.0 },
    ],
    streak: 12,
    burnedKcal: 320,           // exercise + steps
    steps: 7240,
    workout: {
      title: 'Upper Body • Push',
      restDay: false,
      exIndex: 0,
      // sets done count per exercise
      progress: [0, 0, 0, 0],
      resting: false,
      restLeft: 0,
    },
    toast: null,
    paywall: false,
  };

  let state = initial;
  const listeners = new Set();
  function getState() { return state; }
  function setState(updater) {
    state = typeof updater === 'function' ? updater(state) : { ...state, ...updater };
    listeners.forEach((l) => l());
  }
  function subscribe(l) { listeners.add(l); return () => listeners.delete(l); }

  // ---------- nav helpers ----------
  function setTab(tab) {
    setState((s) => ({ ...s, nav: { tab, stack: [] } }));
  }
  function push(screen, params = {}) {
    setState((s) => ({ ...s, nav: { ...s.nav, stack: [...s.nav.stack, { screen, params }] } }));
  }
  function pop() {
    setState((s) => ({ ...s, nav: { ...s.nav, stack: s.nav.stack.slice(0, -1) } }));
  }
  function resetStack() {
    setState((s) => ({ ...s, nav: { ...s.nav, stack: [] } }));
  }
  function setMode(mode) {
    setState((s) => ({ ...s, mode, nav: { tab: 'home', stack: [] } }));
  }

  // ---------- data helpers ----------
  function addFood(entry) {
    setState((s) => ({
      ...s,
      diary: [...s.diary, { ...entry, id: s.nextId }],
      nextId: s.nextId + 1,
    }));
    toast('Added to ' + entry.meal);
  }
  function removeFood(id) {
    setState((s) => ({ ...s, diary: s.diary.filter((e) => e.id !== id) }));
  }
  function addWater(ml) {
    setState((s) => ({ ...s, waterMl: Math.max(0, s.waterMl + ml) }));
  }
  let toastTimer = null;
  function toast(msg) {
    setState((s) => ({ ...s, toast: msg }));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => setState((s) => ({ ...s, toast: null })), 1900);
  }
  function paywall(on) { setState((s) => ({ ...s, paywall: on })); }

  function applyOnboarding(partial) {
    setState((s) => {
      const ob = { ...s.onboarding, ...partial };
      return { ...s, onboarding: ob, targets: computeTargets(ob) };
    });
  }

  // ---------- derived ----------
  function totals(s) {
    const t = { kcal: 0, p: 0, c: 0, f: 0, fib: 0 };
    s.diary.forEach((e) => { t.kcal += e.kcal; t.p += e.p; t.c += e.c; t.f += e.f; t.fib += e.fib; });
    return t;
  }

  window.VitalStore = {
    getState, setState, subscribe,
    setTab, push, pop, resetStack, setMode,
    addFood, removeFood, addWater, toast, paywall, applyOnboarding,
    computeTargets, totals,
  };

  window.useVital = function useVital() {
    const s = React.useSyncExternalStore(subscribe, getState);
    return s;
  };
})();


/* ===== app/icons.jsx ===== */
// icons.jsx — clean line-icon set for Vital. Stroke uses currentColor so they inherit text color.
(function () {
  function Ico({ d, size = 24, sw = 2, fill = 'none', children, vb = 24, ...rest }) {
    return (
      <svg width={size} height={size} viewBox={`0 0 ${vb} ${vb}`} fill="none"
        stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" {...rest}>
        {d ? <path d={d} fill={fill} stroke={fill === 'none' ? 'currentColor' : 'none'} /> : children}
      </svg>
    );
  }

  const I = {
    home: (p) => <Ico {...p}><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5" /></Ico>,
    log: (p) => <Ico {...p}><path d="M5 4.5h11l3 3V19.5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-14a1 1 0 0 1 1-1Z" /><path d="M8 10h8M8 14h6" /></Ico>,
    dumbbell: (p) => <Ico {...p}><path d="M6.5 6.5v11M3.5 9v6M17.5 6.5v11M20.5 9v6M6.5 12h11" /></Ico>,
    plan: (p) => <Ico {...p}><path d="M4 6.5h16M4 12h16M4 17.5h10" /><circle cx="20" cy="17.5" r="1.4" fill="currentColor" stroke="none" /></Ico>,
    profile: (p) => <Ico {...p}><circle cx="12" cy="8" r="3.6" /><path d="M5 20c0-3.6 3.1-6 7-6s7 2.4 7 6" /></Ico>,
    flame: (p) => <Ico {...p}><path d="M12 3c2 3 .5 4.5 0 5.5C11 7 9.5 6 9.5 6S7 8 7 11.5a5 5 0 0 0 10 0c0-2.2-1.2-3.7-2-5-.7 1.4-2 1.6-3 .5Z" /></Ico>,
    drop: (p) => <Ico {...p}><path d="M12 3.5C12 3.5 6 9.5 6 14a6 6 0 0 0 12 0c0-4.5-6-10.5-6-10.5Z" /></Ico>,
    scan: (p) => <Ico {...p}><path d="M4 8V5.5a1.5 1.5 0 0 1 1.5-1.5H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16" /><path d="M7 12h10" /></Ico>,
    camera: (p) => <Ico {...p}><path d="M3.5 8.5A1.5 1.5 0 0 1 5 7h2l1.2-2h7.6L17 7h2a1.5 1.5 0 0 1 1.5 1.5V18a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 18Z" /><circle cx="12" cy="13" r="3.4" /></Ico>,
    plus: (p) => <Ico {...p}><path d="M12 5v14M5 12h14" /></Ico>,
    minus: (p) => <Ico {...p}><path d="M5 12h14" /></Ico>,
    weight: (p) => <Ico {...p}><circle cx="12" cy="12" r="8.5" /><path d="M12 12l3-3.2" /></Ico>,
    chevR: (p) => <Ico {...p}><path d="M9 5l7 7-7 7" /></Ico>,
    chevL: (p) => <Ico {...p}><path d="M15 5l-7 7 7 7" /></Ico>,
    chevD: (p) => <Ico {...p}><path d="M5 9l7 7 7-7" /></Ico>,
    chevU: (p) => <Ico {...p}><path d="M5 15l7-7 7 7" /></Ico>,
    search: (p) => <Ico {...p}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></Ico>,
    star: (p) => <Ico {...p}><path d="M12 4l2.3 4.7 5.2.8-3.8 3.7.9 5.2L12 16.7 7.4 18.4l.9-5.2L4.5 9.5l5.2-.8Z" /></Ico>,
    starFill: (p) => <Ico {...p} fill="currentColor"><path d="M12 4l2.3 4.7 5.2.8-3.8 3.7.9 5.2L12 16.7 7.4 18.4l.9-5.2L4.5 9.5l5.2-.8Z" fill="currentColor" stroke="currentColor" /></Ico>,
    check: (p) => <Ico {...p}><path d="M5 12.5l4.5 4.5L19 7" /></Ico>,
    x: (p) => <Ico {...p}><path d="M6 6l12 12M18 6L6 18" /></Ico>,
    bolt: (p) => <Ico {...p}><path d="M13 3 5 13h6l-1 8 8-10h-6l1-8Z" /></Ico>,
    clock: (p) => <Ico {...p}><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></Ico>,
    crown: (p) => <Ico {...p}><path d="M4 8l3.5 3L12 5l4.5 6L20 8l-1.5 9h-13L4 8Z" /></Ico>,
    edit: (p) => <Ico {...p}><path d="M5 19h14M14 5.5l3.5 3.5L9 17.5l-4 1 1-4 8-9Z" /></Ico>,
    copy: (p) => <Ico {...p}><rect x="8" y="8" width="11" height="11" rx="2" /><path d="M5 15.5V6.5A1.5 1.5 0 0 1 6.5 5H15" /></Ico>,
    trash: (p) => <Ico {...p}><path d="M4.5 7h15M9 7V5.5A1.5 1.5 0 0 1 10.5 4h3A1.5 1.5 0 0 1 15 5.5V7M6.5 7l1 12.5A1.5 1.5 0 0 0 9 21h6a1.5 1.5 0 0 0 1.5-1.5L17.5 7" /></Ico>,
    calendar: (p) => <Ico {...p}><rect x="4" y="5.5" width="16" height="15" rx="2" /><path d="M4 10h16M8 3.5v4M16 3.5v4" /></Ico>,
    cog: (p) => <Ico {...p}><circle cx="12" cy="12" r="3.2" /><path d="M12 3.5v2.2M12 18.3v2.2M20.5 12h-2.2M5.7 12H3.5M18 6l-1.6 1.6M7.6 16.4 6 18M18 18l-1.6-1.6M7.6 7.6 6 6" /></Ico>,
    sync: (p) => <Ico {...p}><path d="M5 12a7 7 0 0 1 12-5l2 2M19 12a7 7 0 0 1-12 5l-2-2" /><path d="M19 4v5h-5M5 20v-5h5" /></Ico>,
    chart: (p) => <Ico {...p}><path d="M4 19V5M4 19h16" /><path d="M8 16l3.5-4 3 2.5L20 8" /></Ico>,
    apple: (p) => <Ico {...p}><path d="M16 13.5c0 3-2 5.5-3.4 5.5-.8 0-1.2-.5-2.1-.5s-1.4.5-2.2.5C6.8 19 5 16.2 5 13c0-3 1.8-4.5 3.3-4.5.9 0 1.6.5 2.2.5s1.2-.6 2.4-.6c1 0 2 .5 2.6 1.3-1.5 1-1.5 3.2.5 3.8Z" /><path d="M12.5 6.2c.6-.8.5-1.9.4-2.2-.8.1-1.6.6-2 1.2" /></Ico>,
    target: (p) => <Ico {...p}><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4" /><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" /></Ico>,
    leaf: (p) => <Ico {...p}><path d="M19 5c-8 0-13 3.5-13 10 0 0 0 0 0 0a1 1 0 0 0 1 1c6.5 0 12-5 12-11Z" /><path d="M6 18C9 13 13 9.5 17 7.5" /></Ico>,
    info: (p) => <Ico {...p}><circle cx="12" cy="12" r="8.5" /><path d="M12 11v5M12 7.8v.2" /></Ico>,
    play: (p) => <Ico {...p} fill="currentColor"><path d="M8 5.5v13l11-6.5-11-6.5Z" fill="currentColor" stroke="currentColor" /></Ico>,
    music: (p) => <Ico {...p}><circle cx="7" cy="17" r="2.5" /><circle cx="17" cy="15" r="2.5" /><path d="M9.5 17V6l10-2v11" /></Ico>,
    fork: (p) => <Ico {...p}><path d="M7 3v7a2 2 0 0 0 4 0V3M9 10v11M16 3c-1.5 0-2.5 2-2.5 5s1 4 2.5 4M16 3v18" /></Ico>,
    arrowUp: (p) => <Ico {...p}><path d="M12 19V5M6 11l6-6 6 6" /></Ico>,
    arrowDown: (p) => <Ico {...p}><path d="M12 5v14M6 13l6 6 6-6" /></Ico>,
  };

  window.VIcon = I;
})();


/* ===== app/ui.jsx ===== */
// ui.jsx — Vital UI primitives. Theme via CSS vars set on the app root.
// Exposes window.V (components) and window.VTheme (theme builder).
(function () {
  const I = window.VIcon;

  // ---------- theme ----------
  const ACCENTS = {
    lime:   { accent: '#C8F751', on: '#0B0C0E' },
    blue:   { accent: '#4D8DFF', on: '#FFFFFF' },
    coral:  { accent: '#FF6A4D', on: '#1A0B07' },
    violet: { accent: '#A47BFF', on: '#FFFFFF' },
  };
  function buildTheme(accentKey, dark) {
    const a = ACCENTS[accentKey] || ACCENTS.lime;
    const accentDim = a.accent.replace(')', '') ; // not used
    if (dark) {
      return {
        '--bg': '#0B0C0E', '--surface': '#15171B', '--surface2': '#1D2026',
        '--border': 'rgba(255,255,255,0.08)', '--text': '#F3F5F4',
        '--muted': '#9AA0A8', '--faint': '#5C626B',
        '--accent': a.accent, '--on-accent': a.on,
        '--accent-soft': hexA(a.accent, 0.14),
        '--c-protein': a.accent, '--c-carbs': '#5EC8FF', '--c-fat': '#FFB259', '--c-fiber': '#B69CFF',
        '--track': 'rgba(255,255,255,0.09)',
        '--shadow': '0 12px 30px rgba(0,0,0,0.45)',
      };
    }
    return {
      '--bg': '#EFF1EC', '--surface': '#FFFFFF', '--surface2': '#F4F6F1',
      '--border': 'rgba(15,18,20,0.09)', '--text': '#14171A',
      '--muted': '#5C636B', '--faint': '#9AA1A9',
      '--accent': a.accent, '--on-accent': a.on,
      '--accent-soft': hexA(a.accent, 0.20),
      '--c-protein': darken(a.accent), '--c-carbs': '#1F93D6', '--c-fat': '#E0892A', '--c-fiber': '#8B5CF6',
      '--track': 'rgba(15,18,20,0.08)',
      '--shadow': '0 12px 30px rgba(15,18,20,0.10)',
    };
  }
  function hexA(hex, a) {
    const h = hex.replace('#', '');
    const n = parseInt(h.length === 3 ? h.split('').map(x => x + x).join('') : h, 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  }
  function darken(hex) {
    const h = hex.replace('#', '');
    const n = parseInt(h, 16);
    const r = Math.round(((n >> 16) & 255) * 0.7), g = Math.round(((n >> 8) & 255) * 0.7), b = Math.round((n & 255) * 0.7);
    return `rgb(${r},${g},${b})`;
  }
  const DENSITY = {
    compact: { pad: 13, gap: 10, radius: 18 },
    regular: { pad: 16, gap: 14, radius: 22 },
    comfy:   { pad: 20, gap: 18, radius: 26 },
  };

  // ---------- Card ----------
  function Card({ children, style = {}, pad, onClick, accent }) {
    return (
      <div onClick={onClick} style={{
        background: accent ? 'var(--accent)' : 'var(--surface)',
        color: accent ? 'var(--on-accent)' : 'var(--text)',
        border: accent ? 'none' : '1px solid var(--border)',
        borderRadius: 'var(--radius)',
        padding: pad != null ? pad : 'var(--pad)',
        boxSizing: 'border-box',
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}>{children}</div>
    );
  }

  // ---------- Pill / chip ----------
  function Pill({ label, value, tone = 'neutral', icon, onClick, active }) {
    const tones = {
      neutral: { bg: 'var(--surface2)', fg: 'var(--text)' },
      accent: { bg: 'var(--accent)', fg: 'var(--on-accent)' },
      soft: { bg: 'var(--accent-soft)', fg: 'var(--accent)' },
      ghost: { bg: 'transparent', fg: 'var(--muted)' },
    };
    const tn = active ? tones.accent : (tones[tone] || tones.neutral);
    return (
      <div onClick={onClick} style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '7px 12px', borderRadius: 999, background: tn.bg, color: tn.fg,
        fontSize: 12.5, fontWeight: 600, whiteSpace: 'nowrap',
        border: tone === 'ghost' && !active ? '1px solid var(--border)' : 'none',
        cursor: onClick ? 'pointer' : 'default', letterSpacing: 0.1,
      }}>
        {icon}
        {label && <span style={{ opacity: value ? 0.62 : 1 }}>{label}</span>}
        {value != null && <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{value}</span>}
      </div>
    );
  }

  // ---------- Button ----------
  function Button({ children, onClick, variant = 'primary', size = 'lg', full, icon, style = {} }) {
    const variants = {
      primary: { bg: 'var(--accent)', fg: 'var(--on-accent)', bd: 'none' },
      dark: { bg: 'var(--surface2)', fg: 'var(--text)', bd: '1px solid var(--border)' },
      ghost: { bg: 'transparent', fg: 'var(--text)', bd: '1px solid var(--border)' },
    };
    const v = variants[variant] || variants.primary;
    const sz = size === 'sm' ? { h: 38, fs: 13, px: 14 } : size === 'md' ? { h: 46, fs: 14.5, px: 18 } : { h: 54, fs: 16, px: 22 };
    return (
      <button onClick={onClick} style={{
        height: sz.h, padding: `0 ${sz.px}px`, borderRadius: 14,
        background: v.bg, color: v.fg, border: v.bd,
        fontSize: sz.fs, fontWeight: 700, fontFamily: 'inherit', letterSpacing: 0.2,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8, whiteSpace: 'nowrap',
        width: full ? '100%' : undefined, cursor: 'pointer', ...style,
      }}>{icon}{children}</button>
    );
  }

  // ---------- Stepper ----------
  function Stepper({ value, onChange, step = 1, unit = '', min = 0, max = 9999, big }) {
    const btn = (dir) => (
      <button onClick={() => onChange(Math.min(max, Math.max(min, +(value + dir * step).toFixed(2))))}
        style={{
          width: big ? 46 : 34, height: big ? 46 : 34, borderRadius: 999,
          border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
        }}>
        {dir > 0 ? <I.plus size={big ? 22 : 18} /> : <I.minus size={big ? 22 : 18} />}
      </button>
    );
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: big ? 16 : 10 }}>
        {btn(-1)}
        <div style={{ minWidth: big ? 84 : 56, textAlign: 'center', fontWeight: 800, fontSize: big ? 30 : 17, fontVariantNumeric: 'tabular-nums' }}>
          {value}{unit && <span style={{ fontSize: big ? 15 : 12, color: 'var(--muted)', marginLeft: 3 }}>{unit}</span>}
        </div>
        {btn(1)}
      </div>
    );
  }

  // ---------- Segmented control ----------
  function Segmented({ options, value, onChange, full }) {
    return (
      <div style={{
        display: 'flex', gap: 4, padding: 4, background: 'var(--surface2)',
        borderRadius: 13, width: full ? '100%' : undefined,
      }}>
        {options.map((o) => {
          const val = typeof o === 'string' ? o : o.value;
          const lbl = typeof o === 'string' ? o : o.label;
          const on = val === value;
          return (
            <button key={val} onClick={() => onChange(val)} style={{
              flex: full ? 1 : undefined, padding: '8px 13px', borderRadius: 10, border: 'none',
              background: on ? 'var(--accent)' : 'transparent', color: on ? 'var(--on-accent)' : 'var(--muted)',
              fontWeight: 700, fontSize: 13, fontFamily: 'inherit', cursor: 'pointer', whiteSpace: 'nowrap',
              transition: 'all .15s',
            }}>{lbl}</button>
          );
        })}
      </div>
    );
  }

  // ---------- Linear progress ----------
  function ProgressBar({ value, max, color = 'var(--accent)', height = 8, track = 'var(--track)' }) {
    const pct = Math.max(0, Math.min(100, (value / max) * 100));
    return (
      <div style={{ height, background: track, borderRadius: 999, overflow: 'hidden' }}>
        <div style={{ width: pct + '%', height: '100%', background: color, borderRadius: 999, transition: 'width .5s cubic-bezier(.4,0,.2,1)' }} />
      </div>
    );
  }

  // ---------- Macro bars ----------
  function MacroBars({ totals, targets, compact }) {
    const rows = [
      { k: 'Protein', v: totals.p, t: targets.proteinG, c: 'var(--c-protein)' },
      { k: 'Carbs', v: totals.c, t: targets.carbsG, c: 'var(--c-carbs)' },
      { k: 'Fat', v: totals.f, t: targets.fatG, c: 'var(--c-fat)' },
      { k: 'Fiber', v: totals.fib, t: targets.fiberG, c: 'var(--c-fiber)' },
    ];
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: compact ? 9 : 13 }}>
        {rows.map((r) => (
          <div key={r.k}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 5 }}>
              <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text)' }}>{r.k}</span>
              <span style={{ fontSize: 12, color: 'var(--muted)', fontVariantNumeric: 'tabular-nums' }}>
                <b style={{ color: 'var(--text)' }}>{Math.round(r.v)}</b> / {r.t} g
                <span style={{ color: 'var(--faint)', marginLeft: 6 }}>{Math.round((r.v / r.t) * 100)}%</span>
              </span>
            </div>
            <ProgressBar value={r.v} max={r.t} color={r.c} height={compact ? 6 : 8} />
          </div>
        ))}
      </div>
    );
  }

  // ---------- Calorie hero (4 metaphors) ----------
  function CalorieHero({ consumed, budget, burned, metaphor = 'ring', size = 200 }) {
    const remaining = Math.round(budget - consumed + burned);
    const pct = Math.max(0, Math.min(1, consumed / budget));
    const center = (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', lineHeight: 1 }}>
        <div style={{ fontSize: size * 0.235, fontWeight: 800, fontVariantNumeric: 'tabular-nums', letterSpacing: -1, fontFamily: 'var(--font-display)' }}>
          {remaining < 0 ? '+' + Math.abs(remaining) : remaining}
        </div>
        <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1.5, marginTop: 5 }}>
          {remaining < 0 ? 'over' : 'kcal left'}
        </div>
      </div>
    );

    if (metaphor === 'ring' || metaphor === 'arc') {
      const arc = metaphor === 'arc';
      const stroke = size * 0.085;
      const r = (size - stroke) / 2;
      const circ = 2 * Math.PI * r;
      const span = arc ? 0.75 : 1;            // arc covers 270°
      const dash = circ * span;
      const filled = dash * pct;
      const rot = arc ? 135 : -90;
      return (
        <div style={{ position: 'relative', width: size, height: arc ? size * 0.86 : size }}>
          <svg width={size} height={size} style={{ transform: `rotate(${rot}deg)`, display: 'block' }}>
            <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--track)" strokeWidth={stroke}
              strokeDasharray={`${dash} ${circ}`} strokeLinecap="round" />
            <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--accent)" strokeWidth={stroke}
              strokeDasharray={`${filled} ${circ}`} strokeLinecap="round"
              style={{ transition: 'stroke-dasharray .7s cubic-bezier(.4,0,.2,1)' }} />
          </svg>
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: arc ? '14%' : 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {center}
          </div>
        </div>
      );
    }

    if (metaphor === 'battery') {
      const cells = 12, lit = Math.round(pct * cells);
      return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
          {center}
          <div style={{ display: 'flex', gap: 4, width: size * 0.92 }}>
            {Array.from({ length: cells }).map((_, i) => (
              <div key={i} style={{ flex: 1, height: 22, borderRadius: 4, background: i < lit ? 'var(--accent)' : 'var(--track)', transition: 'background .3s' }} />
            ))}
          </div>
        </div>
      );
    }

    // bar
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18, width: '100%' }}>
        {center}
        <div style={{ width: '100%' }}>
          <div style={{ height: 18, borderRadius: 999, background: 'var(--track)', overflow: 'hidden' }}>
            <div style={{ width: pct * 100 + '%', height: '100%', background: 'var(--accent)', borderRadius: 999, transition: 'width .6s' }} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, fontSize: 11.5, color: 'var(--muted)', fontWeight: 600 }}>
            <span>{consumed} eaten</span><span>{budget} goal</span>
          </div>
        </div>
      </div>
    );
  }

  // ---------- Weekly bar chart ----------
  function BarChart({ data, labels, color = 'var(--accent)', height = 80, goalRatio }) {
    const max = Math.max(...data, 1);
    return (
      <div>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 7, height }}>
          {data.map((v, i) => (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: '100%' }}>
              <div style={{ height: (v / max) * 100 + '%', background: i === data.length - 1 ? color : 'var(--track)', borderRadius: 5, minHeight: 4, transition: 'height .5s' }} />
            </div>
          ))}
        </div>
        {labels && (
          <div style={{ display: 'flex', gap: 7, marginTop: 7 }}>
            {labels.map((l, i) => <div key={i} style={{ flex: 1, textAlign: 'center', fontSize: 10.5, color: 'var(--faint)', fontWeight: 600 }}>{l}</div>)}
          </div>
        )}
      </div>
    );
  }

  // ---------- Sparkline / trend ----------
  function Sparkline({ points, width = 260, height = 70, color = 'var(--accent)', goal }) {
    const xs = points.map((p) => p.kg ?? p);
    const min = Math.min(...xs) - 0.4, max = Math.max(...xs) + 0.4;
    const px = (i) => (i / (points.length - 1)) * width;
    const py = (v) => height - ((v - min) / (max - min)) * height;
    const d = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${px(i).toFixed(1)} ${py(p.kg ?? p).toFixed(1)}`).join(' ');
    const area = d + ` L ${width} ${height} L 0 ${height} Z`;
    const gid = 'sg' + Math.round(width);
    return (
      <svg width="100%" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ display: 'block', overflow: 'visible' }}>
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.28" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {goal != null && <line x1="0" y1={py(goal)} x2={width} y2={py(goal)} stroke="var(--faint)" strokeWidth="1" strokeDasharray="4 4" />}
        <path d={area} fill={`url(#${gid})`} />
        <path d={d} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        {points.map((p, i) => i === points.length - 1 && (
          <circle key={i} cx={px(i)} cy={py(p.kg ?? p)} r="4" fill={color} stroke="var(--surface)" strokeWidth="2" />
        ))}
      </svg>
    );
  }

  // ---------- Section header ----------
  function SectionHeader({ title, action, onAction }) {
    return (
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <h3 style={{ margin: 0, fontSize: 17, fontWeight: 800, letterSpacing: -0.3, fontFamily: 'var(--font-display)' }}>{title}</h3>
        {action && <span onClick={onAction} style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)', cursor: 'pointer' }}>{action}</span>}
      </div>
    );
  }

  // ---------- Maze texture (brand element) ----------
  function MazeBg({ opacity = 0.06, color = 'var(--on-accent)' }) {
    return (
      <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0, opacity, pointerEvents: 'none' }} preserveAspectRatio="xMidYMid slice">
        <pattern id="maze" width="44" height="44" patternUnits="userSpaceOnUse">
          <path d="M0 11h22v22h22M11 0v22h22M0 33h11v11" fill="none" stroke={color} strokeWidth="2.5" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#maze)" />
      </svg>
    );
  }

  // ---------- Disclaimer ----------
  function Disclaimer({ text }) {
    return (
      <div style={{ display: 'flex', gap: 8, padding: '0 4px', marginTop: 4 }}>
        <I.info size={14} style={{ color: 'var(--faint)', flexShrink: 0, marginTop: 1 }} />
        <p style={{ margin: 0, fontSize: 10.5, lineHeight: 1.45, color: 'var(--faint)' }}>
          {text || 'Estimates only — not medical advice. Consult a professional before changing your nutrition or training.'}
        </p>
      </div>
    );
  }

  window.VTheme = { buildTheme, DENSITY, ACCENTS };
  window.V = { Card, Pill, Button, Stepper, Segmented, ProgressBar, MacroBars, CalorieHero, BarChart, Sparkline, SectionHeader, MazeBg, Disclaimer };
})();


/* ===== app/screens-onboarding.jsx ===== */
// screens-onboarding.jsx — questionnaire → results reveal. Real Mifflin–St Jeor math via store.
(function () {
  const I = window.VIcon;
  const { Button, Segmented, Stepper, MazeBg, Disclaimer } = window.V;
  const S = window.VitalStore;

  const inputStyle = {
    width: '100%', boxSizing: 'border-box', height: 52, padding: '0 16px', borderRadius: 14,
    border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)',
    fontSize: 16, fontFamily: 'inherit', outline: 'none', fontWeight: 600,
  };

  const ACTIVITY = [
    { value: 'sedentary', label: 'Sedentary', sub: 'Little or no exercise' },
    { value: 'light', label: 'Light', sub: '1–3 days / week' },
    { value: 'moderate', label: 'Moderate', sub: '3–5 days / week' },
    { value: 'very', label: 'Very active', sub: '6–7 days / week' },
    { value: 'extra', label: 'Extra active', sub: 'Hard daily / physical job' },
  ];
  const GOALS = [
    { value: 'lose', label: 'Lose weight', sub: 'Shed fat at a steady pace' },
    { value: 'maintain', label: 'Maintain', sub: 'Stay where I am, eat smarter' },
    { value: 'gain', label: 'Build muscle', sub: 'Lean gains, fuel training' },
  ];
  const DIETS = [
    { value: 'omnivore', label: 'Omnivore' }, { value: 'highprotein', label: 'High-protein' },
    { value: 'lowcarb', label: 'Low-carb' }, { value: 'vegetarian', label: 'Vegetarian' },
    { value: 'vegan', label: 'Vegan' }, { value: 'mediterranean', label: 'Mediterranean' },
  ];

  function Field({ label, children, hint }) {
    return (
      <div>
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 }}>{label}</div>
        {children}
        {hint && <div style={{ fontSize: 11.5, color: 'var(--faint)', marginTop: 8 }}>{hint}</div>}
      </div>
    );
  }

  function ChoiceRow({ title, sub, active, onClick }) {
    return (
      <div onClick={onClick} style={{
        display: 'flex', alignItems: 'center', gap: 14, padding: '15px 16px',
        borderRadius: 16, cursor: 'pointer', transition: 'all .15s',
        background: active ? 'var(--accent-soft)' : 'var(--surface)',
        border: active ? '1.5px solid var(--accent)' : '1px solid var(--border)',
      }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 15 }}>{title}</div>
          {sub && <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 2 }}>{sub}</div>}
        </div>
        <div style={{
          width: 22, height: 22, borderRadius: 999, flexShrink: 0,
          border: active ? 'none' : '2px solid var(--border)',
          background: active ? 'var(--accent)' : 'transparent',
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--on-accent)',
        }}>{active && <I.check size={14} sw={3} />}</div>
      </div>
    );
  }

  function StatChip({ label, value, unit }) {
    return (
      <div style={{ flex: 1, textAlign: 'center', padding: '14px 8px', borderRadius: 16, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
        <div style={{ fontSize: 23, fontWeight: 800, letterSpacing: -0.5, fontFamily: 'var(--font-display)', fontVariantNumeric: 'tabular-nums' }}>{value}<span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600, marginLeft: 2 }}>{unit}</span></div>
        <div style={{ fontSize: 10.5, color: 'var(--muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8, marginTop: 4 }}>{label}</div>
      </div>
    );
  }

  function Onboarding({ onDone }) {
    window.useVital();
    const [step, setStep] = React.useState(0);
    const [d, setD] = React.useState({ ...S.getState().onboarding });
    const set = (k, v) => setD((p) => ({ ...p, [k]: v }));
    const metric = d.units === 'metric';
    const scrollRef = React.useRef(null);

    const STEPS = ['You', 'Body', 'Activity', 'Goal', 'Diet'];
    const total = STEPS.length;
    const isResults = step === total;
    const preview = S.computeTargets(d);

    React.useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, [step]);

    function next() { setStep((s) => Math.min(total, s + 1)); }
    function back() { setStep((s) => Math.max(0, s - 1)); }
    function finish() { S.applyOnboarding(d); S.toast('Targets saved'); onDone && onDone(); }

    // ---- RESULTS SCREEN ----
    if (isResults) {
      const t = preview;
      const goalLabel = { lose: 'lose weight', maintain: 'maintain', gain: 'build muscle' }[d.goal];
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', WebkitOverflowScrolling: 'touch' }}>
            {/* accent hero */}
            <div style={{ position: 'relative', background: 'var(--accent)', color: 'var(--on-accent)', padding: 'calc(var(--safe-top) + 6px) 24px 30px', overflow: 'hidden' }}>
              <MazeBg opacity={0.08} />
              <div style={{ position: 'relative' }}>
                <div style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, opacity: 0.7 }}>Your plan is ready</div>
                <div style={{ fontSize: 15, fontWeight: 600, opacity: 0.85, marginTop: 14 }}>Daily calorie budget</div>
                <div style={{ fontSize: 76, fontWeight: 800, lineHeight: 1, letterSpacing: -3, fontFamily: 'var(--font-display)', fontVariantNumeric: 'tabular-nums', marginTop: 2 }}>
                  {t.budget.toLocaleString()}
                </div>
                <div style={{ fontSize: 14, fontWeight: 600, opacity: 0.85, marginTop: 6 }}>
                  kcal / day to {goalLabel}{d.goal !== 'maintain' ? ` · ~${d.rateKgWk} ${metric ? 'kg' : 'lb'}/wk` : ''}
                </div>
              </div>
            </div>

            <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 20, marginTop: -2 }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', marginBottom: 12 }}>Daily macro split</div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <MacroTarget label="Protein" g={t.proteinG} c="var(--c-protein)" pct={Math.round(t.proteinG * 4 / t.budget * 100)} />
                  <MacroTarget label="Carbs" g={t.carbsG} c="var(--c-carbs)" pct={Math.round(t.carbsG * 4 / t.budget * 100)} />
                  <MacroTarget label="Fat" g={t.fatG} c="var(--c-fat)" pct={Math.round(t.fatG * 9 / t.budget * 100)} />
                </div>
              </div>

              <div>
                <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', marginBottom: 12 }}>The science</div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <StatChip label="BMR" value={t.bmr.toLocaleString()} unit="" />
                  <StatChip label="Maintenance" value={t.tdee.toLocaleString()} unit="" />
                  <StatChip label="BMI" value={t.bmi} unit="" />
                </div>
                <p style={{ fontSize: 12.5, lineHeight: 1.5, color: 'var(--muted)', marginTop: 14 }}>
                  Your maintenance is <b style={{ color: 'var(--text)' }}>{t.tdee.toLocaleString()} kcal</b> (Mifflin–St Jeor × activity).
                  {d.goal === 'lose' && ` We trimmed ${(t.tdee - t.budget).toLocaleString()} kcal for steady fat loss.`}
                  {d.goal === 'gain' && ` We added ${(t.budget - t.tdee).toLocaleString()} kcal to fuel lean gains.`}
                  {d.goal === 'maintain' && ' Your budget matches maintenance.'}
                </p>
                {t.clamped && (
                  <div style={{ marginTop: 12, padding: '12px 14px', borderRadius: 12, background: 'var(--accent-soft)', fontSize: 12.5, lineHeight: 1.5, color: 'var(--text)' }}>
                    We raised your budget to a safe minimum — aggressive deficits aren’t sustainable or healthy.
                  </div>
                )}
              </div>

              <Disclaimer />
            </div>
          </div>

          <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)', display: 'flex', gap: 12 }}>
            <Button variant="ghost" size="lg" onClick={() => setStep(total - 1)}>Edit</Button>
            <Button full size="lg" onClick={finish}>Start tracking</Button>
          </div>
        </div>
      );
    }

    // ---- QUESTION STEPS ----
    let title, subtitle, content;
    if (step === 0) {
      title = 'Welcome to Vital'; subtitle = 'Two minutes of setup powers every number you’ll see.';
      content = (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <Field label="What should we call you?">
            <input value={d.name} onChange={(e) => set('name', e.target.value)} placeholder="Your name" style={inputStyle} />
          </Field>
          <Field label="Age">
            <Stepper value={d.age} onChange={(v) => set('age', v)} min={14} max={99} unit="yrs" />
          </Field>
          <Field label="Sex" hint="Used only to estimate your metabolic rate.">
            <Segmented full options={[{ value: 'male', label: 'Male' }, { value: 'female', label: 'Female' }]} value={d.sex} onChange={(v) => set('sex', v)} />
          </Field>
        </div>
      );
    } else if (step === 1) {
      title = 'Your body'; subtitle = 'The inputs behind your energy needs.';
      content = (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <Field label="Units">
            <Segmented full options={[{ value: 'metric', label: 'Metric' }, { value: 'imperial', label: 'Imperial' }]} value={d.units} onChange={(v) => set('units', v)} />
          </Field>
          <Field label="Height">
            <Stepper big value={metric ? d.heightCm : Math.round(d.heightCm / 2.54)} unit={metric ? 'cm' : 'in'}
              onChange={(v) => set('heightCm', metric ? v : Math.round(v * 2.54))} step={1} min={120} max={230} />
          </Field>
          <Field label="Current weight">
            <Stepper big value={metric ? d.weightKg : Math.round(d.weightKg * 2.205)} unit={metric ? 'kg' : 'lb'}
              onChange={(v) => set('weightKg', metric ? v : Math.round(v / 2.205))} step={metric ? 0.5 : 1} min={30} max={400} />
          </Field>
        </div>
      );
    } else if (step === 2) {
      title = 'How active are you?'; subtitle = 'Outside of planned workouts.';
      content = (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {ACTIVITY.map((a) => <ChoiceRow key={a.value} title={a.label} sub={a.sub} active={d.activity === a.value} onClick={() => set('activity', a.value)} />)}
        </div>
      );
    } else if (step === 3) {
      title = 'What’s your goal?'; subtitle = 'We’ll set a safe, sustainable target.';
      content = (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {GOALS.map((g) => <ChoiceRow key={g.value} title={g.label} sub={g.sub} active={d.goal === g.value} onClick={() => set('goal', g.value)} />)}
          </div>
          {d.goal !== 'maintain' && (
            <Field label={`Weekly pace · ${metric ? 'kg' : 'lb'} per week`} hint="0.5 kg/wk is the sustainable sweet spot for most people.">
              <Stepper big value={metric ? d.rateKgWk : +(d.rateKgWk * 2.205).toFixed(1)} unit={metric ? 'kg' : 'lb'}
                onChange={(v) => set('rateKgWk', metric ? v : +(v / 2.205).toFixed(2))} step={metric ? 0.25 : 0.5} min={0.25} max={metric ? 1 : 2} />
            </Field>
          )}
        </div>
      );
    } else if (step === 4) {
      title = 'Eating style'; subtitle = 'Tunes your meal suggestions — not your calories.';
      content = (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {DIETS.map((g) => <ChoiceRow key={g.value} title={g.label} active={d.diet === g.value} onClick={() => set('diet', g.value)} />)}
        </div>
      );
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        {/* progress */}
        <div style={{ padding: 'var(--safe-top) 22px 8px', display: 'flex', alignItems: 'center', gap: 14 }}>
          {step > 0 ? (
            <button onClick={back} style={iconBtn}><I.chevL size={20} /></button>
          ) : <div style={{ width: 38 }} />}
          <div style={{ flex: 1, display: 'flex', gap: 5 }}>
            {STEPS.map((_, i) => (
              <div key={i} style={{ flex: 1, height: 5, borderRadius: 99, background: i <= step ? 'var(--accent)' : 'var(--track)', transition: 'background .3s' }} />
            ))}
          </div>
          <div style={{ width: 38, textAlign: 'right', fontSize: 12.5, fontWeight: 700, color: 'var(--muted)' }}>{step + 1}/{total}</div>
        </div>

        <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '18px 22px 22px' }}>
          <h1 style={{ margin: '0 0 6px', fontSize: 30, fontWeight: 800, letterSpacing: -1, lineHeight: 1.05, fontFamily: 'var(--font-display)' }}>{title}</h1>
          <p style={{ margin: '0 0 26px', fontSize: 15, color: 'var(--muted)', lineHeight: 1.4 }}>{subtitle}</p>
          {content}
        </div>

        <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
          <Button full size="lg" onClick={next} icon={null}>
            {step === total - 1 ? 'See my plan' : 'Continue'}
          </Button>
        </div>
      </div>
    );
  }

  function MacroTarget({ label, g, c, pct }) {
    return (
      <div style={{ flex: 1, padding: '16px 8px', borderRadius: 18, background: 'var(--surface)', border: '1px solid var(--border)', textAlign: 'center' }}>
        <div style={{ width: 32, height: 6, borderRadius: 99, background: c, margin: '0 auto 12px' }} />
        <div style={{ fontSize: 24, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5, fontVariantNumeric: 'tabular-nums' }}>{g}<span style={{ fontSize: 12, color: 'var(--muted)' }}>g</span></div>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.6, marginTop: 3 }}>{label}</div>
        <div style={{ fontSize: 11, color: 'var(--faint)', marginTop: 2 }}>{pct}%</div>
      </div>
    );
  }

  const iconBtn = {
    width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface)',
    color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
  };

  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Onboarding = Onboarding;
})();


/* ===== app/screens-home.jsx ===== */
// screens-home.jsx — dashboard: hero calorie metaphor, macros, quick actions, widgets.
(function () {
  const I = window.VIcon;
  const { Card, CalorieHero, MacroBars, BarChart, ProgressBar, SectionHeader, Pill } = window.V;
  const S = window.VitalStore;

  function QuickAction({ icon, label, onClick, accent }) {
    return (
      <button onClick={onClick} style={{
        flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
        padding: '14px 6px', borderRadius: 18, cursor: 'pointer',
        background: accent ? 'var(--accent)' : 'var(--surface)',
        color: accent ? 'var(--on-accent)' : 'var(--text)',
        border: accent ? 'none' : '1px solid var(--border)', fontFamily: 'inherit',
      }}>
        <div style={{
          width: 40, height: 40, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: accent ? 'rgba(0,0,0,0.12)' : 'var(--accent-soft)', color: accent ? 'var(--on-accent)' : 'var(--accent)',
        }}>{icon}</div>
        <span style={{ fontSize: 11.5, fontWeight: 700 }}>{label}</span>
      </button>
    );
  }

  function Home({ metaphor }) {
    const s = window.useVital();
    const t = S.totals(s);
    const tg = s.targets;
    const greeting = (() => {
      const h = new Date().getHours();
      return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
    })();
    const weekKcal = [1820, 2010, 1760, 1950, 2080, 1690, t.kcal];
    const wLabels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

    const waterPct = Math.round((s.waterMl / s.waterGoalMl) * 100);

    return (
      <div style={{ paddingBottom: 18 }}>
        {/* header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', padding: '6px 2px 18px' }}>
          <div>
            <div style={{ fontSize: 13, color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>{greeting},</div>
            <h1 style={{ margin: '2px 0 0', fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>{s.onboarding.name}</h1>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', borderRadius: 999, background: 'var(--surface)', border: '1px solid var(--border)' }}>
            <I.flame size={16} style={{ color: 'var(--accent)' }} />
            <span style={{ fontWeight: 800, fontSize: 14 }}>{s.streak}</span>
            <span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600 }}>day streak</span>
          </div>
        </div>

        {/* hero */}
        <Card style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18, paddingTop: 24, paddingBottom: 22 }}>
          <CalorieHero consumed={t.kcal} budget={tg.budget} burned={s.burnedKcal} metaphor={metaphor} size={196} />
          <div style={{ display: 'flex', width: '100%', borderTop: '1px solid var(--border)', paddingTop: 16 }}>
            <HeroStat icon={<I.apple size={16} />} label="Eaten" value={t.kcal.toLocaleString()} />
            <Divider />
            <HeroStat icon={<I.flame size={16} />} label="Burned" value={s.burnedKcal.toLocaleString()} />
            <Divider />
            <HeroStat icon={<I.target size={16} />} label="Budget" value={tg.budget.toLocaleString()} />
          </div>
        </Card>

        {/* quick actions */}
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <QuickAction accent icon={<I.plus size={22} sw={2.4} />} label="Log food" onClick={() => { S.setTab('log'); S.push('foodSearch', { meal: 'Lunch' }); }} />
          <QuickAction icon={<I.camera size={20} />} label="AI snap" onClick={() => { S.setTab('log'); S.push('aiSnap', {}); }} />
          <QuickAction icon={<I.scan size={20} />} label="Scan" onClick={() => { S.setTab('log'); S.push('foodSearch', { meal: 'Snack', scan: true }); }} />
          <QuickAction icon={<I.drop size={20} />} label="Water" onClick={() => S.addWater(250)} />
        </div>

        {/* macros */}
        <Card style={{ marginTop: 14 }}>
          <SectionHeader title="Macros" action="Details" onAction={() => S.setTab('log')} />
          <MacroBars totals={t} targets={tg} />
        </Card>

        {/* row: water + weekly */}
        <div style={{ display: 'flex', gap: 12, marginTop: 14 }}>
          <Card style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <I.drop size={20} style={{ color: 'var(--c-carbs)' }} />
              <span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 700 }}>{waterPct}%</span>
            </div>
            <div style={{ margin: '14px 0 10px' }}>
              <div style={{ fontSize: 24, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5 }}>{(s.waterMl / 1000).toFixed(1)}<span style={{ fontSize: 13, color: 'var(--muted)', fontWeight: 600 }}> / {(s.waterGoalMl / 1000).toFixed(1)} L</span></div>
              <div style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 600 }}>Water today</div>
            </div>
            <ProgressBar value={s.waterMl} max={s.waterGoalMl} color="var(--c-carbs)" height={7} />
            <div style={{ display: 'flex', gap: 7, marginTop: 12 }}>
              <button onClick={() => S.addWater(250)} style={miniBtn}>+250</button>
              <button onClick={() => S.addWater(500)} style={miniBtn}>+500 ml</button>
            </div>
          </Card>

          <Card style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
              <I.chart size={20} style={{ color: 'var(--accent)' }} />
              <span style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 700 }}>7-day</span>
            </div>
            <div style={{ fontSize: 24, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5, margin: '6px 0 2px' }}>1,857</div>
            <div style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 600, marginBottom: 12 }}>avg kcal / day</div>
            <BarChart data={weekKcal} labels={wLabels} height={56} />
          </Card>
        </div>

        {/* steps / activity */}
        <Card style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ width: 46, height: 46, borderRadius: 999, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.bolt size={22} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontWeight: 700, fontSize: 14 }}>Steps</span>
              <span style={{ fontSize: 13, color: 'var(--muted)', fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}><b style={{ color: 'var(--text)' }}>{s.steps.toLocaleString()}</b> / 10,000</span>
            </div>
            <ProgressBar value={s.steps} max={10000} height={7} />
          </div>
        </Card>

        {/* today's workout teaser */}
        <Card onClick={() => S.setTab('workout')} style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ width: 46, height: 46, borderRadius: 14, background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.dumbbell size={24} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8 }}>Today’s workout</div>
            <div style={{ fontWeight: 700, fontSize: 15, marginTop: 2 }}>{s.workout.title}</div>
          </div>
          <I.chevR size={20} style={{ color: 'var(--muted)' }} />
        </Card>
      </div>
    );
  }

  function HeroStat({ icon, label, value }) {
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
        <div style={{ color: 'var(--muted)' }}>{icon}</div>
        <div style={{ fontSize: 16, fontWeight: 800, fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--font-display)' }}>{value}</div>
        <div style={{ fontSize: 10.5, color: 'var(--muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6 }}>{label}</div>
      </div>
    );
  }
  function Divider() { return <div style={{ width: 1, background: 'var(--border)', margin: '2px 0' }} />; }

  const miniBtn = {
    flex: 1, padding: '7px 0', borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface2)',
    color: 'var(--text)', fontSize: 12, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer',
  };

  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Home = Home;
})();


/* ===== app/screens-log.jsx ===== */
// screens-log.jsx — Food diary, search, food detail, AI snap. Live add/remove via store.
(function () {
  const I = window.VIcon;
  const { Card, MacroBars, Button, Stepper, Segmented, ProgressBar, Pill } = window.V;
  const S = window.VitalStore;

  const MEALS = ['Breakfast', 'Lunch', 'Dinner', 'Snack'];

  // food database for search
  const FOODS = [
    { name: 'Grilled Chicken Breast', brand: '', unit: '100 g', kcal: 165, p: 31, c: 0, f: 3.6, fib: 0, src: 'common', verified: true },
    { name: 'White Rice, cooked', brand: '', unit: '1 cup', kcal: 205, p: 4.3, c: 45, f: 0.4, fib: 0.6, src: 'common', verified: true },
    { name: 'Banana', brand: '', unit: '1 medium', kcal: 105, p: 1.3, c: 27, f: 0.4, fib: 3.1, src: 'common', verified: true },
    { name: 'Whole Eggs', brand: '', unit: '2 large', kcal: 156, p: 12.6, c: 1.1, f: 10.6, fib: 0, src: 'common', verified: true },
    { name: 'Oats, rolled', brand: '', unit: '40 g', kcal: 152, p: 5.3, c: 27, f: 2.6, fib: 4, src: 'common', verified: true },
    { name: 'Protein Bar', brand: 'RXBAR', unit: '1 bar', kcal: 210, p: 12, c: 24, f: 9, fib: 5, src: 'branded', verified: true },
    { name: 'Salmon Fillet', brand: '', unit: '140 g', kcal: 280, p: 39, c: 0, f: 13, fib: 0, src: 'common', verified: true },
    { name: 'Avocado', brand: '', unit: '1/2 fruit', kcal: 160, p: 2, c: 8.5, f: 14.7, fib: 6.7, src: 'common', verified: true },
    { name: 'Greek Yogurt, plain', brand: 'Fage 0%', unit: '170 g', kcal: 90, p: 18, c: 6, f: 0, fib: 0, src: 'branded', verified: true },
    { name: 'Almond Butter', brand: '', unit: '1 tbsp', kcal: 98, p: 3.4, c: 3, f: 8.9, fib: 1.6, src: 'common', verified: false },
    { name: 'Sweet Potato, baked', brand: '', unit: '1 medium', kcal: 112, p: 2, c: 26, f: 0.1, fib: 3.9, src: 'common', verified: true },
    { name: 'Sourdough Bread', brand: '', unit: '1 slice', kcal: 120, p: 4, c: 23, f: 1, fib: 1.2, src: 'common', verified: true },
  ];

  const RECENT = ['Greek Yogurt, plain', 'Grilled Chicken Breast', 'Banana', 'Oats, rolled'];

  // ---------- DIARY ----------
  function MealGroup({ meal, entries, onAdd }) {
    const kcal = entries.reduce((a, e) => a + e.kcal, 0);
    return (
      <Card style={{ marginBottom: 14, padding: 0, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '15px 16px 13px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontWeight: 800, fontSize: 15.5, fontFamily: 'var(--font-display)' }}>{meal}</span>
            {kcal > 0 && <span style={{ fontSize: 12.5, color: 'var(--muted)', fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{kcal} kcal</span>}
          </div>
          <button onClick={onAdd} style={{ width: 30, height: 30, borderRadius: 999, border: 'none', background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <I.plus size={18} sw={2.5} />
          </button>
        </div>
        {entries.length > 0 && entries.map((e) => (
          <div key={e.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 16px', borderTop: '1px solid var(--border)' }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', flexShrink: 0 }}>
              <I.fork size={17} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 600, fontSize: 14, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{e.name}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>{e.qty} {e.unit} · P{Math.round(e.p)} C{Math.round(e.c)} F{Math.round(e.f)}</div>
            </div>
            <div style={{ fontWeight: 700, fontSize: 14, fontVariantNumeric: 'tabular-nums' }}>{e.kcal}</div>
            <button onClick={() => S.removeFood(e.id)} style={{ border: 'none', background: 'transparent', color: 'var(--faint)', cursor: 'pointer', padding: 4 }}><I.x size={16} /></button>
          </div>
        ))}
        {entries.length === 0 && (
          <div onClick={onAdd} style={{ padding: '13px 16px', borderTop: '1px solid var(--border)', fontSize: 13, color: 'var(--faint)', cursor: 'pointer' }}>
            Nothing logged — tap to add
          </div>
        )}
      </Card>
    );
  }

  function Diary() {
    const s = window.useVital();
    const t = S.totals(s);
    const tg = s.targets;
    const remaining = tg.budget - t.kcal + s.burnedKcal;
    return (
      <div style={{ paddingBottom: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 2px 16px' }}>
          <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>Diary</h1>
          <Pill icon={<I.calendar size={15} />} label="Today" tone="neutral" />
        </div>

        {/* summary strip */}
        <Card style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 12 }}>
            <div>
              <div style={{ fontSize: 28, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5, lineHeight: 1 }}>{remaining.toLocaleString()}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600, marginTop: 3 }}>kcal remaining</div>
            </div>
            <div style={{ textAlign: 'right', fontSize: 12.5, color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>
              <span style={{ color: 'var(--text)', fontWeight: 700 }}>{t.kcal.toLocaleString()}</span> eaten · <span style={{ color: 'var(--text)', fontWeight: 700 }}>{s.burnedKcal}</span> burned
            </div>
          </div>
          <ProgressBar value={t.kcal} max={tg.budget} height={9} />
          <div style={{ marginTop: 16 }}><MacroBars totals={t} targets={tg} compact /></div>
        </Card>

        {MEALS.map((m) => (
          <MealGroup key={m} meal={m} entries={s.diary.filter((e) => e.meal === m)} onAdd={() => S.push('foodSearch', { meal: m })} />
        ))}
      </div>
    );
  }

  // ---------- FOOD SEARCH ----------
  function FoodSearch({ params }) {
    window.useVital();
    const [q, setQ] = React.useState('');
    const [meal, setMeal] = React.useState(params.meal || 'Lunch');
    const [scanning, setScanning] = React.useState(!!params.scan);
    const results = q.trim()
      ? FOODS.filter((f) => (f.name + ' ' + f.brand).toLowerCase().includes(q.toLowerCase()))
      : FOODS.filter((f) => RECENT.includes(f.name));

    React.useEffect(() => {
      if (!scanning) return;
      const t = setTimeout(() => { setScanning(false); setQ('Protein Bar'); }, 1800);
      return () => clearTimeout(t);
    }, [scanning]);

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <Header title="Add food" onBack={() => S.pop()} />
        <div style={{ padding: '4px 18px 12px' }}>
          <Segmented full options={MEALS} value={meal} onChange={setMeal} />
          <div style={{ position: 'relative', marginTop: 12 }}>
            <I.search size={18} style={{ position: 'absolute', left: 14, top: 15, color: 'var(--muted)' }} />
            <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search 1M+ foods"
              style={{ width: '100%', boxSizing: 'border-box', height: 48, padding: '0 44px 0 42px', borderRadius: 14, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', fontSize: 15, fontFamily: 'inherit', outline: 'none' }} />
            <button onClick={() => setScanning(true)} style={{ position: 'absolute', right: 8, top: 8, width: 32, height: 32, borderRadius: 10, border: 'none', background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
              <I.scan size={18} />
            </button>
          </div>
        </div>

        {scanning ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, color: 'var(--muted)' }}>
            <div className="vital-scan" style={{ width: 120, height: 120, borderRadius: 24, border: '2px solid var(--accent)', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <I.scan size={46} style={{ color: 'var(--accent)' }} />
            </div>
            <div style={{ fontWeight: 600 }}>Scanning barcode…</div>
          </div>
        ) : (
          <div style={{ flex: 1, overflowY: 'auto', padding: '0 18px 18px' }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1, margin: '6px 2px 10px' }}>
              {q.trim() ? `${results.length} results` : 'Recent'}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {results.map((f, i) => (
                <div key={i} onClick={() => S.push('foodDetail', { food: f, meal })} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderRadius: 14, background: 'var(--surface)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                  <div style={{ width: 38, height: 38, borderRadius: 11, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', flexShrink: 0 }}>
                    <I.fork size={18} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 14.5, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{f.name}</span>
                      {f.verified && <I.check size={13} sw={3} style={{ color: 'var(--accent)', flexShrink: 0 }} />}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--muted)' }}>{f.brand ? f.brand + ' · ' : ''}{f.unit} · {f.kcal} kcal</div>
                  </div>
                  <div style={{ width: 28, height: 28, borderRadius: 999, border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)', flexShrink: 0 }}>
                    <I.plus size={16} sw={2.5} />
                  </div>
                </div>
              ))}
              {results.length === 0 && (
                <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--faint)' }}>
                  <I.search size={32} style={{ marginBottom: 10, opacity: 0.5 }} />
                  <div style={{ fontSize: 14 }}>No foods match “{q}”.</div>
                  <div style={{ fontSize: 12.5, marginTop: 4 }}>Try a barcode scan instead.</div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ---------- FOOD DETAIL ----------
  function FoodDetail({ params }) {
    window.useVital();
    const f = params.food;
    const [qty, setQty] = React.useState(1);
    const [meal, setMeal] = React.useState(params.meal || 'Lunch');
    const scale = (v) => Math.round(v * qty * 10) / 10;
    const macros = [
      { k: 'Protein', v: scale(f.p), c: 'var(--c-protein)', cal: scale(f.p) * 4 },
      { k: 'Carbs', v: scale(f.c), c: 'var(--c-carbs)', cal: scale(f.c) * 4 },
      { k: 'Fat', v: scale(f.f), c: 'var(--c-fat)', cal: scale(f.f) * 9 },
    ];
    const totalCal = Math.round(f.kcal * qty);
    const ringTotal = macros.reduce((a, m) => a + m.cal, 0) || 1;

    function add() {
      S.addFood({ meal, name: f.name, brand: f.brand, qty, unit: f.unit, kcal: totalCal, p: scale(f.p), c: scale(f.c), f: scale(f.f), fib: scale(f.fib), src: f.src, verified: f.verified });
      S.resetStack();
      S.setTab('log');
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <Header title="" onBack={() => S.pop()} />
        <div style={{ flex: 1, overflowY: 'auto', padding: '0 22px 18px' }}>
          <h1 style={{ margin: '0 0 8px', fontSize: 24, fontWeight: 800, letterSpacing: -0.6, lineHeight: 1.12, fontFamily: 'var(--font-display)' }}>{f.name}</h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', color: 'var(--muted)', fontSize: 13.5, marginBottom: 22 }}>
            <span style={{ whiteSpace: 'nowrap' }}>{f.brand ? f.brand + ' · ' : ''}per {f.unit}</span>
            {f.verified && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, color: 'var(--accent)', fontWeight: 700, whiteSpace: 'nowrap' }}><I.check size={13} sw={3} /> Verified</span>}
          </div>

          {/* calorie + macro donut */}
          <Card style={{ display: 'flex', alignItems: 'center', gap: 22, marginBottom: 16 }}>
            <MacroDonut macros={macros} total={ringTotal} kcal={totalCal} />
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12 }}>
              {macros.map((m) => (
                <div key={m.k} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 999, background: m.c }} />
                  <span style={{ flex: 1, fontSize: 13.5, color: 'var(--muted)', fontWeight: 600 }}>{m.k}</span>
                  <span style={{ fontWeight: 700, fontSize: 14, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{m.v} g</span>
                </div>
              ))}
            </div>
          </Card>

          {/* meal + serving */}
          <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1, margin: '6px 2px 10px' }}>Meal</div>
          <Segmented full options={MEALS} value={meal} onChange={setMeal} />
          <Card style={{ marginTop: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14.5 }}>Servings</div>
              <div style={{ fontSize: 12.5, color: 'var(--muted)' }}>{f.unit}</div>
            </div>
            <Stepper value={qty} onChange={setQty} step={0.5} min={0.5} max={20} />
          </Card>
        </div>

        <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
          <Button full size="lg" onClick={add} icon={<I.plus size={20} sw={2.5} />}>Add to {meal} · {totalCal} kcal</Button>
        </div>
      </div>
    );
  }

  function MacroDonut({ macros, total, kcal }) {
    const size = 104, sw = 13, r = (size - sw) / 2, C = 2 * Math.PI * r;
    let off = 0;
    return (
      <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--track)" strokeWidth={sw} />
          {macros.map((m, i) => {
            const frac = m.cal / total;
            const seg = <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={m.c} strokeWidth={sw}
              strokeDasharray={`${C * frac} ${C}`} strokeDashoffset={-C * off} />;
            off += frac;
            return seg;
          })}
        </svg>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontSize: 22, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5, lineHeight: 1 }}>{kcal}</div>
          <div style={{ fontSize: 9.5, color: 'var(--muted)', fontWeight: 700, letterSpacing: 0.5 }}>KCAL</div>
        </div>
      </div>
    );
  }

  // ---------- AI SNAP ----------
  function AiSnap() {
    window.useVital();
    const [phase, setPhase] = React.useState('aim'); // aim | analyzing | result
    const detected = [
      { name: 'Grilled chicken', kcal: 220, p: 41, c: 0, f: 5, fib: 0, conf: 0.94 },
      { name: 'Brown rice', kcal: 170, p: 4, c: 36, f: 1.4, fib: 2.5, conf: 0.88 },
      { name: 'Steamed broccoli', kcal: 55, p: 3.7, c: 11, f: 0.6, fib: 5, conf: 0.81 },
    ];
    const [items, setItems] = React.useState(detected.map((d) => ({ ...d, on: true })));
    const sum = items.filter((i) => i.on).reduce((a, i) => ({ kcal: a.kcal + i.kcal, p: a.p + i.p, c: a.c + i.c, f: a.f + i.f, fib: a.fib + i.fib }), { kcal: 0, p: 0, c: 0, f: 0, fib: 0 });

    React.useEffect(() => {
      if (phase !== 'analyzing') return;
      const t = setTimeout(() => setPhase('result'), 2100);
      return () => clearTimeout(t);
    }, [phase]);

    function logAll() {
      items.filter((i) => i.on).forEach((i) => S.addFood({ meal: 'Lunch', name: i.name, brand: 'AI estimate', qty: 1, unit: 'serving', kcal: i.kcal, p: i.p, c: i.c, f: i.f, fib: i.fib, src: 'ai', verified: false }));
      S.resetStack(); S.setTab('log');
    }

    if (phase === 'result') {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <Header title="Review meal" onBack={() => S.pop()} />
          <div style={{ flex: 1, overflowY: 'auto', padding: '0 22px 18px' }}>
            <div style={{ background: 'var(--surface2)', borderRadius: 20, overflow: 'hidden', marginBottom: 8 }}>
              <image-slot id="aisnap-meal" shape="rounded" radius="20" fit="cover" placeholder="Drop your meal photo"
                style={{ display: 'block', width: '100%', height: '150px', color: '#9aa1ab' }}></image-slot>
            </div>
            <p style={{ fontSize: 13, color: 'var(--muted)', margin: '12px 2px 16px', lineHeight: 1.45 }}>
              We detected <b style={{ color: 'var(--text)' }}>{items.length} items</b>. Toggle anything we got wrong, then log.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {items.map((it, idx) => (
                <div key={idx} onClick={() => setItems((p) => p.map((x, i) => i === idx ? { ...x, on: !x.on } : x))}
                  style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 14px', borderRadius: 14, background: it.on ? 'var(--surface)' : 'var(--surface2)', border: it.on ? '1px solid var(--border)' : '1px dashed var(--border)', cursor: 'pointer', opacity: it.on ? 1 : 0.55 }}>
                  <div style={{ width: 22, height: 22, borderRadius: 7, background: it.on ? 'var(--accent)' : 'transparent', border: it.on ? 'none' : '2px solid var(--border)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{it.on && <I.check size={14} sw={3} />}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14.5 }}>{it.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--muted)' }}>{it.kcal} kcal · P{it.p} C{it.c} F{it.f}</div>
                  </div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: it.conf > 0.85 ? 'var(--accent)' : 'var(--muted)' }}>{Math.round(it.conf * 100)}%</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
            <Button full size="lg" onClick={logAll}>Log {Math.round(sum.kcal)} kcal · {items.filter(i => i.on).length} items</Button>
          </div>
        </div>
      );
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#08090A', color: '#fff' }}>
        <Header title="AI meal scan" onBack={() => S.pop()} dark />
        <div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', inset: 24, borderRadius: 28, background: 'linear-gradient(135deg,#1a1d22,#0d0f12)' }} />
          {/* framing brackets */}
          <div style={{ position: 'absolute', inset: 48 }}>
            {[[0,0],[1,0],[0,1],[1,1]].map(([x,y],i) => (
              <div key={i} style={{ position: 'absolute', width: 34, height: 34, [x?'right':'left']: 0, [y?'bottom':'top']: 0,
                borderTop: y?'none':'3px solid var(--accent)', borderBottom: y?'3px solid var(--accent)':'none',
                borderLeft: x?'none':'3px solid var(--accent)', borderRight: x?'3px solid var(--accent)':'none',
                borderRadius: 6 }} />
            ))}
          </div>
          {phase === 'analyzing' ? (
            <div style={{ textAlign: 'center', position: 'relative' }}>
              <div className="vital-spin" style={{ width: 54, height: 54, borderRadius: 999, border: '3px solid rgba(255,255,255,0.15)', borderTopColor: 'var(--accent)', margin: '0 auto 16px' }} />
              <div style={{ fontWeight: 600 }}>Analyzing your plate…</div>
              <div style={{ fontSize: 12.5, color: 'rgba(255,255,255,0.5)', marginTop: 4 }}>Identifying foods & portions</div>
            </div>
          ) : (
            <div style={{ textAlign: 'center', position: 'relative', color: 'rgba(255,255,255,0.65)' }}>
              <I.camera size={40} /><div style={{ fontSize: 13.5, marginTop: 10, maxWidth: 180 }}>Center your meal in the frame</div>
            </div>
          )}
        </div>
        <div style={{ padding: '20px 22px calc(var(--safe-bottom) + 22px)', display: 'flex', justifyContent: 'center' }}>
          <button onClick={() => setPhase('analyzing')} disabled={phase === 'analyzing'}
            style={{ width: 72, height: 72, borderRadius: 999, border: '5px solid rgba(255,255,255,0.25)', background: 'var(--accent)', cursor: 'pointer', opacity: phase === 'analyzing' ? 0.5 : 1 }} />
        </div>
      </div>
    );
  }

  // shared header
  function Header({ title, onBack, dark }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 'var(--safe-top) 18px 12px' }}>
        <button onClick={onBack} style={{ width: 38, height: 38, borderRadius: 999, border: dark ? '1px solid rgba(255,255,255,0.18)' : '1px solid var(--border)', background: dark ? 'rgba(255,255,255,0.08)' : 'var(--surface)', color: dark ? '#fff' : 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}>
          <I.chevL size={20} />
        </button>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 800, letterSpacing: -0.3, fontFamily: 'var(--font-display)', flex: 1, whiteSpace: 'nowrap' }}>{title}</h2>
      </div>
    );
  }

  window.VitalScreens = window.VitalScreens || {};
  Object.assign(window.VitalScreens, { Diary, FoodSearch, FoodDetail, AiSnap });
})();


/* ===== app/screens-workout.jsx ===== */
// screens-workout.jsx — workout overview + in-gym player (set tracker + rest timer).
(function () {
  const I = window.VIcon;
  const { Card, Button, ProgressBar, Pill, MazeBg } = window.V;
  const S = window.VitalStore;

  const PLAN = {
    title: 'Upper Body • Push',
    meta: '5 exercises · ~48 min · 320 kcal',
    exercises: [
      { name: 'Barbell Bench Press', sets: 4, reps: '8–10', weight: '60 kg', rest: 90, muscle: 'Chest' },
      { name: 'Incline Dumbbell Press', sets: 3, reps: '10–12', weight: '22 kg', rest: 75, muscle: 'Upper chest' },
      { name: 'Overhead Press', sets: 3, reps: '8–10', weight: '40 kg', rest: 90, muscle: 'Shoulders' },
      { name: 'Cable Lateral Raise', sets: 3, reps: '12–15', weight: '7 kg', rest: 60, muscle: 'Side delts' },
      { name: 'Tricep Rope Pushdown', sets: 3, reps: '12–15', weight: '25 kg', rest: 60, muscle: 'Triceps' },
    ],
  };

  function WorkoutHome() {
    const s = window.useVital();
    const totalSets = PLAN.exercises.reduce((a, e) => a + e.sets, 0);
    const week = [
      { d: 'Mon', name: 'Upper • Push', done: true },
      { d: 'Tue', name: 'Lower • Quads', done: true },
      { d: 'Wed', name: 'Rest', rest: true },
      { d: 'Thu', name: 'Upper • Pull', done: true },
      { d: 'Fri', name: 'Upper • Push', today: true },
      { d: 'Sat', name: 'Lower • Posterior' },
      { d: 'Sun', name: 'Rest', rest: true },
    ];
    return (
      <div style={{ paddingBottom: 18 }}>
        <div style={{ padding: '6px 2px 16px' }}>
          <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>Train</h1>
          <div style={{ fontSize: 13.5, color: 'var(--muted)', marginTop: 2 }}>Week 3 · Push / Pull / Legs</div>
        </div>

        {/* today hero */}
        <Card accent style={{ position: 'relative', overflow: 'hidden', paddingTop: 20, paddingBottom: 20 }}>
          <MazeBg opacity={0.1} />
          <div style={{ position: 'relative' }}>
            <div style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1.5, opacity: 0.65 }}>Today</div>
            <div style={{ fontSize: 27, fontWeight: 800, letterSpacing: -0.6, marginTop: 6, fontFamily: 'var(--font-display)' }}>{PLAN.title}</div>
            <div style={{ fontSize: 13.5, opacity: 0.8, marginTop: 4, fontWeight: 600 }}>{PLAN.meta}</div>
            <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
              <button onClick={() => S.push('workoutPlayer', {})} style={{ flex: 1, height: 50, borderRadius: 14, border: 'none', background: 'var(--on-accent)', color: 'var(--accent)', fontWeight: 800, fontSize: 15.5, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                <I.play size={18} /> Start workout
              </button>
            </div>
          </div>
        </Card>

        {/* exercise list */}
        <div style={{ margin: '18px 2px 12px', fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>{PLAN.exercises.length} exercises · {totalSets} sets</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {PLAN.exercises.map((e, i) => (
            <Card key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14 }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: 'var(--surface2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', fontWeight: 800, fontFamily: 'var(--font-display)', flexShrink: 0 }}>{i + 1}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 14.5 }}>{e.name}</div>
                <div style={{ fontSize: 12.5, color: 'var(--muted)' }}>{e.sets} × {e.reps} · {e.weight}</div>
              </div>
              <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--accent)', background: 'var(--accent-soft)', padding: '4px 9px', borderRadius: 999 }}>{e.muscle}</span>
            </Card>
          ))}
        </div>

        {/* week strip */}
        <div style={{ margin: '22px 2px 12px', fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>This week</div>
        <div style={{ display: 'flex', gap: 7 }}>
          {week.map((w, i) => (
            <div key={i} style={{
              flex: 1, textAlign: 'center', padding: '12px 4px', borderRadius: 14,
              background: w.today ? 'var(--accent)' : 'var(--surface)', color: w.today ? 'var(--on-accent)' : 'var(--text)',
              border: w.today ? 'none' : '1px solid var(--border)',
            }}>
              <div style={{ fontSize: 10.5, fontWeight: 700, opacity: 0.7, textTransform: 'uppercase' }}>{w.d}</div>
              <div style={{ margin: '8px auto 0', width: 24, height: 24, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: w.done ? 'var(--accent-soft)' : w.today ? 'rgba(0,0,0,0.15)' : 'var(--surface2)',
                color: w.done ? 'var(--accent)' : 'inherit' }}>
                {w.done ? <I.check size={14} sw={3} /> : w.rest ? <span style={{ fontSize: 9, fontWeight: 700, opacity: 0.6 }}>—</span> : <I.dumbbell size={13} />}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ---------- PLAYER ----------
  function WorkoutPlayer() {
    window.useVital();
    const [exIndex, setExIndex] = React.useState(0);
    const [done, setDone] = React.useState(PLAN.exercises.map(() => 0)); // sets completed per exercise
    const [resting, setResting] = React.useState(false);
    const [restLeft, setRestLeft] = React.useState(0);
    const [finished, setFinished] = React.useState(false);
    const ex = PLAN.exercises[exIndex];
    const setsDone = done[exIndex];
    const totalDone = done.reduce((a, b) => a + b, 0);
    const totalSets = PLAN.exercises.reduce((a, e) => a + e.sets, 0);

    React.useEffect(() => {
      if (!resting) return;
      if (restLeft <= 0) { setResting(false); return; }
      const t = setTimeout(() => setRestLeft((r) => r - 1), 1000);
      return () => clearTimeout(t);
    }, [resting, restLeft]);

    function completeSet() {
      const newCount = Math.min(ex.sets, setsDone + 1);
      const nd = done.slice(); nd[exIndex] = newCount; setDone(nd);
      if (newCount < ex.sets) {
        setRestLeft(ex.rest); setResting(true);
      } else {
        // exercise complete → advance
        if (exIndex < PLAN.exercises.length - 1) {
          setTimeout(() => { setExIndex(exIndex + 1); setRestLeft(PLAN.exercises[exIndex + 1].rest); setResting(true); }, 250);
        } else {
          setFinished(true);
        }
      }
    }

    if (finished) {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--accent)', color: 'var(--on-accent)', position: 'relative', overflow: 'hidden' }}>
          <MazeBg opacity={0.1} />
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: 30, position: 'relative' }}>
            <div style={{ width: 88, height: 88, borderRadius: 999, background: 'rgba(0,0,0,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 22 }}>
              <I.check size={46} sw={3} />
            </div>
            <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, opacity: 0.7 }}>Workout complete</div>
            <h1 style={{ fontSize: 34, fontWeight: 800, letterSpacing: -1, margin: '10px 0 4px', fontFamily: 'var(--font-display)' }}>Nice work.</h1>
            <p style={{ fontSize: 15, opacity: 0.82, margin: '0 0 30px', fontWeight: 600 }}>{totalSets} sets · ~48 min · 320 kcal burned</p>
            <div style={{ display: 'flex', gap: 28, marginBottom: 36 }}>
              <Stat big label="Sets" value={totalSets} />
              <Stat big label="Volume" value="6.4t" />
              <Stat big label="kcal" value="320" />
            </div>
          </div>
          <div style={{ padding: '0 22px calc(var(--safe-bottom) + 16px)', position: 'relative' }}>
            <button onClick={() => { S.pop(); S.toast('Workout logged'); }} style={{ width: '100%', height: 54, borderRadius: 14, border: 'none', background: 'var(--on-accent)', color: 'var(--accent)', fontWeight: 800, fontSize: 16, fontFamily: 'inherit', cursor: 'pointer' }}>Done</button>
          </div>
        </div>
      );
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        {/* top bar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 'var(--safe-top) 18px 10px' }}>
          <button onClick={() => S.pop()} style={{ width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><I.x size={20} /></button>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', marginBottom: 5 }}>
              <span>Exercise {exIndex + 1} of {PLAN.exercises.length}</span>
              <span>{totalDone}/{totalSets} sets</span>
            </div>
            <ProgressBar value={totalDone} max={totalSets} height={6} />
          </div>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '14px 22px 18px' }}>
          <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: 1 }}>{ex.muscle}</div>
          <h1 style={{ margin: '6px 0 4px', fontSize: 28, fontWeight: 800, letterSpacing: -0.8, lineHeight: 1.05, fontFamily: 'var(--font-display)' }}>{ex.name}</h1>
          <div style={{ fontSize: 14.5, color: 'var(--muted)', fontWeight: 600 }}>Target: {ex.reps} reps · {ex.weight}</div>

          {/* rest timer OR set tracker */}
          {resting ? (
            <Card style={{ marginTop: 20, textAlign: 'center', paddingTop: 28, paddingBottom: 28 }}>
              <RestRing total={ex.rest} left={restLeft} />
              <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginTop: 22 }}>
                <button onClick={() => setRestLeft((r) => r + 15)} style={restBtn}>+15s</button>
                <button onClick={() => { setResting(false); setRestLeft(0); }} style={{ ...restBtn, background: 'var(--accent)', color: 'var(--on-accent)', border: 'none' }}>Skip rest</button>
              </div>
            </Card>
          ) : (
            <div style={{ marginTop: 20 }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {Array.from({ length: ex.sets }).map((_, i) => {
                  const isDone = i < setsDone;
                  const isCurrent = i === setsDone;
                  return (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', borderRadius: 16,
                      background: isCurrent ? 'var(--accent-soft)' : 'var(--surface)',
                      border: isCurrent ? '1.5px solid var(--accent)' : '1px solid var(--border)',
                      opacity: isDone ? 0.55 : 1,
                    }}>
                      <div style={{ width: 30, height: 30, borderRadius: 999, background: isDone ? 'var(--accent)' : 'var(--surface2)', color: isDone ? 'var(--on-accent)' : 'var(--muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13, flexShrink: 0 }}>
                        {isDone ? <I.check size={15} sw={3} /> : i + 1}
                      </div>
                      <div style={{ flex: 1, fontSize: 14, fontWeight: 600 }}>Set {i + 1}</div>
                      <div style={{ fontSize: 13, color: 'var(--muted)', fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{ex.reps} × {ex.weight}</div>
                    </div>
                  );
                })}
              </div>
              <button onClick={completeSet} style={{ width: '100%', marginTop: 16, height: 56, borderRadius: 16, border: 'none', background: 'var(--accent)', color: 'var(--on-accent)', fontWeight: 800, fontSize: 16.5, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, whiteSpace: 'nowrap' }}>
                <I.check size={22} sw={2.8} /> Complete set {setsDone + 1}
              </button>
            </div>
          )}
        </div>

        {/* exercise nav */}
        <div style={{ display: 'flex', gap: 10, padding: '12px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
          <button onClick={() => { setExIndex(Math.max(0, exIndex - 1)); setResting(false); }} disabled={exIndex === 0} style={{ ...navBtn, opacity: exIndex === 0 ? 0.4 : 1 }}><I.chevL size={18} /> Prev</button>
          <button onClick={() => { if (exIndex < PLAN.exercises.length - 1) { setExIndex(exIndex + 1); setResting(false); } }} disabled={exIndex === PLAN.exercises.length - 1} style={{ ...navBtn, opacity: exIndex === PLAN.exercises.length - 1 ? 0.4 : 1 }}>Skip <I.chevR size={18} /></button>
        </div>
      </div>
    );
  }

  function RestRing({ total, left }) {
    const size = 168, sw = 12, r = (size - sw) / 2, C = 2 * Math.PI * r;
    const pct = left / total;
    const mm = Math.floor(left / 60), ss = left % 60;
    return (
      <div style={{ position: 'relative', width: size, height: size, margin: '0 auto' }}>
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--track)" strokeWidth={sw} />
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--accent)" strokeWidth={sw} strokeLinecap="round"
            strokeDasharray={C} strokeDashoffset={C * (1 - pct)} style={{ transition: 'stroke-dashoffset 1s linear' }} />
        </svg>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1.5 }}>Rest</div>
          <div style={{ fontSize: 44, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -1, fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>{mm}:{ss.toString().padStart(2, '0')}</div>
        </div>
      </div>
    );
  }

  function Stat({ label, value, big }) {
    return (
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: big ? 30 : 20, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5 }}>{value}</div>
        <div style={{ fontSize: 11, fontWeight: 700, opacity: 0.7, textTransform: 'uppercase', letterSpacing: 0.8, marginTop: 2 }}>{label}</div>
      </div>
    );
  }

  const restBtn = { padding: '11px 20px', borderRadius: 12, border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)', fontWeight: 700, fontSize: 13.5, fontFamily: 'inherit', cursor: 'pointer' };
  const navBtn = { flex: 1, height: 46, borderRadius: 12, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', fontWeight: 700, fontSize: 14, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 };

  window.VitalScreens = window.VitalScreens || {};
  Object.assign(window.VitalScreens, { WorkoutHome, WorkoutPlayer });
})();


/* ===== app/screens-misc.jsx ===== */
// screens-misc.jsx — Plan (meal suggestions), Profile, Paywall modal.
(function () {
  const I = window.VIcon;
  const { Card, Button, ProgressBar, Pill, MazeBg, Sparkline, SectionHeader, Disclaimer } = window.V;
  const S = window.VitalStore;

  // ---------- PLAN ----------
  const MEAL_IDEAS = [
    { id: 'oats', meal: 'Breakfast', name: 'Protein Oats & Berries', kcal: 420, p: 32, c: 52, f: 9, tag: 'High protein', mins: 8 },
    { id: 'chickenbowl', meal: 'Lunch', name: 'Chicken & Quinoa Bowl', kcal: 540, p: 46, c: 52, f: 16, tag: 'Balanced', mins: 15 },
    { id: 'salmon', meal: 'Dinner', name: 'Salmon, Greens & Sweet Potato', kcal: 610, p: 44, c: 41, f: 27, tag: 'Omega-3', mins: 22 },
    { id: 'yogurt', meal: 'Snack', name: 'Greek Yogurt & Almonds', kcal: 250, p: 22, c: 14, f: 12, tag: 'Quick', mins: 2 },
  ];

  function Plan() {
    const s = window.useVital();
    const tg = s.targets;
    const planned = MEAL_IDEAS.reduce((a, m) => a + m.kcal, 0);
    return (
      <div style={{ paddingBottom: 18 }}>
        <div style={{ padding: '6px 2px 16px' }}>
          <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>Plan</h1>
          <div style={{ fontSize: 13.5, color: 'var(--muted)', marginTop: 2 }}>A day that hits your {tg.budget.toLocaleString()} kcal target</div>
        </div>

        {/* summary */}
        <Card style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 16 }}>
          <div style={{ width: 48, height: 48, borderRadius: 14, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><I.leaf size={24} /></div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 15 }}>Today’s suggested menu</div>
            <div style={{ fontSize: 12.5, color: 'var(--muted)' }}>{planned.toLocaleString()} kcal · {s.onboarding.diet} · 4 meals</div>
          </div>
          <button onClick={() => S.toast('Menu refreshed')} style={{ width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><I.sync size={18} /></button>
        </Card>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {MEAL_IDEAS.map((m, i) => (
            <Card key={i} style={{ padding: 0, overflow: 'hidden' }} onClick={() => S.push('recipe', { id: m.id })}>
              <div style={{ height: 110, position: 'relative', display: 'flex', alignItems: 'flex-end', padding: 12, overflow: 'hidden', background: 'var(--surface2)' }}>
                <image-slot id={'plan-thumb-' + m.id} shape="rect" fit="cover" placeholder="Drop photo"
                  style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', color: '#9aa1ab' }}></image-slot>
                <span style={{ position: 'relative', fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--on-accent)', background: 'var(--accent)', padding: '4px 10px', borderRadius: 999 }}>{m.meal}</span>
                <div style={{ position: 'absolute', right: 12, top: 12, display: 'flex', gap: 6 }}>
                  <span style={{ fontSize: 11, fontWeight: 700, color: '#fff', background: 'rgba(0,0,0,0.45)', backdropFilter: 'blur(6px)', WebkitBackdropFilter: 'blur(6px)', padding: '4px 9px', borderRadius: 999, display: 'inline-flex', alignItems: 'center', gap: 4 }}><I.clock size={12} /> {m.mins}m</span>
                </div>
              </div>
              <div style={{ padding: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
                  <div style={{ fontWeight: 700, fontSize: 15.5, flex: 1 }}>{m.name}</div>
                  <div style={{ fontWeight: 800, fontSize: 15, fontFamily: 'var(--font-display)' }}>{m.kcal}</div>
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 10, alignItems: 'center' }}>
                  <MacroTag c="var(--c-protein)" v={m.p} k="P" />
                  <MacroTag c="var(--c-carbs)" v={m.c} k="C" />
                  <MacroTag c="var(--c-fat)" v={m.f} k="F" />
                  <div style={{ flex: 1 }} />
                  <button onClick={(e) => { e.stopPropagation(); S.addFood({ meal: m.meal, name: m.name, brand: 'Vital plan', qty: 1, unit: 'serving', kcal: m.kcal, p: m.p, c: m.c, f: m.f, fib: 5, src: 'plan', verified: true }); }}
                    style={{ height: 34, padding: '0 14px', borderRadius: 10, border: 'none', background: 'var(--accent)', color: 'var(--on-accent)', fontWeight: 700, fontSize: 13, fontFamily: 'inherit', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                    <I.plus size={15} sw={2.5} /> Log
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  function MacroTag({ c, v, k }) {
    return (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 600, color: 'var(--muted)' }}>
        <span style={{ width: 8, height: 8, borderRadius: 999, background: c }} />{v}g {k}
      </span>
    );
  }

  // ---------- PROFILE ----------
  function Profile({ onReplayOnboarding }) {
    const s = window.useVital();
    const tg = s.targets;
    const ob = s.onboarding;
    const goalKg = ob.targetWeightKg;
    return (
      <div style={{ paddingBottom: 18 }}>
        <div style={{ padding: '6px 2px 16px' }}>
          <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, letterSpacing: -0.6, fontFamily: 'var(--font-display)' }}>Profile</h1>
        </div>

        {/* identity */}
        <Card style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 14 }}>
          <div style={{ width: 60, height: 60, borderRadius: 999, background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 26, fontFamily: 'var(--font-display)', flexShrink: 0 }}>{(ob.name || 'A')[0]}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 800, fontSize: 19, fontFamily: 'var(--font-display)' }}>{ob.name}</div>
            <div style={{ fontSize: 13, color: 'var(--muted)' }}>{ob.age} · {ob.sex} · {ob.heightCm} cm</div>
          </div>
          <button onClick={onReplayOnboarding} style={{ width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface2)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><I.edit size={17} /></button>
        </Card>

        {/* premium banner */}
        <Card accent onClick={() => S.paywall(true)} style={{ position: 'relative', overflow: 'hidden', marginBottom: 14, cursor: 'pointer' }}>
          <MazeBg opacity={0.1} />
          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(0,0,0,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><I.crown size={24} /></div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 800, fontSize: 16, fontFamily: 'var(--font-display)' }}>Go Vital Pro</div>
              <div style={{ fontSize: 12.5, opacity: 0.82, fontWeight: 600 }}>AI coaching, custom macros & more</div>
            </div>
            <I.chevR size={20} />
          </div>
        </Card>

        {/* weight trend */}
        <Card onClick={() => S.push('progress')} style={{ marginBottom: 14, cursor: 'pointer' }}>
          <SectionHeader title="Progress" action="View all" onAction={() => S.push('progress')} />
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 30, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5 }}>{s.weightLog[s.weightLog.length - 1].kg}<span style={{ fontSize: 14, color: 'var(--muted)' }}> kg</span></span>
            <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)', display: 'inline-flex', alignItems: 'center' }}><I.arrowDown size={14} /> 2.2 kg</span>
            <span style={{ fontSize: 12.5, color: 'var(--muted)' }}>· goal {goalKg} kg</span>
          </div>
          <div style={{ marginTop: 10 }}>
            <Sparkline points={s.weightLog} goal={goalKg} width={300} height={72} />
          </div>
        </Card>

        {/* targets */}
        <Card style={{ marginBottom: 14, padding: 0, overflow: 'hidden' }}>
          <Row icon={<I.target size={19} />} label="Daily calorie target" value={`${tg.budget.toLocaleString()} kcal`} />
          <Row icon={<I.flame size={19} />} label="Maintenance (TDEE)" value={`${tg.tdee.toLocaleString()} kcal`} />
          <Row icon={<I.leaf size={19} />} label="Diet style" value={ob.diet} cap />
          <Row icon={<I.weight size={19} />} label="Goal weight" value={`${goalKg} kg`} last />
        </Card>

        {/* settings */}
        <Card style={{ padding: 0, overflow: 'hidden' }}>
          <Row icon={<I.cog size={19} />} label="Units & preferences" chevron onClick={() => S.toast('Settings')} />
          <Row icon={<I.sync size={19} />} label="Connected apps & devices" chevron onClick={() => S.toast('Health sync')} />
          <Row icon={<I.calendar size={19} />} label="Reminders" value="On" chevron onClick={() => S.toast('Reminders')} last />
        </Card>

        <div style={{ marginTop: 16 }}><Disclaimer /></div>
      </div>
    );
  }

  function Row({ icon, label, value, chevron, onClick, last, cap }) {
    return (
      <div onClick={onClick} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', borderBottom: last ? 'none' : '1px solid var(--border)', cursor: onClick ? 'pointer' : 'default' }}>
        <div style={{ color: 'var(--muted)', flexShrink: 0 }}>{icon}</div>
        <div style={{ flex: 1, fontWeight: 600, fontSize: 14.5 }}>{label}</div>
        {value && <div style={{ fontSize: 13.5, color: 'var(--muted)', fontWeight: 600, textTransform: cap ? 'capitalize' : 'none' }}>{value}</div>}
        {chevron && <I.chevR size={18} style={{ color: 'var(--faint)' }} />}
      </div>
    );
  }

  // ---------- PAYWALL ----------
  function Paywall() {
    window.useVital();
    const [plan, setPlan] = React.useState('year');
    const feats = [
      'AI meal scan — unlimited photos',
      'Custom macro & calorie targets',
      'Adaptive coaching that adjusts weekly',
      'Recipe library & auto meal plans',
      'Advanced trends & body analytics',
    ];
    return (
      <div style={{ position: 'absolute', inset: 0, zIndex: 50, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
        <div onClick={() => S.paywall(false)} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(2px)' }} />
        <div style={{ position: 'relative', background: 'var(--bg)', borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: '92%', overflowY: 'auto', boxShadow: '0 -10px 40px rgba(0,0,0,0.3)' }}>
          {/* hero */}
          <div style={{ position: 'relative', background: 'var(--accent)', color: 'var(--on-accent)', padding: '22px 24px 26px', borderTopLeftRadius: 28, borderTopRightRadius: 28, overflow: 'hidden' }}>
            <MazeBg opacity={0.1} />
            <div style={{ position: 'relative' }}>
              <button onClick={() => S.paywall(false)} style={{ position: 'absolute', right: 0, top: 0, width: 32, height: 32, borderRadius: 999, border: 'none', background: 'rgba(0,0,0,0.15)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}><I.x size={18} /></button>
              <div style={{ width: 50, height: 50, borderRadius: 14, background: 'rgba(0,0,0,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}><I.crown size={28} /></div>
              <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1.5, opacity: 0.7 }}>Vital Pro</div>
              <h2 style={{ margin: '4px 0 0', fontSize: 27, fontWeight: 800, letterSpacing: -0.8, lineHeight: 1.1, fontFamily: 'var(--font-display)' }}>Reach your goal faster.</h2>
            </div>
          </div>

          <div style={{ padding: '20px 24px calc(var(--safe-bottom) + 16px)' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>
              {feats.map((f, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 24, height: 24, borderRadius: 999, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><I.check size={15} sw={3} /></div>
                  <span style={{ fontSize: 14.5, fontWeight: 600 }}>{f}</span>
                </div>
              ))}
            </div>

            {/* plans */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <PlanOption active={plan === 'year'} onClick={() => setPlan('year')} title="Annual" price="$59.99 / yr" sub="$4.99 / mo · billed yearly" badge="Save 50%" />
              <PlanOption active={plan === 'month'} onClick={() => setPlan('month')} title="Monthly" price="$9.99 / mo" sub="Billed monthly" />
            </div>

            <Button full size="lg" onClick={() => { S.paywall(false); S.toast('Welcome to Pro 🎉'); }} style={{ marginTop: 18 }}>Start 7-day free trial</Button>
            <div style={{ textAlign: 'center', fontSize: 11.5, color: 'var(--faint)', marginTop: 12, lineHeight: 1.4 }}>
              Then {plan === 'year' ? '$59.99/yr' : '$9.99/mo'}. Cancel anytime. Renews automatically.
            </div>
          </div>
        </div>
      </div>
    );
  }

  function PlanOption({ active, onClick, title, price, sub, badge }) {
    return (
      <div onClick={onClick} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '15px 16px', borderRadius: 16, cursor: 'pointer', background: active ? 'var(--accent-soft)' : 'var(--surface)', border: active ? '1.5px solid var(--accent)' : '1px solid var(--border)' }}>
        <div style={{ width: 22, height: 22, borderRadius: 999, border: active ? 'none' : '2px solid var(--border)', background: active ? 'var(--accent)' : 'transparent', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{active && <I.check size={14} sw={3} />}</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontWeight: 800, fontSize: 15.5 }}>{title}</span>
            {badge && <span style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--on-accent)', background: 'var(--accent)', padding: '2px 8px', borderRadius: 999, textTransform: 'uppercase', letterSpacing: 0.5, whiteSpace: 'nowrap' }}>{badge}</span>}
          </div>
          <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 2 }}>{sub}</div>
        </div>
        <div style={{ fontWeight: 800, fontSize: 15, fontFamily: 'var(--font-display)', whiteSpace: 'nowrap' }}>{price}</div>
      </div>
    );
  }

  window.VitalScreens = window.VitalScreens || {};
  Object.assign(window.VitalScreens, { Plan, Profile, Paywall });
})();


/* ===== app/screens-recipe.jsx ===== */
// screens-recipe.jsx — recipe / meal detail with user-fillable photo slots.
(function () {
  const I = window.VIcon;
  const { Card, Button, Stepper, Segmented, ProgressBar } = window.V;
  const S = window.VitalStore;

  // recipe DB — keyed by id. Quantities are per 1 serving; stepper scales them.
  const RECIPES = {
    oats: {
      id: 'oats', name: 'Protein Oats & Berries', meal: 'Breakfast',
      kcal: 420, p: 32, c: 52, f: 9, fib: 8, mins: 8, level: 'Easy',
      blurb: 'A fast, high-protein start that keeps you full to lunch.',
      ingredients: [
        { q: 40, u: 'g', item: 'Rolled oats' },
        { q: 1, u: 'scoop', item: 'Whey protein, vanilla' },
        { q: 200, u: 'ml', item: 'Semi-skimmed milk' },
        { q: 80, u: 'g', item: 'Mixed berries' },
        { q: 1, u: 'tbsp', item: 'Almond butter' },
        { q: 1, u: 'pinch', item: 'Cinnamon' },
      ],
      steps: [
        'Combine oats and milk in a bowl and microwave for 2 minutes.',
        'Stir through the whey protein until smooth.',
        'Top with berries, a swirl of almond butter and a pinch of cinnamon.',
      ],
    },
    chickenbowl: {
      id: 'chickenbowl', name: 'Chicken & Quinoa Bowl', meal: 'Lunch',
      kcal: 540, p: 46, c: 52, f: 16, fib: 9, mins: 15, level: 'Easy',
      blurb: 'Balanced macros, meal-prep friendly, ready in 15.',
      ingredients: [
        { q: 150, u: 'g', item: 'Chicken breast' },
        { q: 80, u: 'g', item: 'Quinoa, dry' },
        { q: 100, u: 'g', item: 'Cherry tomatoes' },
        { q: 0.5, u: '', item: 'Avocado' },
        { q: 1, u: 'handful', item: 'Baby spinach' },
        { q: 1, u: 'tbsp', item: 'Olive oil' },
      ],
      steps: [
        'Rinse and simmer quinoa for 12 minutes, then fluff.',
        'Season and grill the chicken 4–5 min per side; slice.',
        'Build the bowl with quinoa, spinach, tomatoes and avocado.',
        'Dress with olive oil and a squeeze of lemon.',
      ],
    },
    salmon: {
      id: 'salmon', name: 'Salmon, Greens & Sweet Potato', meal: 'Dinner',
      kcal: 610, p: 44, c: 41, f: 27, fib: 9, mins: 22, level: 'Medium',
      blurb: 'Omega-3 rich and satisfying — a proper plate.',
      ingredients: [
        { q: 140, u: 'g', item: 'Salmon fillet' },
        { q: 200, u: 'g', item: 'Sweet potato' },
        { q: 100, u: 'g', item: 'Tenderstem broccoli' },
        { q: 100, u: 'g', item: 'Asparagus' },
        { q: 1, u: 'tbsp', item: 'Olive oil' },
        { q: 1, u: 'clove', item: 'Garlic' },
      ],
      steps: [
        'Cube the sweet potato, toss in oil, roast at 200°C for 20 min.',
        'Add salmon to the tray for the last 12 minutes.',
        'Steam the broccoli and asparagus until just tender.',
        'Plate up and finish with garlic and lemon.',
      ],
    },
    yogurt: {
      id: 'yogurt', name: 'Greek Yogurt & Almonds', meal: 'Snack',
      kcal: 250, p: 22, c: 14, f: 12, fib: 3, mins: 2, level: 'Easy',
      blurb: 'A two-minute, protein-dense snack.',
      ingredients: [
        { q: 170, u: 'g', item: 'Greek yogurt, 0%' },
        { q: 20, u: 'g', item: 'Almonds' },
        { q: 1, u: 'tsp', item: 'Honey' },
        { q: 1, u: 'handful', item: 'Berries' },
      ],
      steps: [
        'Spoon the yogurt into a bowl.',
        'Top with almonds, a drizzle of honey and berries.',
      ],
    },
  };

  function fmtQ(q) {
    if (q === 0.5) return '½';
    if (Number.isInteger(q)) return String(q);
    return (Math.round(q * 100) / 100).toString();
  }

  function Recipe({ params }) {
    window.useVital();
    const r = RECIPES[params.id] || RECIPES.chickenbowl;
    const [servings, setServings] = React.useState(1);
    const [fav, setFav] = React.useState(false);
    const sc = (v) => Math.round(v * servings);

    function logIt() {
      S.addFood({ meal: r.meal, name: r.name, brand: 'Vital recipe', qty: servings, unit: servings > 1 ? 'servings' : 'serving', kcal: sc(r.kcal), p: sc(r.p), c: sc(r.c), f: sc(r.f), fib: sc(r.fib), src: 'recipe', verified: true });
      S.resetStack();
      S.setTab('log');
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {/* hero photo slot */}
          <div style={{ position: 'relative', background: 'var(--surface2)' }}>
            <image-slot
              id={'recipe-hero-' + r.id}
              shape="rect"
              fit="cover"
              placeholder="Drop a food photo"
              style={{ display: 'block', width: '100%', height: '240px', color: '#9aa1ab' }}
            ></image-slot>
            {/* top controls over the photo */}
            <div style={{ position: 'absolute', top: 'var(--safe-top)', left: 14, right: 14, display: 'flex', justifyContent: 'space-between', pointerEvents: 'none' }}>
              <button onClick={() => S.pop()} style={{ ...glassBtn, pointerEvents: 'auto' }}><I.chevL size={20} /></button>
              <button onClick={() => setFav((f) => !f)} style={{ ...glassBtn, pointerEvents: 'auto', color: fav ? 'var(--accent)' : '#fff' }}>{fav ? <I.starFill size={19} /> : <I.star size={19} />}</button>
            </div>
            {/* gradient + title */}
            <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, padding: '40px 22px 16px', background: 'linear-gradient(to top, rgba(0,0,0,0.78), transparent)', pointerEvents: 'none' }}>
              <span style={{ fontSize: 11, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1.2, color: 'var(--accent)' }}>{r.meal}</span>
              <h1 style={{ margin: '6px 0 0', fontSize: 26, fontWeight: 800, letterSpacing: -0.6, lineHeight: 1.08, color: '#fff', fontFamily: 'var(--font-display)' }}>{r.name}</h1>
            </div>
          </div>

          <div style={{ padding: '18px 22px 18px' }}>
            <p style={{ margin: '0 0 16px', fontSize: 14, color: 'var(--muted)', lineHeight: 1.5 }}>{r.blurb}</p>

            {/* meta chips */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 18 }}>
              <Meta icon={<I.clock size={16} />} label={r.mins + ' min'} />
              <Meta icon={<I.bolt size={16} />} label={r.level} />
              <Meta icon={<I.flame size={16} />} label={sc(r.kcal) + ' kcal'} />
            </div>

            {/* macros per current servings */}
            <Card style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
              <MacroCol k="Protein" v={sc(r.p)} c="var(--c-protein)" />
              <MacroCol k="Carbs" v={sc(r.c)} c="var(--c-carbs)" />
              <MacroCol k="Fat" v={sc(r.f)} c="var(--c-fat)" />
              <MacroCol k="Fiber" v={sc(r.fib)} c="var(--c-fiber)" />
            </Card>

            {/* servings */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 16, fontFamily: 'var(--font-display)' }}>Servings</div>
                <div style={{ fontSize: 12.5, color: 'var(--muted)', whiteSpace: 'nowrap' }}>Scales the ingredients</div>
              </div>
              <Stepper value={servings} onChange={setServings} step={1} min={1} max={8} />
            </div>

            {/* ingredients */}
            <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', margin: '6px 2px 12px' }}>Ingredients</div>
            <Card style={{ padding: 0, overflow: 'hidden', marginBottom: 20 }}>
              {r.ingredients.map((ing, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 16px', borderTop: i ? '1px solid var(--border)' : 'none' }}>
                  <div style={{ width: 8, height: 8, borderRadius: 999, background: 'var(--accent)', flexShrink: 0 }} />
                  <span style={{ flex: 1, fontSize: 14.5, fontWeight: 500 }}>{ing.item}</span>
                  <span style={{ fontSize: 13.5, color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{fmtQ(ing.q * servings)} {ing.u}</span>
                </div>
              ))}
            </Card>

            {/* method */}
            <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', margin: '6px 2px 12px' }}>Method</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {r.steps.map((st, i) => (
                <div key={i} style={{ display: 'flex', gap: 14 }}>
                  <div style={{ width: 30, height: 30, borderRadius: 999, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 14, flexShrink: 0, fontFamily: 'var(--font-display)' }}>{i + 1}</div>
                  <p style={{ margin: 0, fontSize: 14.5, lineHeight: 1.5, paddingTop: 4, color: 'var(--text)' }}>{st}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
          <Button full size="lg" onClick={logIt} icon={<I.plus size={20} sw={2.5} />}>Log to {r.meal} · {sc(r.kcal)} kcal</Button>
        </div>
      </div>
    );
  }

  function Meta({ icon, label }) {
    return (
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 13px', borderRadius: 12, background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)' }}>
        <span style={{ color: 'var(--muted)' }}>{icon}</span>
        <span style={{ fontSize: 13, fontWeight: 700, whiteSpace: 'nowrap' }}>{label}</span>
      </div>
    );
  }
  function MacroCol({ k, v, c }) {
    return (
      <div style={{ flex: 1, textAlign: 'center' }}>
        <div style={{ width: 26, height: 5, borderRadius: 99, background: c, margin: '0 auto 9px' }} />
        <div style={{ fontSize: 19, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.3, fontVariantNumeric: 'tabular-nums' }}>{v}<span style={{ fontSize: 11, color: 'var(--muted)' }}>g</span></div>
        <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 2 }}>{k}</div>
      </div>
    );
  }

  const glassBtn = {
    width: 38, height: 38, borderRadius: 999, border: 'none',
    background: 'rgba(0,0,0,0.42)', backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)',
    color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
  };

  window.VitalRecipes = RECIPES;
  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Recipe = Recipe;
})();


/* ===== app/screens-auth.jsx ===== */
// screens-auth.jsx — Welcome → Sign in / Sign up / Forgot password.
(function () {
  const I = window.VIcon;
  const { Button, MazeBg } = window.V;
  const S = window.VitalStore;

  const inputStyle = {
    width: '100%', boxSizing: 'border-box', height: 52, padding: '0 16px', borderRadius: 14,
    border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)',
    fontSize: 16, fontFamily: 'inherit', outline: 'none', fontWeight: 600,
  };

  function Labeled({ label, children }) {
    return (
      <div>
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 9 }}>{label}</div>
        {children}
      </div>
    );
  }

  function Social({ label, icon }) {
    return (
      <button onClick={() => S.toast('Continuing with ' + label)} style={{
        flex: 1, height: 50, borderRadius: 14, border: '1px solid var(--border)', background: 'var(--surface)',
        color: 'var(--text)', fontWeight: 700, fontSize: 14, fontFamily: 'inherit', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9,
      }}>{icon}{label}</button>
    );
  }

  function AuthHeader({ onBack, title, sub }) {
    return (
      <div style={{ padding: 'var(--safe-top) 24px 0' }}>
        {onBack && <button onClick={onBack} style={{ width: 40, height: 40, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', marginBottom: 18 }}><I.chevL size={20} /></button>}
        <h1 style={{ margin: 0, fontSize: 30, fontWeight: 800, letterSpacing: -1, lineHeight: 1.05, fontFamily: 'var(--font-display)' }}>{title}</h1>
        {sub && <p style={{ margin: '8px 0 0', fontSize: 15, color: 'var(--muted)', lineHeight: 1.4 }}>{sub}</p>}
      </div>
    );
  }

  const APPLE = <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M16 13.5c0 3-2 5.5-3.4 5.5-.8 0-1.2-.5-2.1-.5s-1.4.5-2.2.5C6.8 19 5 16.2 5 13c0-3 1.8-4.5 3.3-4.5.9 0 1.6.5 2.2.5s1.2-.6 2.4-.6c1 0 2 .5 2.6 1.3-1.5 1-1.5 3.2.5 3.8ZM12.9 6.2c.6-.8.5-1.9.4-2.2-.8.1-1.6.6-2 1.2-.4.5-.7 1.3-.6 2 .8.1 1.6-.3 2.2-1Z"/></svg>;
  const GOOG = <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#4285F4" d="M21.6 12.2c0-.6-.1-1.2-.2-1.8H12v3.6h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3Z"/><path fill="#34A853" d="M12 22c2.7 0 5-.9 6.6-2.5l-3.2-2.5c-.9.6-2 .9-3.4.9-2.6 0-4.8-1.7-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.4 13.8a6 6 0 0 1 0-3.6V7.6H3.1a10 10 0 0 0 0 8.8l3.3-2.6Z"/><path fill="#EA4335" d="M12 6.1c1.5 0 2.8.5 3.8 1.5l2.8-2.8A10 10 0 0 0 3.1 7.6l3.3 2.6C7.2 7.8 9.4 6.1 12 6.1Z"/></svg>;

  function Auth({ onApp, onSignup }) {
    window.useVital();
    const [view, setView] = React.useState('welcome'); // welcome | signin | signup | forgot
    const [email, setEmail] = React.useState('');
    const [pw, setPw] = React.useState('');
    const [name, setName] = React.useState('');
    const scrollRef = React.useRef(null);
    React.useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, [view]);

    // ---------- WELCOME ----------
    if (view === 'welcome') {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', padding: '0 28px 36px' }}>
            <MazeBg opacity={0.1} />
            <div style={{ position: 'absolute', top: 'calc(var(--safe-top) + 8px)', left: 28, display: 'flex', alignItems: 'center', gap: 11 }}>
              <div style={{ width: 38, height: 38, borderRadius: 11, background: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 13h4l2.5 6 3-14 2.5 8H20" /></svg>
              </div>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, letterSpacing: -0.5 }}>Vital</span>
            </div>
            <div style={{ position: 'relative' }}>
              <h1 style={{ margin: 0, fontSize: 40, fontWeight: 800, letterSpacing: -1.6, lineHeight: 0.98, fontFamily: 'var(--font-display)' }}>Train smarter.<br />Eat better.</h1>
              <p style={{ margin: '14px 0 0', fontSize: 16, fontWeight: 600, opacity: 0.78, maxWidth: 300, lineHeight: 1.4 }}>Your calories, macros and workouts — one science-backed app.</p>
            </div>
          </div>
          <div style={{ padding: '22px 24px calc(var(--safe-bottom) + 14px)', background: 'var(--bg)', display: 'flex', flexDirection: 'column', gap: 11 }}>
            <Button full size="lg" onClick={() => setView('signup')}>Get started — it’s free</Button>
            <button onClick={() => setView('signin')} style={{ height: 50, borderRadius: 14, border: 'none', background: 'transparent', color: 'var(--text)', fontWeight: 700, fontSize: 15, fontFamily: 'inherit', cursor: 'pointer' }}>
              I already have an account
            </button>
          </div>
        </div>
      );
    }

    // ---------- SIGN IN ----------
    if (view === 'signin') {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <AuthHeader onBack={() => setView('welcome')} title="Welcome back" sub="Pick up right where you left off." />
          <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '26px 24px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
            <Labeled label="Email"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" style={inputStyle} /></Labeled>
            <Labeled label="Password"><input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="••••••••" style={inputStyle} /></Labeled>
            <div style={{ textAlign: 'right', marginTop: -6 }}>
              <span onClick={() => setView('forgot')} style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--accent)', cursor: 'pointer' }}>Forgot password?</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '4px 0' }}>
              <div style={{ flex: 1, height: 1, background: 'var(--border)' }} /><span style={{ fontSize: 12, color: 'var(--faint)', fontWeight: 600 }}>or</span><div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}><Social label="Apple" icon={APPLE} /><Social label="Google" icon={GOOG} /></div>
          </div>
          <div style={{ padding: '14px 24px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)' }}>
            <Button full size="lg" onClick={() => { S.toast('Signed in'); onApp(); }}>Sign in</Button>
          </div>
        </div>
      );
    }

    // ---------- SIGN UP ----------
    if (view === 'signup') {
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <AuthHeader onBack={() => setView('welcome')} title="Create account" sub="Two minutes to your personalised plan." />
          <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '26px 24px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
            <Labeled label="Name"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" style={inputStyle} /></Labeled>
            <Labeled label="Email"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" style={inputStyle} /></Labeled>
            <Labeled label="Password"><input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="At least 8 characters" style={inputStyle} /></Labeled>
            <div style={{ display: 'flex', gap: 10, marginTop: 2 }}><Social label="Apple" icon={APPLE} /><Social label="Google" icon={GOOG} /></div>
            <p style={{ fontSize: 11.5, color: 'var(--faint)', lineHeight: 1.5, margin: '2px 4px 0', textAlign: 'center' }}>By continuing you agree to our Terms and Privacy Policy.</p>
          </div>
          <div style={{ padding: '14px 24px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)' }}>
            <Button full size="lg" onClick={() => { if (name) S.applyOnboarding({ name }); onSignup(); }}>Create account</Button>
          </div>
        </div>
      );
    }

    // ---------- FORGOT ----------
    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <AuthHeader onBack={() => setView('signin')} title="Reset password" sub="We’ll email you a secure reset link." />
        <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '26px 24px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
          <Labeled label="Email"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" style={inputStyle} /></Labeled>
        </div>
        <div style={{ padding: '14px 24px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)' }}>
          <Button full size="lg" onClick={() => { S.toast('Reset link sent'); setView('signin'); }}>Send reset link</Button>
        </div>
      </div>
    );
  }

  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Auth = Auth;
})();


/* ===== app/screens-progress.jsx ===== */
// screens-progress.jsx — weight trend, measurements, progress photos.
(function () {
  const I = window.VIcon;
  const { Card, Button, Segmented, Sparkline, ProgressBar } = window.V;
  const S = window.VitalStore;

  const MEAS = [
    { k: 'Waist', v: 81.5, unit: 'cm', delta: -3.2 },
    { k: 'Chest', v: 102, unit: 'cm', delta: +1.1 },
    { k: 'Hips', v: 95, unit: 'cm', delta: -1.8 },
    { k: 'Arms', v: 36.5, unit: 'cm', delta: +0.9 },
    { k: 'Body fat', v: 18.2, unit: '%', delta: -2.4 },
    { k: 'Resting HR', v: 58, unit: 'bpm', delta: -4 },
  ];

  const POSES = [
    { id: 'front', label: 'Front' },
    { id: 'side', label: 'Side' },
    { id: 'back', label: 'Back' },
  ];

  function Progress() {
    const s = window.useVital();
    const [range, setRange] = React.useState('3M');
    const log = s.weightLog;
    const current = log[log.length - 1].kg;
    const start = log[0].kg;
    const change = +(current - start).toFixed(1);
    const goal = s.onboarding.targetWeightKg;
    const toGoal = +(current - goal).toFixed(1);
    const goalPct = Math.min(100, Math.max(0, ((start - current) / (start - goal)) * 100));

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 'var(--safe-top) 18px 12px' }}>
          <button onClick={() => S.pop()} style={{ width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}><I.chevL size={20} /></button>
          <h2 style={{ margin: 0, fontSize: 18, fontWeight: 800, letterSpacing: -0.3, fontFamily: 'var(--font-display)', flex: 1, whiteSpace: 'nowrap' }}>Progress</h2>
          <button onClick={() => S.toast('Add a weigh-in')} style={{ width: 38, height: 38, borderRadius: 999, border: 'none', background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}><I.plus size={20} sw={2.5} /></button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '6px 18px 18px' }}>
          {/* weight card */}
          <Card style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1 }}>Weight</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 9, marginTop: 4 }}>
                  <span style={{ fontSize: 38, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -1, lineHeight: 1 }}>{current}<span style={{ fontSize: 16, color: 'var(--muted)' }}> kg</span></span>
                  <span style={{ fontSize: 14, fontWeight: 800, color: change <= 0 ? 'var(--accent)' : 'var(--c-fat)', display: 'inline-flex', alignItems: 'center' }}>
                    {change <= 0 ? <I.arrowDown size={15} /> : <I.arrowUp size={15} />}{Math.abs(change)} kg
                  </span>
                </div>
              </div>
              <div style={{ width: 132 }}><Segmented full options={['1M', '3M', '6M', '1Y']} value={range} onChange={setRange} /></div>
            </div>
            <Sparkline points={log} goal={goal} width={320} height={92} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12, fontSize: 12, color: 'var(--muted)', fontWeight: 600 }}>
              <span>Start {start} kg</span>
              <span>Goal {goal} kg</span>
            </div>
            <div style={{ marginTop: 12 }}>
              <ProgressBar value={goalPct} max={100} height={8} />
              <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 8, fontWeight: 600 }}>
                {toGoal > 0 ? <span><b style={{ color: 'var(--text)' }}>{toGoal} kg</b> to your goal · {Math.round(goalPct)}% there</span> : <span style={{ color: 'var(--accent)', fontWeight: 700 }}>Goal reached 🎉</span>}
              </div>
            </div>
          </Card>

          {/* measurements */}
          <div style={{ margin: '6px 2px 12px', fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>Measurements</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
            {MEAS.map((m) => (
              <Card key={m.k} pad={14} onClick={() => S.toast('Log ' + m.k)} style={{ cursor: 'pointer' }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted)' }}>{m.k}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginTop: 6 }}>
                  <span style={{ fontSize: 22, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.4, fontVariantNumeric: 'tabular-nums' }}>{m.v}<span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600, marginLeft: 2 }}>{m.unit}</span></span>
                  <span style={{ fontSize: 12, fontWeight: 800, color: m.delta <= 0 ? 'var(--accent)' : 'var(--c-fat)', display: 'inline-flex', alignItems: 'center', whiteSpace: 'nowrap' }}>
                    {m.delta <= 0 ? <I.arrowDown size={13} /> : <I.arrowUp size={13} />}{Math.abs(m.delta)}
                  </span>
                </div>
              </Card>
            ))}
          </div>

          {/* progress photos */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '6px 2px 12px' }}>
            <span style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>Progress photos</span>
            <span style={{ fontSize: 12.5, color: 'var(--muted)', fontWeight: 600 }}>29 May</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 16 }}>
            {POSES.map((p) => (
              <div key={p.id}>
                <div style={{ background: 'var(--surface2)', borderRadius: 16, overflow: 'hidden' }}>
                  <image-slot id={'progress-' + p.id} shape="rect" fit="cover" placeholder={p.label}
                    style={{ display: 'block', width: '100%', height: '150px', color: '#9aa1ab' }}></image-slot>
                </div>
                <div style={{ textAlign: 'center', fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', marginTop: 7 }}>{p.label}</div>
              </div>
            ))}
          </div>
          <p style={{ fontSize: 12, color: 'var(--faint)', lineHeight: 1.5, margin: '0 4px 18px' }}>
            Drop a photo into each pose to track visual change over time. Photos stay on your device.
          </p>

          {/* history */}
          <div style={{ margin: '6px 2px 12px', fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>Weigh-in history</div>
          <Card style={{ padding: 0, overflow: 'hidden' }}>
            {[...log].reverse().map((w, i, arr) => {
              const prev = arr[i + 1];
              const d = prev ? +(w.kg - prev.kg).toFixed(1) : 0;
              return (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 16px', borderTop: i ? '1px solid var(--border)' : 'none' }}>
                  <I.weight size={18} style={{ color: 'var(--muted)', flexShrink: 0 }} />
                  <span style={{ flex: 1, fontSize: 14, fontWeight: 600 }}>{w.d.replace('-', '/')}</span>
                  <span style={{ fontSize: 14, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{w.kg} kg</span>
                  {prev && <span style={{ fontSize: 12, fontWeight: 700, color: d <= 0 ? 'var(--accent)' : 'var(--c-fat)', width: 50, textAlign: 'right', whiteSpace: 'nowrap' }}>{d <= 0 ? '' : '+'}{d}</span>}
                </div>
              );
            })}
          </Card>
        </div>
      </div>
    );
  }

  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Progress = Progress;
})();


/* ===== app/app-shell.jsx ===== */
// app-shell.jsx — tab bar + router. Renders the active screen for one device.
(function () {
  const I = window.VIcon;
  const S = window.VitalStore;
  const SC = window.VitalScreens;

  const TABS = [
    { key: 'home', label: 'Home', icon: I.home },
    { key: 'log', label: 'Diary', icon: I.log },
    { key: 'workout', label: 'Train', icon: I.dumbbell },
    { key: 'plan', label: 'Plan', icon: I.plan },
    { key: 'profile', label: 'Profile', icon: I.profile },
  ];

  function TabBar({ tab }) {
    return (
      <div style={{
        display: 'flex', alignItems: 'stretch', gap: 2,
        padding: '8px 10px calc(var(--safe-bottom) + 6px)',
        background: 'var(--surface)', borderTop: '1px solid var(--border)',
      }}>
        {TABS.map((t) => {
          const on = t.key === tab;
          const Icon = t.icon;
          return (
            <button key={t.key} onClick={() => S.setTab(t.key)} style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              padding: '6px 0', border: 'none', background: 'transparent', cursor: 'pointer',
              color: on ? 'var(--accent)' : 'var(--muted)', fontFamily: 'inherit',
            }}>
              <Icon size={24} sw={on ? 2.4 : 2} />
              <span style={{ fontSize: 10.5, fontWeight: on ? 800 : 600, letterSpacing: 0.1 }}>{t.label}</span>
            </button>
          );
        })}
      </div>
    );
  }

  function Toast({ msg }) {
    if (!msg) return null;
    return (
      <div style={{ position: 'absolute', left: '50%', bottom: 'calc(var(--safe-bottom) + 86px)', transform: 'translateX(-50%)', zIndex: 40, pointerEvents: 'none' }}>
        <div className="vital-toast" style={{
          background: 'var(--text)', color: 'var(--bg)', padding: '11px 18px', borderRadius: 999,
          fontSize: 13.5, fontWeight: 700, whiteSpace: 'nowrap', boxShadow: 'var(--shadow)',
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <I.check size={16} sw={3} style={{ color: 'var(--accent)' }} />{msg}
        </div>
      </div>
    );
  }

  function tabScreen(tab, metaphor, replay) {
    switch (tab) {
      case 'home': return <SC.Home metaphor={metaphor} />;
      case 'log': return <SC.Diary />;
      case 'workout': return <SC.WorkoutHome />;
      case 'plan': return <SC.Plan />;
      case 'profile': return <SC.Profile onReplayOnboarding={replay} />;
      default: return <SC.Home metaphor={metaphor} />;
    }
  }

  function stackScreen(top) {
    switch (top.screen) {
      case 'foodSearch': return <SC.FoodSearch params={top.params} />;
      case 'foodDetail': return <SC.FoodDetail params={top.params} />;
      case 'aiSnap': return <SC.AiSnap params={top.params} />;
      case 'workoutPlayer': return <SC.WorkoutPlayer params={top.params} />;
      case 'recipe': return <SC.Recipe params={top.params} />;
      case 'progress': return <SC.Progress params={top.params} />;
      default: return null;
    }
  }

  // App: one full instance of Vital for a device. Props: metaphor (calorie hero).
  function VitalApp({ metaphor }) {
    const s = window.useVital();
    const scrollRef = React.useRef(null);
    const top = s.nav.stack[s.nav.stack.length - 1];

    // reset scroll when switching tab / pushing
    React.useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, [s.nav.tab, s.nav.stack.length]);

    let content;
    if (s.mode === 'auth') {
      content = <SC.Auth onApp={() => S.setMode('app')} onSignup={() => S.setMode('onboarding')} />;
    } else if (s.mode === 'onboarding') {
      content = <SC.Onboarding onDone={() => S.setMode('app')} />;
    } else if (top) {
      content = stackScreen(top);
    } else {
      content = (
        <React.Fragment>
          <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', WebkitOverflowScrolling: 'touch', padding: 'var(--safe-top) 18px 14px' }}>
            {tabScreen(s.nav.tab, metaphor, () => S.setMode('onboarding'))}
          </div>
          <TabBar tab={s.nav.tab} />
        </React.Fragment>
      );
    }

    return (
      <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)', color: 'var(--text)', overflow: 'hidden', fontFamily: 'var(--font-body)' }}>
        {content}
        <Toast msg={s.toast} />
        {s.paywall && <SC.Paywall />}
      </div>
    );
  }

  window.VitalApp = VitalApp;
})();

