// screens-progress.jsx — weight trend, measurements, progress photos.
(function () {
  const I = window.VIcon;
  const { Card, Button, Segmented, Sparkline, ProgressBar } = window.V;
  const S = window.VitalStore;

  const MEAS = [
    { k: 'Waist', v: 81.5, unit: 'cm', delta: -3.2 },
    { k: 'Chest', v: 102, unit: 'cm', delta: +1.1 },
    { k: 'Hips', v: 95, unit: 'cm', delta: -1.8 },
    { k: 'Arms', v: 36.5, unit: 'cm', delta: +0.9 },
    { k: 'Body fat', v: 18.2, unit: '%', delta: -2.4 },
    { k: 'Resting HR', v: 58, unit: 'bpm', delta: -4 },
  ];

  const POSES = [
    { id: 'front', label: 'Front' },
    { id: 'side', label: 'Side' },
    { id: 'back', label: 'Back' },
  ];

  function Progress() {
    const s = window.useVital();
    const [range, setRange] = React.useState('3M');
    const log = s.weightLog;
    const current = log[log.length - 1].kg;
    const start = log[0].kg;
    const change = +(current - start).toFixed(1);
    const goal = s.onboarding.targetWeightKg;
    const toGoal = +(current - goal).toFixed(1);
    const goalPct = Math.min(100, Math.max(0, ((start - current) / (start - goal)) * 100));

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 'var(--safe-top) 18px 12px' }}>
          <button onClick={() => S.pop()} style={{ width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}><I.chevL size={20} /></button>
          <h2 style={{ margin: 0, fontSize: 18, fontWeight: 800, letterSpacing: -0.3, fontFamily: 'var(--font-display)', flex: 1, whiteSpace: 'nowrap' }}>Progress</h2>
          <button onClick={() => S.toast('Add a weigh-in')} style={{ width: 38, height: 38, borderRadius: 999, border: 'none', background: 'var(--accent)', color: 'var(--on-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}><I.plus size={20} sw={2.5} /></button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '6px 18px 18px' }}>
          {/* weight card */}
          <Card style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1 }}>Weight</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 9, marginTop: 4 }}>
                  <span style={{ fontSize: 38, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -1, lineHeight: 1 }}>{current}<span style={{ fontSize: 16, color: 'var(--muted)' }}> kg</span></span>
                  <span style={{ fontSize: 14, fontWeight: 800, color: change <= 0 ? 'var(--accent)' : 'var(--c-fat)', display: 'inline-flex', alignItems: 'center' }}>
                    {change <= 0 ? <I.arrowDown size={15} /> : <I.arrowUp size={15} />}{Math.abs(change)} kg
                  </span>
                </div>
              </div>
              <div style={{ width: 132 }}><Segmented full options={['1M', '3M', '6M', '1Y']} value={range} onChange={setRange} /></div>
            </div>
            <Sparkline points={log} goal={goal} width={320} height={92} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12, fontSize: 12, color: 'var(--muted)', fontWeight: 600 }}>
              <span>Start {start} kg</span>
              <span>Goal {goal} kg</span>
            </div>
            <div style={{ marginTop: 12 }}>
              <ProgressBar value={goalPct} max={100} height={8} />
              <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 8, fontWeight: 600 }}>
                {toGoal > 0 ? <span><b style={{ color: 'var(--text)' }}>{toGoal} kg</b> to your goal · {Math.round(goalPct)}% there</span> : <span style={{ color: 'var(--accent)', fontWeight: 700 }}>Goal reached 🎉</span>}
              </div>
            </div>
          </Card>

          {/* measurements */}
          <div style={{ margin: '6px 2px 12px', fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>Measurements</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
            {MEAS.map((m) => (
              <Card key={m.k} pad={14} onClick={() => S.toast('Log ' + m.k)} style={{ cursor: 'pointer' }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted)' }}>{m.k}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginTop: 6 }}>
                  <span style={{ fontSize: 22, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.4, fontVariantNumeric: 'tabular-nums' }}>{m.v}<span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600, marginLeft: 2 }}>{m.unit}</span></span>
                  <span style={{ fontSize: 12, fontWeight: 800, color: m.delta <= 0 ? 'var(--accent)' : 'var(--c-fat)', display: 'inline-flex', alignItems: 'center', whiteSpace: 'nowrap' }}>
                    {m.delta <= 0 ? <I.arrowDown size={13} /> : <I.arrowUp size={13} />}{Math.abs(m.delta)}
                  </span>
                </div>
              </Card>
            ))}
          </div>

          {/* progress photos */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '6px 2px 12px' }}>
            <span style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>Progress photos</span>
            <span style={{ fontSize: 12.5, color: 'var(--muted)', fontWeight: 600 }}>29 May</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 16 }}>
            {POSES.map((p) => (
              <div key={p.id}>
                <div style={{ background: 'var(--surface2)', borderRadius: 16, overflow: 'hidden' }}>
                  <image-slot id={'progress-' + p.id} shape="rect" fit="cover" placeholder={p.label}
                    style={{ display: 'block', width: '100%', height: '150px', color: '#9aa1ab' }}></image-slot>
                </div>
                <div style={{ textAlign: 'center', fontSize: 11.5, fontWeight: 700, color: 'var(--muted)', marginTop: 7 }}>{p.label}</div>
              </div>
            ))}
          </div>
          <p style={{ fontSize: 12, color: 'var(--faint)', lineHeight: 1.5, margin: '0 4px 18px' }}>
            Drop a photo into each pose to track visual change over time. Photos stay on your device.
          </p>

          {/* history */}
          <div style={{ margin: '6px 2px 12px', fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)' }}>Weigh-in history</div>
          <Card style={{ padding: 0, overflow: 'hidden' }}>
            {[...log].reverse().map((w, i, arr) => {
              const prev = arr[i + 1];
              const d = prev ? +(w.kg - prev.kg).toFixed(1) : 0;
              return (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 16px', borderTop: i ? '1px solid var(--border)' : 'none' }}>
                  <I.weight size={18} style={{ color: 'var(--muted)', flexShrink: 0 }} />
                  <span style={{ flex: 1, fontSize: 14, fontWeight: 600 }}>{w.d.replace('-', '/')}</span>
                  <span style={{ fontSize: 14, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{w.kg} kg</span>
                  {prev && <span style={{ fontSize: 12, fontWeight: 700, color: d <= 0 ? 'var(--accent)' : 'var(--c-fat)', width: 50, textAlign: 'right', whiteSpace: 'nowrap' }}>{d <= 0 ? '' : '+'}{d}</span>}
                </div>
              );
            })}
          </Card>
        </div>
      </div>
    );
  }

  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Progress = Progress;
})();
