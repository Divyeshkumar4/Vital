// screens-onboarding.jsx — questionnaire → results reveal. Real Mifflin–St Jeor math via store.
(function () {
  const I = window.VIcon;
  const { Button, Segmented, Stepper, MazeBg, Disclaimer } = window.V;
  const S = window.VitalStore;

  const inputStyle = {
    width: '100%', boxSizing: 'border-box', height: 52, padding: '0 16px', borderRadius: 14,
    border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text)',
    fontSize: 16, fontFamily: 'inherit', outline: 'none', fontWeight: 600,
  };

  const ACTIVITY = [
    { value: 'sedentary', label: 'Sedentary', sub: 'Little or no exercise' },
    { value: 'light', label: 'Light', sub: '1–3 days / week' },
    { value: 'moderate', label: 'Moderate', sub: '3–5 days / week' },
    { value: 'very', label: 'Very active', sub: '6–7 days / week' },
    { value: 'extra', label: 'Extra active', sub: 'Hard daily / physical job' },
  ];
  const GOALS = [
    { value: 'lose', label: 'Lose weight', sub: 'Shed fat at a steady pace' },
    { value: 'maintain', label: 'Maintain', sub: 'Stay where I am, eat smarter' },
    { value: 'gain', label: 'Build muscle', sub: 'Lean gains, fuel training' },
  ];
  const DIETS = [
    { value: 'omnivore', label: 'Omnivore' }, { value: 'highprotein', label: 'High-protein' },
    { value: 'lowcarb', label: 'Low-carb' }, { value: 'vegetarian', label: 'Vegetarian' },
    { value: 'vegan', label: 'Vegan' }, { value: 'mediterranean', label: 'Mediterranean' },
  ];

  function Field({ label, children, hint }) {
    return (
      <div>
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 }}>{label}</div>
        {children}
        {hint && <div style={{ fontSize: 11.5, color: 'var(--faint)', marginTop: 8 }}>{hint}</div>}
      </div>
    );
  }

  function ChoiceRow({ title, sub, active, onClick }) {
    return (
      <div onClick={onClick} style={{
        display: 'flex', alignItems: 'center', gap: 14, padding: '15px 16px',
        borderRadius: 16, cursor: 'pointer', transition: 'all .15s',
        background: active ? 'var(--accent-soft)' : 'var(--surface)',
        border: active ? '1.5px solid var(--accent)' : '1px solid var(--border)',
      }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 15 }}>{title}</div>
          {sub && <div style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 2 }}>{sub}</div>}
        </div>
        <div style={{
          width: 22, height: 22, borderRadius: 999, flexShrink: 0,
          border: active ? 'none' : '2px solid var(--border)',
          background: active ? 'var(--accent)' : 'transparent',
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--on-accent)',
        }}>{active && <I.check size={14} sw={3} />}</div>
      </div>
    );
  }

  function StatChip({ label, value, unit }) {
    return (
      <div style={{ flex: 1, textAlign: 'center', padding: '14px 8px', borderRadius: 16, background: 'var(--surface2)', border: '1px solid var(--border)' }}>
        <div style={{ fontSize: 23, fontWeight: 800, letterSpacing: -0.5, fontFamily: 'var(--font-display)', fontVariantNumeric: 'tabular-nums' }}>{value}<span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600, marginLeft: 2 }}>{unit}</span></div>
        <div style={{ fontSize: 10.5, color: 'var(--muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8, marginTop: 4 }}>{label}</div>
      </div>
    );
  }

  function Onboarding({ onDone }) {
    window.useVital();
    const [step, setStep] = React.useState(0);
    const [d, setD] = React.useState({ ...S.getState().onboarding });
    const set = (k, v) => setD((p) => ({ ...p, [k]: v }));
    const metric = d.units === 'metric';
    const scrollRef = React.useRef(null);

    const STEPS = ['You', 'Body', 'Activity', 'Goal', 'Diet'];
    const total = STEPS.length;
    const isResults = step === total;
    const preview = S.computeTargets(d);

    React.useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, [step]);

    function next() { setStep((s) => Math.min(total, s + 1)); }
    function back() { setStep((s) => Math.max(0, s - 1)); }
    function finish() { S.applyOnboarding(d); S.toast('Targets saved'); onDone && onDone(); }

    // ---- RESULTS SCREEN ----
    if (isResults) {
      const t = preview;
      const goalLabel = { lose: 'lose weight', maintain: 'maintain', gain: 'build muscle' }[d.goal];
      return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
          <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', WebkitOverflowScrolling: 'touch' }}>
            {/* accent hero */}
            <div style={{ position: 'relative', background: 'var(--accent)', color: 'var(--on-accent)', padding: 'calc(var(--safe-top) + 6px) 24px 30px', overflow: 'hidden' }}>
              <MazeBg opacity={0.08} />
              <div style={{ position: 'relative' }}>
                <div style={{ fontSize: 12, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, opacity: 0.7 }}>Your plan is ready</div>
                <div style={{ fontSize: 15, fontWeight: 600, opacity: 0.85, marginTop: 14 }}>Daily calorie budget</div>
                <div style={{ fontSize: 76, fontWeight: 800, lineHeight: 1, letterSpacing: -3, fontFamily: 'var(--font-display)', fontVariantNumeric: 'tabular-nums', marginTop: 2 }}>
                  {t.budget.toLocaleString()}
                </div>
                <div style={{ fontSize: 14, fontWeight: 600, opacity: 0.85, marginTop: 6 }}>
                  kcal / day to {goalLabel}{d.goal !== 'maintain' ? ` · ~${d.rateKgWk} ${metric ? 'kg' : 'lb'}/wk` : ''}
                </div>
              </div>
            </div>

            <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 20, marginTop: -2 }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', marginBottom: 12 }}>Daily macro split</div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <MacroTarget label="Protein" g={t.proteinG} c="var(--c-protein)" pct={Math.round(t.proteinG * 4 / t.budget * 100)} />
                  <MacroTarget label="Carbs" g={t.carbsG} c="var(--c-carbs)" pct={Math.round(t.carbsG * 4 / t.budget * 100)} />
                  <MacroTarget label="Fat" g={t.fatG} c="var(--c-fat)" pct={Math.round(t.fatG * 9 / t.budget * 100)} />
                </div>
              </div>

              <div>
                <div style={{ fontSize: 13, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--muted)', marginBottom: 12 }}>The science</div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <StatChip label="BMR" value={t.bmr.toLocaleString()} unit="" />
                  <StatChip label="Maintenance" value={t.tdee.toLocaleString()} unit="" />
                  <StatChip label="BMI" value={t.bmi} unit="" />
                </div>
                <p style={{ fontSize: 12.5, lineHeight: 1.5, color: 'var(--muted)', marginTop: 14 }}>
                  Your maintenance is <b style={{ color: 'var(--text)' }}>{t.tdee.toLocaleString()} kcal</b> (Mifflin–St Jeor × activity).
                  {d.goal === 'lose' && ` We trimmed ${(t.tdee - t.budget).toLocaleString()} kcal for steady fat loss.`}
                  {d.goal === 'gain' && ` We added ${(t.budget - t.tdee).toLocaleString()} kcal to fuel lean gains.`}
                  {d.goal === 'maintain' && ' Your budget matches maintenance.'}
                </p>
                {t.clamped && (
                  <div style={{ marginTop: 12, padding: '12px 14px', borderRadius: 12, background: 'var(--accent-soft)', fontSize: 12.5, lineHeight: 1.5, color: 'var(--text)' }}>
                    We raised your budget to a safe minimum — aggressive deficits aren’t sustainable or healthy.
                  </div>
                )}
              </div>

              <Disclaimer />
            </div>
          </div>

          <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)', display: 'flex', gap: 12 }}>
            <Button variant="ghost" size="lg" onClick={() => setStep(total - 1)}>Edit</Button>
            <Button full size="lg" onClick={finish}>Start tracking</Button>
          </div>
        </div>
      );
    }

    // ---- QUESTION STEPS ----
    let title, subtitle, content;
    if (step === 0) {
      title = 'Welcome to Vital'; subtitle = 'Two minutes of setup powers every number you’ll see.';
      content = (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <Field label="What should we call you?">
            <input value={d.name} onChange={(e) => set('name', e.target.value)} placeholder="Your name" style={inputStyle} />
          </Field>
          <Field label="Age">
            <Stepper value={d.age} onChange={(v) => set('age', v)} min={14} max={99} unit="yrs" />
          </Field>
          <Field label="Sex" hint="Used only to estimate your metabolic rate.">
            <Segmented full options={[{ value: 'male', label: 'Male' }, { value: 'female', label: 'Female' }]} value={d.sex} onChange={(v) => set('sex', v)} />
          </Field>
        </div>
      );
    } else if (step === 1) {
      title = 'Your body'; subtitle = 'The inputs behind your energy needs.';
      content = (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <Field label="Units">
            <Segmented full options={[{ value: 'metric', label: 'Metric' }, { value: 'imperial', label: 'Imperial' }]} value={d.units} onChange={(v) => set('units', v)} />
          </Field>
          <Field label="Height">
            <Stepper big value={metric ? d.heightCm : Math.round(d.heightCm / 2.54)} unit={metric ? 'cm' : 'in'}
              onChange={(v) => set('heightCm', metric ? v : Math.round(v * 2.54))} step={1} min={120} max={230} />
          </Field>
          <Field label="Current weight">
            <Stepper big value={metric ? d.weightKg : Math.round(d.weightKg * 2.205)} unit={metric ? 'kg' : 'lb'}
              onChange={(v) => set('weightKg', metric ? v : Math.round(v / 2.205))} step={metric ? 0.5 : 1} min={30} max={400} />
          </Field>
        </div>
      );
    } else if (step === 2) {
      title = 'How active are you?'; subtitle = 'Outside of planned workouts.';
      content = (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {ACTIVITY.map((a) => <ChoiceRow key={a.value} title={a.label} sub={a.sub} active={d.activity === a.value} onClick={() => set('activity', a.value)} />)}
        </div>
      );
    } else if (step === 3) {
      title = 'What’s your goal?'; subtitle = 'We’ll set a safe, sustainable target.';
      content = (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {GOALS.map((g) => <ChoiceRow key={g.value} title={g.label} sub={g.sub} active={d.goal === g.value} onClick={() => set('goal', g.value)} />)}
          </div>
          {d.goal !== 'maintain' && (
            <Field label={`Weekly pace · ${metric ? 'kg' : 'lb'} per week`} hint="0.5 kg/wk is the sustainable sweet spot for most people.">
              <Stepper big value={metric ? d.rateKgWk : +(d.rateKgWk * 2.205).toFixed(1)} unit={metric ? 'kg' : 'lb'}
                onChange={(v) => set('rateKgWk', metric ? v : +(v / 2.205).toFixed(2))} step={metric ? 0.25 : 0.5} min={0.25} max={metric ? 1 : 2} />
            </Field>
          )}
        </div>
      );
    } else if (step === 4) {
      title = 'Eating style'; subtitle = 'Tunes your meal suggestions — not your calories.';
      content = (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {DIETS.map((g) => <ChoiceRow key={g.value} title={g.label} active={d.diet === g.value} onClick={() => set('diet', g.value)} />)}
        </div>
      );
    }

    return (
      <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
        {/* progress */}
        <div style={{ padding: 'var(--safe-top) 22px 8px', display: 'flex', alignItems: 'center', gap: 14 }}>
          {step > 0 ? (
            <button onClick={back} style={iconBtn}><I.chevL size={20} /></button>
          ) : <div style={{ width: 38 }} />}
          <div style={{ flex: 1, display: 'flex', gap: 5 }}>
            {STEPS.map((_, i) => (
              <div key={i} style={{ flex: 1, height: 5, borderRadius: 99, background: i <= step ? 'var(--accent)' : 'var(--track)', transition: 'background .3s' }} />
            ))}
          </div>
          <div style={{ width: 38, textAlign: 'right', fontSize: 12.5, fontWeight: 700, color: 'var(--muted)' }}>{step + 1}/{total}</div>
        </div>

        <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '18px 22px 22px' }}>
          <h1 style={{ margin: '0 0 6px', fontSize: 30, fontWeight: 800, letterSpacing: -1, lineHeight: 1.05, fontFamily: 'var(--font-display)' }}>{title}</h1>
          <p style={{ margin: '0 0 26px', fontSize: 15, color: 'var(--muted)', lineHeight: 1.4 }}>{subtitle}</p>
          {content}
        </div>

        <div style={{ padding: '14px 22px calc(var(--safe-bottom) + 12px)', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
          <Button full size="lg" onClick={next} icon={null}>
            {step === total - 1 ? 'See my plan' : 'Continue'}
          </Button>
        </div>
      </div>
    );
  }

  function MacroTarget({ label, g, c, pct }) {
    return (
      <div style={{ flex: 1, padding: '16px 8px', borderRadius: 18, background: 'var(--surface)', border: '1px solid var(--border)', textAlign: 'center' }}>
        <div style={{ width: 32, height: 6, borderRadius: 99, background: c, margin: '0 auto 12px' }} />
        <div style={{ fontSize: 24, fontWeight: 800, fontFamily: 'var(--font-display)', letterSpacing: -0.5, fontVariantNumeric: 'tabular-nums' }}>{g}<span style={{ fontSize: 12, color: 'var(--muted)' }}>g</span></div>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.6, marginTop: 3 }}>{label}</div>
        <div style={{ fontSize: 11, color: 'var(--faint)', marginTop: 2 }}>{pct}%</div>
      </div>
    );
  }

  const iconBtn = {
    width: 38, height: 38, borderRadius: 999, border: '1px solid var(--border)', background: 'var(--surface)',
    color: 'var(--text)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0,
  };

  window.VitalScreens = window.VitalScreens || {};
  window.VitalScreens.Onboarding = Onboarding;
})();
